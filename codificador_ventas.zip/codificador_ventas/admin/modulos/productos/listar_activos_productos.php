<?php
                             
require_once(explode("wp-content", __FILE__)[0] . "wp-config.php"); 
$wpurl = plugins_url().'/codificador_ventas/plantilla/icons-1.7.2/bootstrap-icons.svg#justify';
$res = file_get_contents(plugins_url().'/codificador_ventas/api/api_productos_activos.php');
$array = json_decode($res);                            


?>               

                <table id="listado_activos_productos" class="display" style="width: 100%">  
                          <thead>  
                               <tr style="background: #FF0066;color: #FFFF;">  
                                    <td style="text-align: left;">Id productos</td>  
                                    <td style="text-align: left;">Productos</td>  
                                    <td style="text-align: center;">Estado</td>
                                    <td style="text-align: center;">Editar</td>
                                    <td style="text-align: center;">Inactivar</td>
                               </tr>  
                          </thead>  
                          <?php  
                            foreach($array as $obj)
                            {  
   
                                 $id_productos = $obj->id_productos; 
                                 $productos = $obj->productos; 
                                 $estado = $obj->estado; 
                               echo '  
                               <tr>  
                                    <td style="text-align: left;">'.$id_productos.'</td>  
                                    <td style="text-align: left;">'.$productos.'</td>  
                                    <td style="text-align: center;">'.$estado.'</td>
                                    <td style="text-align: center;">
                                     <button class="btn btn-primary primary-icon-notika btn-reco-mg btn-button-mg" type="button" class="btn btn-outline-primary block" data-toggle="modal" data-target="#modal_productos_activos"
                                         onclick="listar_generico_productos('.$id_productos.')"><svg class="bi" width="1em" height="1em" fill="currentColor">
                                                <use
                                                    xlink:href="'.$wpurl.'" />
                                            </svg></button>       
                                   </td>
                                   <td style="text-align: center;">
                                         <button class="btn btn-primary primary-icon-notika btn-reco-mg btn-button-mg" type="button" class="btn btn-outline-primary block" onclick="inactivo_productos(\''.$id_productos.'\')"><svg class="bi" width="1em" height="1em" fill="currentColor">
                                                    <use
                                                        xlink:href="'.$wpurl.'" />
                                                </svg></button>       
                                   </td>
                               </tr>  
                               ';  
                          }  
                          ?>  
                     </table>