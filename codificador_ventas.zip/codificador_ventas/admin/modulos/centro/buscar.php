<?php
    require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
    global $wpdb;
    $id_pais=sanitize_text_field($_POST["id_pais"]);
    
    $resultado_pais = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}pais WHERE id_pais = '$id_pais'", ARRAY_A );
      

?>  
    <form method="POST" id='editar_formulario_pais' enctype="multipart/form-data">
      <table  class="table table-hover">
          <input type="hidden" name="id_pais" value="<?php echo $id_pais ?>">
          <tr>
            <td>Centro: </td>
            <td>
              <input class="form-control" type="text" value="<?php echo $resultado_pais["pais"] ?>" name="centro" id="centro">
            </td>
          </tr>
      </table>                                                    
            
          <button type="button" onclick="modificar_datos_centro()" class="btn btn-primary ml-1"
            class="close" data-bs-dismiss="modal" aria-label="Close">
                                                        <i class="bx bx-check d-block d-sm-none"></i>
                                                        <span class="d-none d-sm-block">Guardar</span>
            </button>
    </form>