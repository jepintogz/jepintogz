<?php
    include_once '../../../../../../wp-config.php';
    include_once '../../../../../../wp-load.php';
    include_once '../../../../../../wp-includes/wp-db.php';
    include_once '../../../../../../wp-includes/pluggable.php';

    include('../../../conexion/conexion.php');
    global $wpdb;


if ($conexion -> connect_errno)

{

  die("Fallo la conexion:(".$conexion -> mysqli_connect_errno().")".$conexion-> mysqli_connect_error());

}

// error_reporting(E_ALL ^ E_NOTICE);

$cargos = $_POST["cargos"];
$estado = 'Activo';






if ($conexion->connect_error) {
    die("Connection failed: " . $conexion->connect_error);
} 

$sql = "INSERT INTO `{$wpdb->prefix}cargos` (`id_cargos`, `cargos`, `estado`) VALUES (Null, '$cargos', '$estado')";

if ($conexion->query($sql) === TRUE) {
    echo 1;
} else {
    echo "Error: " . $sql . "<br>" . $conexion->error;
}

$conexion->close();
 
	
?>