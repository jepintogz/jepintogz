<?php
/**
 * Archivo del plugin 
 * Este archivo es leído por WordPress para generar la información del plugin
 * en el área de administración del complemento. Este archivo también incluye 
 * todas las dependencias utilizadas por el complemento, registra las funciones 
 * de activación y desactivación y define una función que inicia el complemento.
 *
 * @link                https://www.grupounisono.es/
 * @since               2.9.2
 *
 * @wordpress-plugin
 * Plugin Name:         Codificador Ventas
 * Plugin URI:          https://www.grupounisono.es/
 * Description:         Plugin Libre
 * Version:             3.0
 * Author:              Joseph Pinto
 * Author URI:          https://www.grupounisono.es/
 * License:             GPL2
 * License URI:         https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:         https://www.grupounisono.es/
 * Domain Path:         /languages
 */

define('plugin_cd_iberdrola',plugin_dir_path(__FILE__));
   

function Activar_codificador_ventas()
{
        global $wpdb;
        include(plugin_cd_iberdrola . 'bd_registros.php');
}

function Desactivar_codificador_ventas()
{
    flush_rewrite_rules();
}

register_activation_hook(__FILE__,'Activar_codificador_ventas');
register_deactivation_hook(__FILE__,'Desactivar_codificador_ventas');
add_action('admin_menu','CrearMenu_codificador_ventas');

function CrearMenu_codificador_ventas(){

        add_menu_page('Codificador Ventas',
                      'Codificador Ventas',
                      'manage_options',
                      plugin_cd_iberdrola . '/admin/modulos/codificador_ventas/index.php'

                      );


        add_submenu_page(plugin_cd_iberdrola . '/admin/modulos/codificador_ventas/index.php',
                         'Acción',
                         'Acción',
                         'manage_options',
                         plugin_cd_iberdrola . '/admin/modulos/accion/index.php'
                        );

        add_submenu_page(plugin_cd_iberdrola . '/admin/modulos/codificador_ventas/index.php',
                         'Departamento',
                         'Departamento',
                         'manage_options',
                         plugin_cd_iberdrola . '/admin/modulos/departamento/index.php'
                        );

        add_submenu_page(plugin_cd_iberdrola . '/admin/modulos/codificador_ventas/index.php',
                         'Planes',
                         'Planes',
                         'manage_options',
                         plugin_cd_iberdrola . '/admin/modulos/planes/index.php'
                        );

        add_submenu_page(plugin_cd_iberdrola . '/admin/modulos/codificador_ventas/index.php',
                         'Productos',
                         'Productos',
                         'manage_options',
                         plugin_cd_iberdrola . '/admin/modulos/productos/index.php'
                        );

        add_submenu_page(plugin_cd_iberdrola . '/admin/modulos/codificador_ventas/index.php',
                         'Centro',
                         'Centro',
                         'manage_options',
                         plugin_cd_iberdrola . '/admin/modulos/centro/index.php'
                        );

        add_submenu_page(plugin_cd_iberdrola . '/admin/modulos/codificador_ventas/index.php',
                         'Cargos',
                         'Cargos',
                         'manage_options',
                         plugin_cd_iberdrola . '/admin/modulos/cargos/index.php'
                        );

        add_submenu_page(plugin_cd_iberdrola . '/admin/modulos/codificador_ventas/index.php',
                         'Canal Entrada',
                         'Canal Entrada',
                         'manage_options',
                         plugin_cd_iberdrola . '/admin/modulos/canal_entrada/index.php'
                        );

        add_submenu_page(plugin_cd_iberdrola . '/admin/modulos/codificador_ventas/index.php',
                         'Usuarios Delta',
                         'Usuarios Delta',
                         'manage_options',
                         plugin_cd_iberdrola . '/admin/modulos/usuarios_delta/index.php'
                        );

        add_submenu_page(plugin_cd_iberdrola . '/admin/modulos/codificador_ventas/index.php',
                         'Reporte',
                         'Reporte',
                         'manage_options',
                         plugin_cd_iberdrola . '/admin/modulos/reporte/index.php'
                        );
}



function imprimirshortcode()
{

  
  if ( ! is_admin() ) 
  {
       ob_start();
       include(plugin_cd_iberdrola . 'admin/modulos/codificador_ventas/index.php');
       $codigo_html = ob_get_clean();
       return $codigo_html;
  }   


}

add_shortcode("codificador_ventas","imprimirshortcode");

function imprimirshortcode2()
{

  if ( ! is_admin() ) 
  {
       ob_start();
       include(plugin_cd_iberdrola . 'admin/modulos/reporte/index.php');
       $codigo_html = ob_get_clean();
       return $codigo_html;
  }   
  

}

add_shortcode("codificador_reporte","imprimirshortcode2");


function imprimirshortcode3()
{
  
  if ( ! is_admin() ) 
  {
       ob_start();
       include(plugin_cd_iberdrola . 'admin/modulos/accion/index.php');
       $codigo_html = ob_get_clean();
       return $codigo_html;
  }   

}

add_shortcode("imprimirshortcode3","imprimirshortcode3");

if (!defined('ABSPATH') && !defined('WP_UNINSTALL_PLUGIN')) 
{
    exit();
    global $wpdb;
    delete_option('imacPrestashop_options');
}