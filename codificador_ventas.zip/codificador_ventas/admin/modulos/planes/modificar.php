<?php
    require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
    global $wpdb;
    $id_planes=sanitize_text_field($_POST["id_planes"]);
    $planes = sanitize_text_field($_POST["planes"]);
    $sql11_42_1 ="UPDATE {$wpdb->prefix}planes SET planes = '$planes' WHERE id_planes = '$id_planes'";
    $wpdb->query($sql11_42_1);  
    echo 1;

?>