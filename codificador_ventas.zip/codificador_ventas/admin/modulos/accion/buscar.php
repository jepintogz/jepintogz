<?php
    require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
    global $wpdb;
    $id_accion=sanitize_text_field($_POST["id_accion"]);
    
    $resultado_accion = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}accion WHERE id_accion = '$id_accion'", ARRAY_A );
      

?>  
    <form method="POST" id='editar_formulario_accion' enctype="multipart/form-data">
      <table  class="table table-hover">
          <input type="hidden" name="id_accion" value="<?php echo $id_accion ?>">
          <tr>
            <td>Acción: </td>
            <td>
              <input class="form-control" type="text" value="<?php echo $resultado_accion["accion"] ?>" name="accion" id="accion">
            </td>
          </tr>
      </table>                                                    
            <button type="button" onclick="modificar_datos_accion()" class="btn btn-primary ml-1"
            class="close" data-bs-dismiss="modal" aria-label="Close">
                                                        <i class="bx bx-check d-block d-sm-none"></i>
                                                        <span class="d-none d-sm-block">Guardar</span>
            </button>
    </form>