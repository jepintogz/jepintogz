<?php
      
require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
global $wpdb;      
$user_info = get_userdata(1);
if (is_user_logged_in()){
$cu = wp_get_current_user();
}


$user_general = $cu->user_login;
$user_general;
date_default_timezone_set('America/Bogota');
$hoy = date("Y-m-d");
$fechaMysql2 = sanitize_text_field($_POST["fecha_inicial_ranking"]);
$fecha2 = preg_split("/[\s-]/", $fechaMysql2);
$mostrar_fecha1 = $fecha2[2];
$mostrar_fecha2 = $fecha2[1];
$mostrar_fecha3 = $fecha2[0];
$id_accion_ranking = sanitize_text_field($_POST["id_accion_ranking"]);
$id_pais_ranking = sanitize_text_field($_POST["id_pais_ranking"]);
$id_departamento_ranking = sanitize_text_field($_POST["id_departamento_ranking"]);




?>

<?php
        
if(sanitize_text_field($_POST["fecha_inicial_ranking"]) AND sanitize_text_field($_POST["id_accion_ranking"]) AND sanitize_text_field($_POST["id_pais_ranking"]) AND sanitize_text_field($_POST["id_departamento_ranking"]))
{
         
          if(sanitize_text_field($_POST["id_accion_ranking"]=='1'))
          {

               $resultado = $wpdb->get_results( "SELECT {$wpdb->prefix}codificador_ventas.id_codificador,{$wpdb->prefix}codificador_ventas.id_accion,{$wpdb->prefix}codificador_ventas.id_productos,{$wpdb->prefix}codificador_ventas.id_planes,{$wpdb->prefix}codificador_ventas.id_canal_entrada,{$wpdb->prefix}codificador_ventas.cups,{$wpdb->prefix}codificador_ventas.usuario_delta,{$wpdb->prefix}codificador_ventas.fecha_registro,COUNT(DISTINCT {$wpdb->prefix}codificador_ventas.cups) AS acciones,{$wpdb->prefix}departamento.departamento,{$wpdb->prefix}usuarios_delta.id_pais,{$wpdb->prefix}pais.pais FROM {$wpdb->prefix}codificador_ventas
               LEFT JOIN {$wpdb->prefix}accion ON {$wpdb->prefix}accion.id_accion = {$wpdb->prefix}codificador_ventas.id_accion
               LEFT JOIN {$wpdb->prefix}departamento ON {$wpdb->prefix}departamento.id_departamento = {$wpdb->prefix}codificador_ventas.id_departamento
               LEFT JOIN {$wpdb->prefix}usuarios_delta ON {$wpdb->prefix}usuarios_delta.user_login = {$wpdb->prefix}codificador_ventas.usuario
               LEFT JOIN {$wpdb->prefix}pais ON {$wpdb->prefix}pais.id_pais = {$wpdb->prefix}usuarios_delta.id_pais WHERE  MONTH({$wpdb->prefix}codificador_ventas.fecha_registro) = '$mostrar_fecha2' AND YEAR({$wpdb->prefix}codificador_ventas.fecha_registro) = '$mostrar_fecha3' AND {$wpdb->prefix}pais.id_pais = '$id_pais_ranking' AND {$wpdb->prefix}accion.id_accion = '$id_accion_ranking' AND {$wpdb->prefix}departamento.id_departamento = '$id_departamento_ranking' GROUP BY {$wpdb->prefix}codificador_ventas.usuario_delta ORDER BY COUNT(DISTINCT {$wpdb->prefix}codificador_ventas.cups) DESC" , ARRAY_A);   


          }elseif(sanitize_text_field($_POST["id_accion_ranking"]=='2'))
          {

               $resultado = $wpdb->get_results( "SELECT {$wpdb->prefix}codificador_ventas.id_codificador,{$wpdb->prefix}codificador_ventas.id_accion,{$wpdb->prefix}codificador_ventas.id_productos,{$wpdb->prefix}codificador_ventas.id_planes,{$wpdb->prefix}codificador_ventas.id_canal_entrada,{$wpdb->prefix}codificador_ventas.cups,{$wpdb->prefix}codificador_ventas.usuario_delta,{$wpdb->prefix}codificador_ventas.fecha_registro,COUNT(DISTINCT {$wpdb->prefix}codificador_ventas.cups) AS acciones,{$wpdb->prefix}departamento.departamento,{$wpdb->prefix}usuarios_delta.id_pais,{$wpdb->prefix}pais.pais FROM {$wpdb->prefix}codificador_ventas
               LEFT JOIN {$wpdb->prefix}accion ON {$wpdb->prefix}accion.id_accion = {$wpdb->prefix}codificador_ventas.id_accion
               LEFT JOIN {$wpdb->prefix}departamento ON {$wpdb->prefix}departamento.id_departamento = {$wpdb->prefix}codificador_ventas.id_departamento
               LEFT JOIN {$wpdb->prefix}usuarios_delta ON {$wpdb->prefix}usuarios_delta.user_login = {$wpdb->prefix}codificador_ventas.usuario
               LEFT JOIN {$wpdb->prefix}pais ON {$wpdb->prefix}pais.id_pais = {$wpdb->prefix}usuarios_delta.id_pais WHERE  MONTH({$wpdb->prefix}codificador_ventas.fecha_registro) = '$mostrar_fecha2' AND YEAR({$wpdb->prefix}codificador_ventas.fecha_registro) = '$mostrar_fecha3' AND {$wpdb->prefix}pais.id_pais = '$id_pais_ranking' AND ({$wpdb->prefix}accion.id_accion = '2' OR {$wpdb->prefix}accion.id_accion = '3') AND {$wpdb->prefix}departamento.id_departamento = '$id_departamento_ranking' GROUP BY {$wpdb->prefix}codificador_ventas.usuario_delta ORDER BY COUNT(DISTINCT {$wpdb->prefix}codificador_ventas.cups) DESC" , ARRAY_A);   

          }
}
        
        

        ?>


    <br/><br/>
    <br/><br/>
                <table id="mis_ventas_ranking" class="display" style="width:100%">
                          <thead>  
                               <tr style="background: #FF0066;color: #FFFF;">  
                                    <td style="text-align: center;">#</td>  
                                    <td style="text-align: center;">Usuario Delta</td> 
                                    <td style="text-align: center;">Acción</td> 
                               </tr>  
                          </thead>    
                          <?php  
                          $contador=0;
                          foreach ( $resultado as $activos )
                          {
                              $contador++;
                               
                               echo '  
                               <tr>  
                                    <td style="text-align: center;">'.$contador.'</td>  
                                    <td style="text-align: center;">'.$activos["usuario_delta"].'</td>
                                    <td style="text-align: center;">'.$activos["acciones"].'</td>
                                    ';

                               echo '</tr>  
                               ';  
                          }  
                          ?> 
                     </table>
                    
        

