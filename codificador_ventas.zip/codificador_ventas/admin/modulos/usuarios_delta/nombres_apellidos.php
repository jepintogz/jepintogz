<?php
require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
global $wpdb;
$user_login=sanitize_text_field($_POST["user_login"]);
$sql_nombres_apellidos = $wpdb->get_row( "SELECT {$wpdb->prefix}users.user_login, firstmeta.meta_value as first_name, lastmeta.meta_value as last_name FROM {$wpdb->prefix}users left join {$wpdb->prefix}usermeta as firstmeta on {$wpdb->prefix}users.ID = firstmeta.user_id and firstmeta.meta_key = 'first_name' left join {$wpdb->prefix}usermeta as lastmeta on {$wpdb->prefix}users.ID = lastmeta.user_id and lastmeta.meta_key = 'last_name' WHERE {$wpdb->prefix}users.user_login = '$user_login' order by last_name", ARRAY_A );
if($sql_nombres_apellidos["last_name"])
{
	$nombres_apellidos = $sql_nombres_apellidos["last_name"].', '.' '.$sql_nombres_apellidos["first_name"];	
	$cadena=ltrim($nombres_apellidos);
	echo $cadena;
}

?>