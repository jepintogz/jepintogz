<?php
	  
require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
global $wpdb;	  

$id_planes=sanitize_text_field($_POST["id_planes"]);
$id_departamento=sanitize_text_field($_POST["id_departamento"]);
$cups=sanitize_text_field($_POST["cups"]);
$id_accion=sanitize_text_field($_POST["id_accion"]);


$sql11_42_1 ="DELETE FROM `{$wpdb->prefix}codificador_ventas` WHERE `cups` = '$cups' AND `id_planes` = '$id_planes' AND `id_departamento` = '$id_departamento' AND `id_accion` = '$id_accion'";
$wpdb->query($sql11_42_1);  
echo 1;

?>
