<?php


require_once(explode("wp-content", __FILE__)[0] . "wp-config.php"); 
$wpurl = plugins_url().'/codificador_ventas/plantilla/icons-1.7.2/bootstrap-icons.svg#justify';
$cups = sanitize_text_field($_POST["cups"]);
$fecha_registro = sanitize_text_field($_POST["fecha_registro"]);
$consulta_c_ventas = $wpdb->get_results( "SELECT * FROM  {$wpdb->prefix}codificador_ventas WHERE cups = '$cups' AND fecha_registro = '$fecha_registro'" , ARRAY_A);   



foreach ( $consulta_c_ventas as $resultados )
{

        $id_productos = $resultados["id_productos"];
        $resultado_canal = $wpdb->get_row( "SELECT * FROM  {$wpdb->prefix}productos WHERE id_productos = '$id_productos'", ARRAY_A );

?>
	<option value="<?php echo $resultado_canal["id_productos"]; ?>" selected><?php echo $resultado_canal["productos"]; ?></option>
<?php

}


$consulta_c_accion = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}productos where estado = 'Activo'" , ARRAY_A);   
foreach ( $consulta_c_accion as $resultados )
{                            
?>
<option value="<?php echo $resultados["id_productos"]; ?>"><?php echo $resultados["productos"]; ?></option>
                            
<?php
}
?>