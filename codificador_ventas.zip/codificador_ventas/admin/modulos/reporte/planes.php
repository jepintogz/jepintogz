<?php

require_once(explode("wp-content", __FILE__)[0] . "wp-config.php"); 
$wpurl = plugins_url().'/codificador_ventas/plantilla/icons-1.7.2/bootstrap-icons.svg#justify';
$id_codificador = sanitize_text_field($_POST["id_codificador"]);
$consulta_c_ventas = $wpdb->get_results( "SELECT * FROM  {$wpdb->prefix}codificador_ventas WHERE id_codificador = '$id_codificador'" , ARRAY_A);   

?>
<?php
  foreach ( $consulta_c_ventas as $resultados )
  {
        $id_planes = $resultados["id_planes"];
        $resultado_canal = $wpdb->get_row( "SELECT * FROM  {$wpdb->prefix}planes WHERE id_planes = '$id_planes'", ARRAY_A );

?>
	      <option value="<?php echo $resultado_canal["id_planes"]; ?>"><?php echo $resultado_canal["planes"]; ?></option>
<?php

  }

$consulta_c_accion = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}planes where estado = 'Activo'" , ARRAY_A);   
foreach ( $consulta_c_accion as $resultados )
{                            
?>
<option value="<?php echo $resultados["id_planes"]; ?>"><?php echo $resultados["planes"]; ?></option>
                            
<?php
}
?>         