<?php
  require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
  global $wpdb;
  $response = array();
  header("Content-Type: Json");
  $i = 0;
  $motivoss = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}pais WHERE estado = 'Activo'" , ARRAY_A);  

  foreach ( $motivoss as $resultados ) 
  {
                              
    $response [$i]['id_pais'] = $resultados ['id_pais'];
    $response [$i]['pais'] = $resultados ['pais'];
    $response [$i]['estado'] = $resultados ['estado'];
    $i++;
  
  }   

  echo json_encode($response,JSON_PRETTY_PRINT);
?>
