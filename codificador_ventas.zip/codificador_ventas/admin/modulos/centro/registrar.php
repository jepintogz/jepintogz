<?php
    require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
    global $wpdb;
    $pais = sanitize_text_field($_POST["pais"]);
    $estado = 'Activo';
    $sql11_42_1 ="INSERT INTO `{$wpdb->prefix}pais` (`id_pais`, `pais`, `estado`) VALUES (Null, '$pais', '$estado')";
    $wpdb->query($sql11_42_1);  
    echo 1;

?>