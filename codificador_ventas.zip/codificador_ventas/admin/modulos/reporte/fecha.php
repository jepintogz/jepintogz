<?php

require_once(explode("wp-content", __FILE__)[0] . "wp-config.php"); 
$wpurl = plugins_url().'/codificador_ventas/plantilla/icons-1.7.2/bootstrap-icons.svg#justify';
$id_codificador = sanitize_text_field($_POST["id_codificador"]);
$resultado_codificador = $wpdb->get_row( "SELECT * FROM  {$wpdb->prefix}codificador_ventas WHERE id_codificador = '$id_codificador'", ARRAY_A );


	  if($resultado_codificador["fecha_registro"])
	  	{
	  		
	  		$cadena=ltrim($resultado_codificador["fecha_registro"]);
?>
	<?php echo $cadena ?>
	

<?php
		}
?>