<?php
  require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
  global $wpdb;
  $id_productos=sanitize_text_field($_POST["id_productos"]);
  $sql11_42_1 ="UPDATE {$wpdb->prefix}productos SET estado = 'Activo' WHERE id_productos = '$id_productos'";
  $wpdb->query($sql11_42_1);  
?>