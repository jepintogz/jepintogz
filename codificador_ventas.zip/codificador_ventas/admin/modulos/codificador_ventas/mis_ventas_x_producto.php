<?php
      
require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
global $wpdb;      
            
      
$user_info = get_userdata(1);
if (is_user_logged_in()){
$cu = wp_get_current_user();
}
 

$user_general = $cu->user_login;
$user_general;
$hoy = date("Y-m-d");
$fecha_inicial_estadisticas_producto = sanitize_text_field($_POST["fecha_inicial_estadisticas_producto"]);


$fechaMysql2 = sanitize_text_field($_POST["fecha_inicial_estadisticas_producto"]);

$dato_fecha = date("Y-m-d");
$fecha = date('Y-m-d',strtotime($dato_fecha));
$fechaMysql2 = $fecha;
$fecha2 = preg_split("/[\s-]/", $fechaMysql2);

$mostrar_fecha2 = $fecha2[1];
$mostrar_fecha3 = $fecha2[0];
$hoy3 = $fecha2[2];






$dia1 = '01';
$dia2 = '02';
$dia3 = '03';
$dia4 = '04';
$dia5 = '05';
$dia6 = '06';
$dia7 = '07';
$dia8 = '08';
$dia9 = '09';
$dia10 = '10';
$dia11 = '11';
$dia12 = '12';
$dia13 = '13';
$dia14 = '14';
$dia15 = '15';
$dia16 = '16';
$dia17 = '17';
$dia18 = '18';
$dia19 = '19';
$dia20 = '20';
$dia21 = '21';
$dia22 = '22';
$dia23 = '23';
$dia24 = '24';
$dia25 = '25';
$dia26 = '26';
$dia27 = '27';
$dia28 = '28';
$dia29 = '29';
$dia30 = '30';
$dia31 = '31';



$resultado_principal = $wpdb->get_results( "SELECT id_codificador,id_departamento,id_accion,id_productos,id_planes,id_canal_entrada,cups,usuario_delta,usuario,fecha_registro,
max(case when (id_productos) = '1' then '1' end) productos1,
max(case when (id_productos) = '2' then '2' end) productos2,
max(case when (id_productos) = '3' then '3' end) productos3,
max(case when (id_productos) = '4' then '4' end) productos4,
max(case when (id_productos) = '5' then '5' end) productos5,
max(case when (id_productos) = '6' then '6' end) productos6,
max(case when (id_productos) = '7' then '7' end) productos7,
max(case when (id_productos) = '8' then '8' end) productos8,
max(case when (id_productos) = '9' then '9' end) productos9,
max(case when (id_productos) = '10' then '10' end) productos10,
max(case when (id_productos) = '11' then '11' end) productos11,
max(case when (id_productos) = '12' then '12' end) productos12,
max(case when (id_productos) = '13' then '13' end) productos13,
max(case when (id_productos) = '14' then '14' end) productos14,
max(case when (id_productos) = '15' then '15' end) productos15,
max(case when (id_productos) = '16' then '16' end) productos16,
max(case when (id_productos) = '17' then '17' end) productos17,
max(case when (id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   




$resultado2 = $wpdb->get_results( "SELECT id_codificador,id_departamento,id_accion,id_productos,id_planes,id_canal_entrada,cups,usuario_delta,usuario,fecha_registro,
max(case when (id_productos) = '1' then '1' end) productos1,
max(case when (id_productos) = '2' then '2' end) productos2,
max(case when (id_productos) = '3' then '3' end) productos3,
max(case when (id_productos) = '4' then '4' end) productos4,
max(case when (id_productos) = '5' then '5' end) productos5,
max(case when (id_productos) = '6' then '6' end) productos6,
max(case when (id_productos) = '7' then '7' end) productos7,
max(case when (id_productos) = '8' then '8' end) productos8,
max(case when (id_productos) = '9' then '9' end) productos9,
max(case when (id_productos) = '10' then '10' end) productos10,
max(case when (id_productos) = '11' then '11' end) productos11,
max(case when (id_productos) = '12' then '12' end) productos12,
max(case when (id_productos) = '13' then '13' end) productos13,
max(case when (id_productos) = '14' then '14' end) productos14,
max(case when (id_productos) = '15' then '15' end) productos15,
max(case when (id_productos) = '16' then '16' end) productos16,
max(case when (id_productos) = '17' then '17' end) productos17,
max(case when (id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   




$resultado3 = $wpdb->get_results( "SELECT id_codificador,id_departamento,id_accion,id_productos,id_planes,id_canal_entrada,cups,usuario_delta,usuario,fecha_registro,
max(case when (id_productos) = '1' then '1' end) productos1,
max(case when (id_productos) = '2' then '2' end) productos2,
max(case when (id_productos) = '3' then '3' end) productos3,
max(case when (id_productos) = '4' then '4' end) productos4,
max(case when (id_productos) = '5' then '5' end) productos5,
max(case when (id_productos) = '6' then '6' end) productos6,
max(case when (id_productos) = '7' then '7' end) productos7,
max(case when (id_productos) = '8' then '8' end) productos8,
max(case when (id_productos) = '9' then '9' end) productos9,
max(case when (id_productos) = '10' then '10' end) productos10,
max(case when (id_productos) = '11' then '11' end) productos11,
max(case when (id_productos) = '12' then '12' end) productos12,
max(case when (id_productos) = '13' then '13' end) productos13,
max(case when (id_productos) = '14' then '14' end) productos14,
max(case when (id_productos) = '15' then '15' end) productos15,
max(case when (id_productos) = '16' then '16' end) productos16,
max(case when (id_productos) = '17' then '17' end) productos17,
max(case when (id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` WHERE SUBSTR({$wpdb->prefix}codificador_ventas.fecha_registro,1,10)='$hoy' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador3 = $wpdb->num_rows;



$resultado4 = $wpdb->get_results( "SELECT id_codificador,id_departamento,id_accion,id_productos,id_planes,id_canal_entrada,cups,usuario_delta,usuario,fecha_registro,
max(case when (id_productos) = '1' then '1' end) productos1,
max(case when (id_productos) = '2' then '2' end) productos2,
max(case when (id_productos) = '3' then '3' end) productos3,
max(case when (id_productos) = '4' then '4' end) productos4,
max(case when (id_productos) = '5' then '5' end) productos5,
max(case when (id_productos) = '6' then '6' end) productos6,
max(case when (id_productos) = '7' then '7' end) productos7,
max(case when (id_productos) = '8' then '8' end) productos8,
max(case when (id_productos) = '9' then '9' end) productos9,
max(case when (id_productos) = '10' then '10' end) productos10,
max(case when (id_productos) = '11' then '11' end) productos11,
max(case when (id_productos) = '12' then '12' end) productos12,
max(case when (id_productos) = '13' then '13' end) productos13,
max(case when (id_productos) = '14' then '14' end) productos14,
max(case when (id_productos) = '15' then '15' end) productos15,
max(case when (id_productos) = '16' then '16' end) productos16,
max(case when (id_productos) = '17' then '17' end) productos17,
max(case when (id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` WHERE SUBSTR({$wpdb->prefix}codificador_ventas.fecha_registro,1,10)='$hoy' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador4 = $wpdb->num_rows;


$resultado5 = $wpdb->get_results( "SELECT id_codificador,id_departamento,id_accion,id_productos,id_planes,id_canal_entrada,cups,usuario_delta,usuario,fecha_registro,
max(case when (id_productos) = '1' then '1' end) productos1,
max(case when (id_productos) = '2' then '2' end) productos2,
max(case when (id_productos) = '3' then '3' end) productos3,
max(case when (id_productos) = '4' then '4' end) productos4,
max(case when (id_productos) = '5' then '5' end) productos5,
max(case when (id_productos) = '6' then '6' end) productos6,
max(case when (id_productos) = '7' then '7' end) productos7,
max(case when (id_productos) = '8' then '8' end) productos8,
max(case when (id_productos) = '9' then '9' end) productos9,
max(case when (id_productos) = '10' then '10' end) productos10,
max(case when (id_productos) = '11' then '11' end) productos11,
max(case when (id_productos) = '12' then '12' end) productos12,
max(case when (id_productos) = '13' then '13' end) productos13,
max(case when (id_productos) = '14' then '14' end) productos14,
max(case when (id_productos) = '15' then '15' end) productos15,
max(case when (id_productos) = '16' then '16' end) productos16,
max(case when (id_productos) = '17' then '17' end) productos17,
max(case when (id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` WHERE SUBSTR({$wpdb->prefix}codificador_ventas.fecha_registro,1,10)='$hoy' AND usuario = '$user_general' GROUP BY usuario,usuario_delta,fecha_registro" , ARRAY_A);   
$contador5 = $wpdb->num_rows;


$resultado7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador7 = $wpdb->num_rows;



$resultado8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador8 = $wpdb->num_rows;


$resultado9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador9 = $wpdb->num_rows;


$resultado10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador10 = $wpdb->num_rows;


$resultado11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador11 = $wpdb->num_rows;


$resultado12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador12 = $wpdb->num_rows;



$resultado13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador13 = $wpdb->num_rows;



$resultado14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador14 = $wpdb->num_rows;



$resultado15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador15 = $wpdb->num_rows;



$resultado16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador16 = $wpdb->num_rows;



$resultado17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador17 = $wpdb->num_rows;



$resultado18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador18 = $wpdb->num_rows;



$resultado19 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador19 = $wpdb->num_rows;



$resultado20 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador21 = $wpdb->num_rows;



$resultado22 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador22 = $wpdb->num_rows;



$resultado23 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23 = $wpdb->num_rows;



$resultado24 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24 = $wpdb->num_rows;





          /////////////////////////////HOY/////////////////////////////

$resultado23_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_1 = $wpdb->num_rows;
          

$resultado23_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_2 = $wpdb->num_rows;
                    
          
$resultado23_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_3 = $wpdb->num_rows;
                    
$resultado23_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_4 = $wpdb->num_rows;
                    
$resultado23_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_5 = $wpdb->num_rows;
                    
$resultado23_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_6 = $wpdb->num_rows;
                    
$resultado23_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_7 = $wpdb->num_rows;
                    
$resultado23_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_8 = $wpdb->num_rows;
                    
$resultado23_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_9 = $wpdb->num_rows;
                    
$resultado23_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_10 = $wpdb->num_rows;
                    
$resultado23_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_11 = $wpdb->num_rows;
                    
$resultado23_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_12 = $wpdb->num_rows;
                    
$resultado23_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_13 = $wpdb->num_rows;
                    
$resultado23_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_14 = $wpdb->num_rows;
                    
$resultado23_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_15 = $wpdb->num_rows;
                    
$resultado23_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_16 = $wpdb->num_rows;
                    
$resultado23_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_17 = $wpdb->num_rows;
                    
$resultado23_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$hoy3' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_18 = $wpdb->num_rows;
                    



/////////////////////////////DIA 1/////////////////////////////
$resultado24_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_1 = $wpdb->num_rows;
          

$resultado24_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_2 = $wpdb->num_rows;
                    
          
$resultado24_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_3 = $wpdb->num_rows;
                    
$resultado24_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_4 = $wpdb->num_rows;
                    
$resultado24_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_5 = $wpdb->num_rows;
                    
$resultado24_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_6 = $wpdb->num_rows;
                    
$resultado24_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_7 = $wpdb->num_rows;
                    
$resultado24_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_8 = $wpdb->num_rows;
                    
$resultado24_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_9 = $wpdb->num_rows;
                    
$resultado24_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_10 = $wpdb->num_rows;
                    
$resultado24_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_11 = $wpdb->num_rows;
                    
$resultado24_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_12 = $wpdb->num_rows;
                    
$resultado24_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_13 = $wpdb->num_rows;
                    
$resultado24_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_14 = $wpdb->num_rows;
                    
$resultado24_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_15 = $wpdb->num_rows;
                    
$resultado24_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_16 = $wpdb->num_rows;
                    
$resultado24_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_17 = $wpdb->num_rows;
                    
$resultado24_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_18 = $wpdb->num_rows;

/////////////////////////////////DIA 2//////////////////////////////////////
$resultado25_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_1 = $wpdb->num_rows;
          

$resultado25_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_2 = $wpdb->num_rows;
                    
          
$resultado25_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_3 = $wpdb->num_rows;
                    
$resultado25_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_4 = $wpdb->num_rows;
                    
$resultado25_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_5 = $wpdb->num_rows;
                    
$resultado25_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_6 = $wpdb->num_rows;
                    
$resultado25_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_7 = $wpdb->num_rows;
                    
$resultado25_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_8 = $wpdb->num_rows;
                    
$resultado25_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_9 = $wpdb->num_rows;
                    
$resultado25_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_10 = $wpdb->num_rows;
                    
$resultado25_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_11 = $wpdb->num_rows;
                    
$resultado25_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_12 = $wpdb->num_rows;
                    
$resultado25_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_13 = $wpdb->num_rows;
                    
$resultado25_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_14 = $wpdb->num_rows;
                    
$resultado25_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_15 = $wpdb->num_rows;
                    
$resultado25_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_16 = $wpdb->num_rows;
                    
$resultado25_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_17 = $wpdb->num_rows;
                    
$resultado25_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_18 = $wpdb->num_rows;

/////////////////////////////////DIA 3//////////////////////////////////////
$resultado26_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_1 = $wpdb->num_rows;
          

$resultado26_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_2 = $wpdb->num_rows;
                    
          
$resultado26_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_3 = $wpdb->num_rows;
                    
$resultado26_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_4 = $wpdb->num_rows;
                    
$resultado26_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_5 = $wpdb->num_rows;
                    
$resultado26_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_6 = $wpdb->num_rows;
                    
$resultado26_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_7 = $wpdb->num_rows;
                    
$resultado26_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_8 = $wpdb->num_rows;
                    
$resultado26_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_9 = $wpdb->num_rows;
                    
$resultado26_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_10 = $wpdb->num_rows;
                    
$resultado26_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_11 = $wpdb->num_rows;
                    
$resultado26_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_12 = $wpdb->num_rows;
                    
$resultado26_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_13 = $wpdb->num_rows;
                    
$resultado26_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_14 = $wpdb->num_rows;
                    
$resultado26_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_15 = $wpdb->num_rows;
                    
$resultado26_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_16 = $wpdb->num_rows;
                    
$resultado26_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_17 = $wpdb->num_rows;
                    
$resultado26_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_18 = $wpdb->num_rows;


          /////////////////////////////////DIA 4////////////////////////////
$resultado27_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_1 = $wpdb->num_rows;
          

$resultado27_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_2 = $wpdb->num_rows;
                    
          
$resultado27_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_3 = $wpdb->num_rows;
                    
$resultado27_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_4 = $wpdb->num_rows;
                    
$resultado27_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_5 = $wpdb->num_rows;
                    
$resultado27_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_6 = $wpdb->num_rows;
                    
$resultado27_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_7 = $wpdb->num_rows;
                    
$resultado27_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_8 = $wpdb->num_rows;
                    
$resultado27_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_9 = $wpdb->num_rows;
                    
$resultado27_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_10 = $wpdb->num_rows;
                    
$resultado27_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_11 = $wpdb->num_rows;
                    
$resultado27_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_12 = $wpdb->num_rows;
                    
$resultado27_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_13 = $wpdb->num_rows;
                    
$resultado27_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_14 = $wpdb->num_rows;
                    
$resultado27_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_15 = $wpdb->num_rows;
                    
$resultado27_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_16 = $wpdb->num_rows;
                    
$resultado27_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_17 = $wpdb->num_rows;
                    
$resultado27_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_18 = $wpdb->num_rows;

/////////////////////////////////DIA 5//////////////////////////////////////
$resultado28_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_1 = $wpdb->num_rows;
          

$resultado28_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_2 = $wpdb->num_rows;
                    
          
$resultado28_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_3 = $wpdb->num_rows;
                    
$resultado28_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_4 = $wpdb->num_rows;
                    
$resultado28_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_5 = $wpdb->num_rows;
                    
$resultado28_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_6 = $wpdb->num_rows;
                    
$resultado28_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_7 = $wpdb->num_rows;
                    
$resultado28_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_8 = $wpdb->num_rows;
                    
$resultado28_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_9 = $wpdb->num_rows;
                    
$resultado28_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_10 = $wpdb->num_rows;
                    
$resultado28_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_11 = $wpdb->num_rows;
                    
$resultado28_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_12 = $wpdb->num_rows;
                    
$resultado28_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_13 = $wpdb->num_rows;
                    
$resultado28_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_14 = $wpdb->num_rows;
                    
$resultado28_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_15 = $wpdb->num_rows;
                    
$resultado28_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_16 = $wpdb->num_rows;
                    
$resultado28_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_17 = $wpdb->num_rows;
                    
$resultado28_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_18 = $wpdb->num_rows;

          /////////////////////////////////DIA 6//////////////////////////////////////

$resultado29_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_1 = $wpdb->num_rows;
          

$resultado29_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_2 = $wpdb->num_rows;
                    
          
$resultado29_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_3 = $wpdb->num_rows;
                    
$resultado29_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_4 = $wpdb->num_rows;
                    
$resultado29_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_5 = $wpdb->num_rows;
                    
$resultado29_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_6 = $wpdb->num_rows;
                    
$resultado29_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_7 = $wpdb->num_rows;
                    
$resultado29_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_8 = $wpdb->num_rows;
                    
$resultado29_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_9 = $wpdb->num_rows;
                    
$resultado29_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_10 = $wpdb->num_rows;
                    
$resultado29_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_11 = $wpdb->num_rows;
                    
$resultado29_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_12 = $wpdb->num_rows;
                    
$resultado29_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_13 = $wpdb->num_rows;
                    
$resultado29_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_14 = $wpdb->num_rows;
                    
$resultado29_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_15 = $wpdb->num_rows;
                    
$resultado29_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_16 = $wpdb->num_rows;
                    
$resultado29_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_17 = $wpdb->num_rows;
                    
$resultado29_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_18 = $wpdb->num_rows;

          /////////////////////////////////DIA 7//////////////////////////////////////

$resultado30_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_1 = $wpdb->num_rows;
          

$resultado30_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_2 = $wpdb->num_rows;
                    
          
$resultado30_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_3 = $wpdb->num_rows;
                    
$resultado30_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_4 = $wpdb->num_rows;
                    
$resultado30_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_5 = $wpdb->num_rows;
                    
$resultado30_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_6 = $wpdb->num_rows;
                    
$resultado30_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_7 = $wpdb->num_rows;
                    
$resultado30_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_8 = $wpdb->num_rows;
                    
$resultado30_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_9 = $wpdb->num_rows;
                    
$resultado30_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_10 = $wpdb->num_rows;
                    
$resultado30_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_11 = $wpdb->num_rows;
                    
$resultado30_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_12 = $wpdb->num_rows;
                    
$resultado30_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_13 = $wpdb->num_rows;
                    
$resultado30_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_14 = $wpdb->num_rows;
                    
$resultado30_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_15 = $wpdb->num_rows;
                    
$resultado30_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_16 = $wpdb->num_rows;
                    
$resultado30_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_17 = $wpdb->num_rows;
                    
$resultado30_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_18 = $wpdb->num_rows;

/////////////////////////////////DIA 8//////////////////////////////////////

$resultado31_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_1 = $wpdb->num_rows;
          

$resultado31_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_2 = $wpdb->num_rows;
                    
          
$resultado31_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_3 = $wpdb->num_rows;
                    
$resultado31_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_4 = $wpdb->num_rows;
                    
$resultado31_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_5 = $wpdb->num_rows;
                    
$resultado31_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_6 = $wpdb->num_rows;
                    
$resultado31_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_7 = $wpdb->num_rows;
                    
$resultado31_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_8 = $wpdb->num_rows;
                    
$resultado31_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_9 = $wpdb->num_rows;
                    
$resultado31_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_10 = $wpdb->num_rows;
                    
$resultado31_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_11 = $wpdb->num_rows;
                    
$resultado31_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_12 = $wpdb->num_rows;
                    
$resultado31_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_13 = $wpdb->num_rows;
                    
$resultado31_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_14 = $wpdb->num_rows;
                    
$resultado31_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_15 = $wpdb->num_rows;
                    
$resultado31_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_16 = $wpdb->num_rows;
                    
$resultado31_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_17 = $wpdb->num_rows;
                    
$resultado31_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_18 = $wpdb->num_rows;


          /////////////////////////////////DIA 9//////////////////////////////////////

$resultado32_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$contador32_' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_1 = $wpdb->num_rows;
          

$resultado32_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_2 = $wpdb->num_rows;
                    
          
$resultado32_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_3 = $wpdb->num_rows;
                    
$resultado32_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_4 = $wpdb->num_rows;
                    
$resultado32_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_5 = $wpdb->num_rows;
                    
$resultado32_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_6 = $wpdb->num_rows;
                    
$resultado32_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_7 = $wpdb->num_rows;
                    
$resultado32_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_8 = $wpdb->num_rows;
                    
$resultado32_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_9 = $wpdb->num_rows;
                    
$resultado32_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_10 = $wpdb->num_rows;
                    
$resultado32_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_11 = $wpdb->num_rows;
                    
$resultado32_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_12 = $wpdb->num_rows;
                    
$resultado32_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_13 = $wpdb->num_rows;
                    
$resultado32_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_14 = $wpdb->num_rows;
                    
$resultado32_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_15 = $wpdb->num_rows;
                    
$resultado32_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_16 = $wpdb->num_rows;
                    
$resultado32_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_17 = $wpdb->num_rows;
                    
$resultado32_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_18 = $wpdb->num_rows;

            /////////////////////////////////DIA 10//////////////////////////////////////

$resultado33_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_1 = $wpdb->num_rows;
          

$resultado33_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_2 = $wpdb->num_rows;
                    
          
$resultado33_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_3 = $wpdb->num_rows;
                    
$resultado33_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_4 = $wpdb->num_rows;
                    
$resultado33_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_5 = $wpdb->num_rows;
                    
$resultado33_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_6 = $wpdb->num_rows;
                    
$resultado33_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_7 = $wpdb->num_rows;
                    
$resultado33_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_8 = $wpdb->num_rows;
                    
$resultado33_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_9 = $wpdb->num_rows;
                    
$resultado33_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_10 = $wpdb->num_rows;
                    
$resultado33_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_11 = $wpdb->num_rows;
                    
$resultado33_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_12 = $wpdb->num_rows;
                    
$resultado33_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_13 = $wpdb->num_rows;
                    
$resultado33_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_14 = $wpdb->num_rows;
                    
$resultado33_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_15 = $wpdb->num_rows;
                    
$resultado33_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_16 = $wpdb->num_rows;
                    
$resultado33_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_17 = $wpdb->num_rows;
                    
$resultado33_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_18 = $wpdb->num_rows;

            /////////////////////////////////DIA 11//////////////////////////////////////


$resultado34_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_1 = $wpdb->num_rows;
          

$resultado34_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_2 = $wpdb->num_rows;
                    
          
$resultado34_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_3 = $wpdb->num_rows;
                    
$resultado34_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_4 = $wpdb->num_rows;
                    
$resultado34_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_5 = $wpdb->num_rows;
                    
$resultado34_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_6 = $wpdb->num_rows;
                    
$resultado34_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_7 = $wpdb->num_rows;
                    
$resultado34_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_8 = $wpdb->num_rows;
                    
$resultado34_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_9 = $wpdb->num_rows;
                    
$resultado34_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_10 = $wpdb->num_rows;
                    
$resultado34_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_11 = $wpdb->num_rows;
                    
$resultado34_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_12 = $wpdb->num_rows;
                    
$resultado34_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_13 = $wpdb->num_rows;
                    
$resultado34_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_14 = $wpdb->num_rows;
                    
$resultado34_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_15 = $wpdb->num_rows;
                    
$resultado34_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_16 = $wpdb->num_rows;
                    
$resultado34_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_17 = $wpdb->num_rows;
                    
$resultado34_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_18 = $wpdb->num_rows;

          /////////////////////////////////DIA 12//////////////////////////////////////


$resultado35_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_1 = $wpdb->num_rows;
          

$resultado35_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_2 = $wpdb->num_rows;
                    
          
$resultado35_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_3 = $wpdb->num_rows;
                    
$resultado35_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_4 = $wpdb->num_rows;
                    
$resultado35_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_5 = $wpdb->num_rows;
                    
$resultado35_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_6 = $wpdb->num_rows;
                    
$resultado35_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_7 = $wpdb->num_rows;
                    
$resultado35_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_8 = $wpdb->num_rows;
                    
$resultado35_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_9 = $wpdb->num_rows;
                    
$resultado35_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_10 = $wpdb->num_rows;
                    
$resultado35_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_11 = $wpdb->num_rows;
                    
$resultado35_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_12 = $wpdb->num_rows;
                    
$resultado35_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_13 = $wpdb->num_rows;
                    
$resultado35_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_14 = $wpdb->num_rows;
                    
$resultado35_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_15 = $wpdb->num_rows;
                    
$resultado35_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_16 = $wpdb->num_rows;
                    
$resultado35_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_17 = $wpdb->num_rows;
                    
$resultado35_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_18 = $wpdb->num_rows;

          /////////////////////////////////DIA 13//////////////////////////////////////

$resultado36_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_1 = $wpdb->num_rows;
          

$resultado36_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_2 = $wpdb->num_rows;
                    
          
$resultado36_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_3 = $wpdb->num_rows;
                    
$resultado36_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_4 = $wpdb->num_rows;
                    
$resultado36_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_5 = $wpdb->num_rows;
                    
$resultado36_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_6 = $wpdb->num_rows;
                    
$resultado36_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_7 = $wpdb->num_rows;
                    
$resultado36_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_8 = $wpdb->num_rows;
                    
$resultado36_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_9 = $wpdb->num_rows;
                    
$resultado36_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_10 = $wpdb->num_rows;
                    
$resultado36_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_11 = $wpdb->num_rows;
                    
$resultado36_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_12 = $wpdb->num_rows;
                    
$resultado36_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_13 = $wpdb->num_rows;
                    
$resultado36_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_14 = $wpdb->num_rows;
                    
$resultado36_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_15 = $wpdb->num_rows;
                    
$resultado36_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_16 = $wpdb->num_rows;
                    
$resultado36_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_17 = $wpdb->num_rows;
                    
$resultado36_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_18 = $wpdb->num_rows;

 /////////////////////////////////DIA 14//////////////////////////////////////

 $resultado37_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_1 = $wpdb->num_rows;
           
 
 $resultado37_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_2 = $wpdb->num_rows;
                     
           
 $resultado37_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_3 = $wpdb->num_rows;
                     
 $resultado37_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_4 = $wpdb->num_rows;
                     
 $resultado37_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_5 = $wpdb->num_rows;
                     
 $resultado37_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_6 = $wpdb->num_rows;
                     
 $resultado37_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_7 = $wpdb->num_rows;
                     
 $resultado37_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_8 = $wpdb->num_rows;
                     
 $resultado37_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_9 = $wpdb->num_rows;
                     
 $resultado37_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_10 = $wpdb->num_rows;
                     
 $resultado37_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_11 = $wpdb->num_rows;
                     
 $resultado37_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_12 = $wpdb->num_rows;
                     
 $resultado37_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_13 = $wpdb->num_rows;
                     
 $resultado37_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_14 = $wpdb->num_rows;
                     
 $resultado37_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_15 = $wpdb->num_rows;
                     
 $resultado37_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_16 = $wpdb->num_rows;
                     
 $resultado37_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_17 = $wpdb->num_rows;
                     
 $resultado37_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
 $contador37_18 = $wpdb->num_rows;
 
          /////////////////////////////////DIA 15//////////////////////////////////////


$resultado38_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_1 = $wpdb->num_rows;
          

$resultado38_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_2 = $wpdb->num_rows;
                    
          
$resultado38_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_3 = $wpdb->num_rows;
                    
$resultado38_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_4 = $wpdb->num_rows;
                    
$resultado38_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_5 = $wpdb->num_rows;
                    
$resultado38_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_6 = $wpdb->num_rows;
                    
$resultado38_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_7 = $wpdb->num_rows;
                    
$resultado38_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_8 = $wpdb->num_rows;
                    
$resultado38_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_9 = $wpdb->num_rows;
                    
$resultado38_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_10 = $wpdb->num_rows;
                    
$resultado38_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_11 = $wpdb->num_rows;
                    
$resultado38_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_12 = $wpdb->num_rows;
                    
$resultado38_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_13 = $wpdb->num_rows;
                    
$resultado38_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_14 = $wpdb->num_rows;
                    
$resultado38_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_15 = $wpdb->num_rows;
                    
$resultado38_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_16 = $wpdb->num_rows;
                    
$resultado38_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_17 = $wpdb->num_rows;
                    
$resultado38_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_18 = $wpdb->num_rows;


          /////////////////////////////////DIA 16//////////////////////////////////////


$resultado39_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_1 = $wpdb->num_rows;
          

$resultado39_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_2 = $wpdb->num_rows;
                    
          
$resultado39_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_3 = $wpdb->num_rows;
                    
$resultado39_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_4 = $wpdb->num_rows;
                    
$resultado39_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_5 = $wpdb->num_rows;
                    
$resultado39_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_6 = $wpdb->num_rows;
                    
$resultado39_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_7 = $wpdb->num_rows;
                    
$resultado39_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_8 = $wpdb->num_rows;
                    
$resultado39_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_9 = $wpdb->num_rows;
                    
$resultado39_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_10 = $wpdb->num_rows;
                    
$resultado39_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_11 = $wpdb->num_rows;
                    
$resultado39_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_12 = $wpdb->num_rows;
                    
$resultado39_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_13 = $wpdb->num_rows;
                    
$resultado39_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_14 = $wpdb->num_rows;
                    
$resultado39_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_15 = $wpdb->num_rows;
                    
$resultado39_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_16 = $wpdb->num_rows;
                    
$resultado39_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_17 = $wpdb->num_rows;
                    
$resultado39_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_18 = $wpdb->num_rows;

          /////////////////////////////////DIA 17//////////////////////////////////////


$resultado40_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_1 = $wpdb->num_rows;
          

$resultado40_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_2 = $wpdb->num_rows;
                    
          
$resultado40_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_3 = $wpdb->num_rows;
                    
$resultado40_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_4 = $wpdb->num_rows;
                    
$resultado40_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_5 = $wpdb->num_rows;
                    
$resultado40_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_6 = $wpdb->num_rows;
                    
$resultado40_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_7 = $wpdb->num_rows;
                    
$resultado40_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_8 = $wpdb->num_rows;
                    
$resultado40_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_9 = $wpdb->num_rows;
                    
$resultado40_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_10 = $wpdb->num_rows;
                    
$resultado40_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_11 = $wpdb->num_rows;
                    
$resultado40_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_12 = $wpdb->num_rows;
                    
$resultado40_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_13 = $wpdb->num_rows;
                    
$resultado40_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_14 = $wpdb->num_rows;
                    
$resultado40_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_15 = $wpdb->num_rows;
                    
$resultado40_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_16 = $wpdb->num_rows;
                    
$resultado40_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_17 = $wpdb->num_rows;
                    
$resultado40_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_18 = $wpdb->num_rows;


          /////////////////////////////////DIA 18//////////////////////////////////////

$resultado41_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_1 = $wpdb->num_rows;
          

$resultado41_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_2 = $wpdb->num_rows;
                    
          
$resultado41_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_3 = $wpdb->num_rows;
                    
$resultado41_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_4 = $wpdb->num_rows;
                    
$resultado41_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_5 = $wpdb->num_rows;
                    
$resultado41_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_6 = $wpdb->num_rows;
                    
$resultado41_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_7 = $wpdb->num_rows;
                    
$resultado41_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_8 = $wpdb->num_rows;
                    
$resultado41_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_9 = $wpdb->num_rows;
                    
$resultado41_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_10 = $wpdb->num_rows;
                    
$resultado41_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_11 = $wpdb->num_rows;
                    
$resultado41_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_12 = $wpdb->num_rows;
                    
$resultado41_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_13 = $wpdb->num_rows;
                    
$resultado41_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_14 = $wpdb->num_rows;
                    
$resultado41_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_15 = $wpdb->num_rows;
                    
$resultado41_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_16 = $wpdb->num_rows;
                    
$resultado41_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_17 = $wpdb->num_rows;
                    
$resultado41_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador41_18 = $wpdb->num_rows;

          /////////////////////////////////DIA 19//////////////////////////////////////

$resultado42_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_1 = $wpdb->num_rows;
          

$resultado42_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_2 = $wpdb->num_rows;
                    
          
$resultado42_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_3 = $wpdb->num_rows;
                    
$resultado42_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_4 = $wpdb->num_rows;
                    
$resultado42_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_5 = $wpdb->num_rows;
                    
$resultado42_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_6 = $wpdb->num_rows;
                    
$resultado42_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_7 = $wpdb->num_rows;
                    
$resultado42_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_8 = $wpdb->num_rows;
                    
$resultado42_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_9 = $wpdb->num_rows;
                    
$resultado42_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_10 = $wpdb->num_rows;
                    
$resultado42_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_11 = $wpdb->num_rows;
                    
$resultado42_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_12 = $wpdb->num_rows;
                    
$resultado42_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_13 = $wpdb->num_rows;
                    
$resultado42_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_14 = $wpdb->num_rows;
                    
$resultado42_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_15 = $wpdb->num_rows;
                    
$resultado42_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_16 = $wpdb->num_rows;
                    
$resultado42_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_17 = $wpdb->num_rows;
                    
$resultado42_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador42_18 = $wpdb->num_rows;

          /////////////////////////////////DIA 20//////////////////////////////////////

$resultado43_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_1 = $wpdb->num_rows;
          

$resultado43_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_2 = $wpdb->num_rows;
                    
          
$resultado43_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_3 = $wpdb->num_rows;
                    
$resultado43_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_4 = $wpdb->num_rows;
                    
$resultado43_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_5 = $wpdb->num_rows;
                    
$resultado43_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_6 = $wpdb->num_rows;
                    
$resultado43_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_7 = $wpdb->num_rows;
                    
$resultado43_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_8 = $wpdb->num_rows;
                    
$resultado43_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_9 = $wpdb->num_rows;
                    
$resultado43_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_10 = $wpdb->num_rows;
                    
$resultado43_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_11 = $wpdb->num_rows;
                    
$resultado43_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_12 = $wpdb->num_rows;
                    
$resultado43_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_13 = $wpdb->num_rows;
                    
$resultado43_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_14 = $wpdb->num_rows;
                    
$resultado43_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_15 = $wpdb->num_rows;
                    
$resultado43_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_16 = $wpdb->num_rows;
                    
$resultado43_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_17 = $wpdb->num_rows;
                    
$resultado43_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador43_18 = $wpdb->num_rows;

          /////////////////////////////////DIA 21//////////////////////////////////////


$resultado44_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_1 = $wpdb->num_rows;
          

$resultado44_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_2 = $wpdb->num_rows;
                    
          
$resultado44_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_3 = $wpdb->num_rows;
                    
$resultado44_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_4 = $wpdb->num_rows;
                    
$resultado44_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_5 = $wpdb->num_rows;
                    
$resultado44_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_6 = $wpdb->num_rows;
                    
$resultado44_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_7 = $wpdb->num_rows;
                    
$resultado44_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_8 = $wpdb->num_rows;
                    
$resultado44_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_9 = $wpdb->num_rows;
                    
$resultado44_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_10 = $wpdb->num_rows;
                    
$resultado44_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_11 = $wpdb->num_rows;
                    
$resultado44_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_12 = $wpdb->num_rows;
                    
$resultado44_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_13 = $wpdb->num_rows;
                    
$resultado44_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_14 = $wpdb->num_rows;
                    
$resultado44_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_15 = $wpdb->num_rows;
                    
$resultado44_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_16 = $wpdb->num_rows;
                    
$resultado44_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_17 = $wpdb->num_rows;
                    
$resultado44_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador44_18 = $wpdb->num_rows;
          /////////////////////////////////DIA 22//////////////////////////////////////


$resultado45_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_1 = $wpdb->num_rows;
          

$resultado45_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_2 = $wpdb->num_rows;
                    
          
$resultado45_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_3 = $wpdb->num_rows;
                    
$resultado45_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_4 = $wpdb->num_rows;
                    
$resultado45_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_5 = $wpdb->num_rows;
                    
$resultado45_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_6 = $wpdb->num_rows;
                    
$resultado45_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_7 = $wpdb->num_rows;
                    
$resultado45_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_8 = $wpdb->num_rows;
                    
$resultado45_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_9 = $wpdb->num_rows;
                    
$resultado45_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_10 = $wpdb->num_rows;
                    
$resultado45_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_11 = $wpdb->num_rows;
                    
$resultado45_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_12 = $wpdb->num_rows;
                    
$resultado45_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_13 = $wpdb->num_rows;
                    
$resultado45_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_14 = $wpdb->num_rows;
                    
$resultado45_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_15 = $wpdb->num_rows;
                    
$resultado45_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_16 = $wpdb->num_rows;
                    
$resultado45_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_17 = $wpdb->num_rows;
                    
$resultado45_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador45_18 = $wpdb->num_rows;

          /////////////////////////////////DIA 23//////////////////////////////////////



$resultado46_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_1 = $wpdb->num_rows;
          

$resultado46_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_2 = $wpdb->num_rows;
                    
          
$resultado46_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_3 = $wpdb->num_rows;
                    
$resultado46_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_4 = $wpdb->num_rows;
                    
$resultado46_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_5 = $wpdb->num_rows;
                    
$resultado46_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_6 = $wpdb->num_rows;
                    
$resultado46_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_7 = $wpdb->num_rows;
                    
$resultado46_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_8 = $wpdb->num_rows;
                    
$resultado46_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_9 = $wpdb->num_rows;
                    
$resultado46_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_10 = $wpdb->num_rows;
                    
$resultado46_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_11 = $wpdb->num_rows;
                    
$resultado46_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_12 = $wpdb->num_rows;
                    
$resultado46_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_13 = $wpdb->num_rows;
                    
$resultado46_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_14 = $wpdb->num_rows;
                    
$resultado46_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_15 = $wpdb->num_rows;
                    
$resultado46_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_16 = $wpdb->num_rows;
                    
$resultado46_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_17 = $wpdb->num_rows;
                    
$resultado46_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador46_18 = $wpdb->num_rows;


          /////////////////////////////////DIA 24//////////////////////////////////////

$resultado47_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_1 = $wpdb->num_rows;
          

$resultado47_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_2 = $wpdb->num_rows;
                    
          
$resultado47_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_3 = $wpdb->num_rows;
                    
$resultado47_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_4 = $wpdb->num_rows;
                    
$resultado47_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_5 = $wpdb->num_rows;
                    
$resultado47_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_6 = $wpdb->num_rows;
                    
$resultado47_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_7 = $wpdb->num_rows;
                    
$resultado47_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_8 = $wpdb->num_rows;
                    
$resultado47_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_9 = $wpdb->num_rows;
                    
$resultado47_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_10 = $wpdb->num_rows;
                    
$resultado47_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_11 = $wpdb->num_rows;
                    
$resultado47_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_12 = $wpdb->num_rows;
                    
$resultado47_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_13 = $wpdb->num_rows;
                    
$resultado47_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_14 = $wpdb->num_rows;
                    
$resultado47_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_15 = $wpdb->num_rows;
                    
$resultado47_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_16 = $wpdb->num_rows;
                    
$resultado47_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_17 = $wpdb->num_rows;
                    
$resultado47_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador47_18 = $wpdb->num_rows;

          /////////////////////////////////DIA 25//////////////////////////////////////

$resultado48_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_1 = $wpdb->num_rows;
          

$resultado48_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_2 = $wpdb->num_rows;
                    
          
$resultado48_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_3 = $wpdb->num_rows;
                    
$resultado48_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_4 = $wpdb->num_rows;
                    
$resultado48_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_5 = $wpdb->num_rows;
                    
$resultado48_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_6 = $wpdb->num_rows;
                    
$resultado48_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_7 = $wpdb->num_rows;
                    
$resultado48_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_8 = $wpdb->num_rows;
                    
$resultado48_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_9 = $wpdb->num_rows;
                    
$resultado48_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_10 = $wpdb->num_rows;
                    
$resultado48_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_11 = $wpdb->num_rows;
                    
$resultado48_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_12 = $wpdb->num_rows;
                    
$resultado48_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_13 = $wpdb->num_rows;
                    
$resultado48_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_14 = $wpdb->num_rows;
                    
$resultado48_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_15 = $wpdb->num_rows;
                    
$resultado48_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_16 = $wpdb->num_rows;
                    
$resultado48_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_17 = $wpdb->num_rows;
                    
$resultado48_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador48_18 = $wpdb->num_rows;

          /////////////////////////////////DIA 26//////////////////////////////////////

$resultado49_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_1 = $wpdb->num_rows;
          

$resultado49_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_2 = $wpdb->num_rows;
                    
          
$resultado49_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_3 = $wpdb->num_rows;
                    
$resultado49_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_4 = $wpdb->num_rows;
                    
$resultado49_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_5 = $wpdb->num_rows;
                    
$resultado49_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_6 = $wpdb->num_rows;
                    
$resultado49_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_7 = $wpdb->num_rows;
                    
$resultado49_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_8 = $wpdb->num_rows;
                    
$resultado49_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_9 = $wpdb->num_rows;
                    
$resultado49_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_10 = $wpdb->num_rows;
                    
$resultado49_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_11 = $wpdb->num_rows;
                    
$resultado49_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_12 = $wpdb->num_rows;
                    
$resultado49_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_13 = $wpdb->num_rows;
                    
$resultado49_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_14 = $wpdb->num_rows;
                    
$resultado49_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_15 = $wpdb->num_rows;
                    
$resultado49_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_16 = $wpdb->num_rows;
                    
$resultado49_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_17 = $wpdb->num_rows;
                    
$resultado49_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador49_18 = $wpdb->num_rows;
 
          /////////////////////////////////DIA 27//////////////////////////////////////

$resultado50_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_1 = $wpdb->num_rows;
          

$resultado50_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_2 = $wpdb->num_rows;
                    
          
$resultado50_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_3 = $wpdb->num_rows;
                    
$resultado50_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_4 = $wpdb->num_rows;
                    
$resultado50_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_5 = $wpdb->num_rows;
                    
$resultado50_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_6 = $wpdb->num_rows;
                    
$resultado50_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_7 = $wpdb->num_rows;
                    
$resultado50_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_8 = $wpdb->num_rows;
                    
$resultado50_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_9 = $wpdb->num_rows;
                    
$resultado50_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_10 = $wpdb->num_rows;
                    
$resultado50_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_11 = $wpdb->num_rows;
                    
$resultado50_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_12 = $wpdb->num_rows;
                    
$resultado50_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_13 = $wpdb->num_rows;
                    
$resultado50_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_14 = $wpdb->num_rows;
                    
$resultado50_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_15 = $wpdb->num_rows;
                    
$resultado50_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_16 = $wpdb->num_rows;
                    
$resultado50_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_17 = $wpdb->num_rows;
                    
$resultado50_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador50_18 = $wpdb->num_rows;

/////////////////////////////////DIA 28//////////////////////////////////////


$resultado51_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_1 = $wpdb->num_rows;
          

$resultado51_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_2 = $wpdb->num_rows;
                    
          
$resultado51_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_3 = $wpdb->num_rows;
                    
$resultado51_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_4 = $wpdb->num_rows;
                    
$resultado51_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_5 = $wpdb->num_rows;
                    
$resultado51_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_6 = $wpdb->num_rows;
                    
$resultado51_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_7 = $wpdb->num_rows;
                    
$resultado51_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_8 = $wpdb->num_rows;
                    
$resultado51_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_9 = $wpdb->num_rows;
                    
$resultado51_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_10 = $wpdb->num_rows;
                    
$resultado51_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_11 = $wpdb->num_rows;
                    
$resultado51_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_12 = $wpdb->num_rows;
                    
$resultado51_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_13 = $wpdb->num_rows;
                    
$resultado51_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_14 = $wpdb->num_rows;
                    
$resultado51_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_15 = $wpdb->num_rows;
                    
$resultado51_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_16 = $wpdb->num_rows;
                    
$resultado51_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_17 = $wpdb->num_rows;
                    
$resultado51_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador51_18 = $wpdb->num_rows;

          /////////////////////////////////DIA 29//////////////////////////////////////

$resultado52_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_1 = $wpdb->num_rows;
          

$resultado52_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_2 = $wpdb->num_rows;
                    
          
$resultado52_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_3 = $wpdb->num_rows;
                    
$resultado52_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_4 = $wpdb->num_rows;
                    
$resultado52_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_5 = $wpdb->num_rows;
                    
$resultado52_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_6 = $wpdb->num_rows;
                    
$resultado52_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_7 = $wpdb->num_rows;
                    
$resultado52_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_8 = $wpdb->num_rows;
                    
$resultado52_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_9 = $wpdb->num_rows;
                    
$resultado52_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_10 = $wpdb->num_rows;
                    
$resultado52_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_11 = $wpdb->num_rows;
                    
$resultado52_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_12 = $wpdb->num_rows;
                    
$resultado52_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_13 = $wpdb->num_rows;
                    
$resultado52_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_14 = $wpdb->num_rows;
                    
$resultado52_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_15 = $wpdb->num_rows;
                    
$resultado52_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_16 = $wpdb->num_rows;
                    
$resultado52_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_17 = $wpdb->num_rows;
                    
$resultado52_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador52_18 = $wpdb->num_rows;

          /////////////////////////////////DIA 30//////////////////////////////////////

$resultado53_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_1 = $wpdb->num_rows;
          

$resultado53_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_2 = $wpdb->num_rows;
                    
          
$resultado53_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_3 = $wpdb->num_rows;
                    
$resultado53_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_4 = $wpdb->num_rows;
                    
$resultado53_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_5 = $wpdb->num_rows;
                    
$resultado53_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_6 = $wpdb->num_rows;
                    
$resultado53_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_7 = $wpdb->num_rows;
                    
$resultado53_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_8 = $wpdb->num_rows;
                    
$resultado53_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_9 = $wpdb->num_rows;
                    
$resultado53_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_10 = $wpdb->num_rows;
                    
$resultado53_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_11 = $wpdb->num_rows;
                    
$resultado53_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_12 = $wpdb->num_rows;
                    
$resultado53_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_13 = $wpdb->num_rows;
                    
$resultado53_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_14 = $wpdb->num_rows;
                    
$resultado53_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_15 = $wpdb->num_rows;
                    
$resultado53_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_16 = $wpdb->num_rows;
                    
$resultado53_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_17 = $wpdb->num_rows;
                    
$resultado53_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador53_18 = $wpdb->num_rows;
          /////////////////////////////////DIA 31//////////////////////////////////////

$resultado54_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_1 = $wpdb->num_rows;
          

$resultado54_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_2 = $wpdb->num_rows;
                    
          
$resultado54_3 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_3 = $wpdb->num_rows;
                    
$resultado54_4 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '4' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_4 = $wpdb->num_rows;
                    
$resultado54_5 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '5' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_5 = $wpdb->num_rows;
                    
$resultado54_6 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '6' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_6 = $wpdb->num_rows;
                    
$resultado54_7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '7' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_7 = $wpdb->num_rows;
                    
$resultado54_8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '8' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_8 = $wpdb->num_rows;
                    
$resultado54_9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '9' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_9 = $wpdb->num_rows;
                    
$resultado54_10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '10' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_10 = $wpdb->num_rows;
                    
$resultado54_11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '11' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_11 = $wpdb->num_rows;
                    
$resultado54_12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '12' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_12 = $wpdb->num_rows;
                    
$resultado54_13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '13' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_13 = $wpdb->num_rows;
                    
$resultado54_14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '14' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_14 = $wpdb->num_rows;
                    
$resultado54_15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '15' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_15 = $wpdb->num_rows;
                    
$resultado54_16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '16' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_16 = $wpdb->num_rows;
                    
$resultado54_17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '17' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_17 = $wpdb->num_rows;
                    
$resultado54_18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_productos = '18' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador54_18 = $wpdb->num_rows;



  $dias1 = $contador24_1 + $contador24_2 + $contador24_3 + $contador24_4 + $contador24_5 + $contador24_6 + $contador24_7 + $contador24_8 + $contador24_9 + $contador24_10 + $contador24_11 + $contador24_12 + $contador24_13 + $contador24_14 + $contador24_15 + $contador24_16 + $contador24_17+ $contador24_18;

   $dias2 = $contador25_1 + $contador25_2 + $contador25_3 + $contador25_4 + $contador25_5 + $contador25_6 + $contador25_7 + $contador25_8 + $contador25_9 + $contador25_10 + $contador25_11 + $contador25_12 + $contador25_13 + $contador25_14 + $contador25_15 + $contador25_16 + $contador25_17 + $contador25_18;

  $dias3 = $contador26_1 + $contador26_2 + $contador26_3 + $contador26_4 + $contador26_5 + $contador26_6 + $contador26_7 + $contador26_8 + $contador26_9 + $contador26_10 + $contador26_11 + $contador26_12 + $contador26_13 + $contador26_14 + $contador26_15 + $contador26_16 + $contador26_17 + $contador26_18;

  $dias4 = $contador27_1 + $contador27_2 + $contador27_3 + $contador27_4 + $contador27_5 + $contador27_6 + $contador27_7 + $contador27_8 + $contador27_9 + $contador27_10 + $contador27_11 + $contador27_12 + $contador27_13 + $contador27_14 + $contador27_15 + $contador27_16 + $contador27_17 + $contador27_18;

  $dias5 = $contador28_1 + $contador28_2 + $contador28_3 + $contador28_4 + $contador28_5 + $contador28_6 + $contador28_7 + $contador28_8 + $contador28_9 + $contador28_10 + $contador28_11 + $contador28_12 + $contador28_13 + $contador28_14 + $contador28_15 + $contador28_16 + $contador28_17 + $contador28_18;

  $dias6 = $contador29_1 + $contador29_2 + $contador29_3 + $contador29_4 + $contador29_5 + $contador29_6 + $contador29_7 + $contador29_8 + $contador29_9 + $contador29_10 + $contador29_11 + $contador29_12 + $contador29_13 + $contador29_14 + $contador29_15 + $contador29_16 + $contador29_17 + $contador29_18;

  $dias7 = $contador30_1 + $contador30_2 + $contador30_3 + $contador30_4 + $contador30_5 + $contador30_6 + $contador30_7 + $contador30_8 + $contador30_9 + $contador30_10 + $contador30_11 + $contador30_12 + $contador30_13 + $contador30_14 + $contador30_15 + $contador30_16 + $contador30_17 + $contador30_18;

  $dias8 = $contador31_1 + $contador31_2 + $contador31_3 + $contador31_4 + $contador31_5 + $contador31_6 + $contador31_7 + $contador31_8 + $contador31_9 + $contador31_10 + $contador31_11 + $contador31_12 + $contador31_13 + $contador31_14 + $contador31_15 + $contador31_16 + $contador31_17 + $contador31_18;

  $dias9 = $contador32_1 + $contador32_2 + $contador32_3 + $contador32_4 + $contador32_5 + $contador32_6 + $contador32_7 + $contador32_8 + $contador32_9 + $contador32_10 + $contador32_11 + $contador32_12 + $contador32_13 + $contador32_14 + $contador32_15 + $contador32_16 + $contador32_17 + $contador32_18;

  $dias10 = $contador33_1 + $contador33_2 + $contador33_3 + $contador33_4 + $contador33_5 + $contador33_6 + $contador33_7 + $contador33_8 + $contador33_9 + $contador33_10 + $contador33_11 + $contador33_12 + $contador33_13 + $contador33_14 + $contador33_15 + $contador33_16 + $contador33_17 + $contador33_18;

  $dias11 = $contador34_1 + $contador34_2 + $contador34_3 + $contador34_4 + $contador34_5 + $contador34_6 + $contador34_7 + $contador34_8 + $contador34_9 + $contador34_10 + $contador34_11 + $contador34_12 + $contador34_13 + $contador34_14 + $contador34_15 + $contador34_16 + $contador34_17 + $contador34_18;

  $dias12 = $contador35_1 + $contador35_2 + $contador35_3 + $contador35_4 + $contador35_5 + $contador35_6 + $contador35_7 + $contador35_8 + $contador35_9 + $contador35_10 + $contador35_11 + $contador35_12 + $contador35_13 + $contador35_14 + $contador35_15 + $contador35_16 + $contador35_17 + $contador35_18;

  $dias13 = $contador36_1 + $contador36_2 + $contador36_3 + $contador36_4 + $contador36_5 + $contador36_6 + $contador36_7 + $contador36_8 + $contador36_9 + $contador36_10 + $contador36_11 + $contador36_12 + $contador36_13 + $contador36_14 + $contador36_15 + $contador36_16 + $contador36_17 + $contador36_18;

  $dias14 = $contador37_1 + $contador37_2 + $contador37_3 + $contador37_4 + $contador37_5 + $contador37_6 + $contador37_7 + $contador37_8 + $contador37_9 + $contador37_10 + $contador37_11 + $contador37_12 + $contador37_13 + $contador37_14 + $contador37_15 + $contador37_16 + $contador37_17 + $contador37_18;

  $dias15 = $contador38_1 + $contador38_2 + $contador38_3 + $contador38_4 + $contador38_5 + $contador38_6 + $contador38_7 + $contador38_8 + $contador38_9 + $contador38_10 + $contador38_11 + $contador38_12 + $contador38_13 + $contador38_14 + $contador38_15 + $contador38_16 + $contador38_17 + $contador38_18;

  $dias16 = $contador39_1 + $contador39_2 + $contador39_3 + $contador39_4 + $contador39_5 + $contador39_6 + $contador39_7 + $contador39_8 + $contador39_9 + $contador39_10 + $contador39_11 + $contador39_12 + $contador39_13 + $contador39_14 + $contador39_15 + $contador39_16 + $contador39_17 + $contador39_18;

  $dias17 = $contador40_1 + $contador40_2 + $contador40_3 + $contador40_4 + $contador40_5 + $contador40_6 + $contador40_7 + $contador40_8 + $contador40_9 + $contador40_10 + $contador40_11 + $contador40_12 + $contador40_13 + $contador40_14 + $contador40_15 + $contador40_16 + $contador40_17 + $contador40_18;

  $dias18 = $contador41_1 + $contador41_2 + $contador41_3 + $contador41_4 + $contador41_5 + $contador41_6 + $contador41_7 + $contador41_8 + $contador41_9 + $contador41_10 + $contador41_11 + $contador41_12 + $contador41_13 + $contador41_14 + $contador41_15 + $contador41_16 + $contador41_17 + $contador41_18;

  $dias19 = $contador42_1 + $contador42_2 + $contador42_3 + $contador42_4 + $contador42_5 + $contador42_6 + $contador42_7 + $contador42_8 + $contador42_9 + $contador42_10 + $contador42_11 + $contador42_12 + $contador42_13 + $contador42_14 + $contador42_15 + $contador42_16 + $contador42_17 + $contador42_18;

  $dias20 = $contador43_1 + $contador43_2 + $contador43_3 + $contador43_4 + $contador43_5 + $contador43_6 + $contador43_7 + $contador43_8 + $contador43_9 + $contador43_10 + $contador43_11 + $contador43_12 + $contador43_13 + $contador43_14 + $contador43_15 + $contador43_16 + $contador43_17 + $contador43_18;

  $dias21 = $contador44_1 + $contador44_2 + $contador44_3 + $contador44_4 + $contador44_5 + $contador44_6 + $contador44_7 + $contador44_8 + $contador44_9 + $contador44_10 + $contador44_11 + $contador44_12 + $contador44_13 + $contador44_14 + $contador44_15 + $contador44_16 + $contador44_17 + $contador44_18;

  $dias22 = $contador45_1 + $contador45_2 + $contador45_3 + $contador45_4 + $contador45_5 + $contador45_6 + $contador45_7 + $contador45_8 + $contador45_9 + $contador45_10 + $contador45_11 + $contador45_12 + $contador45_13 + $contador45_14 + $contador45_15 + $contador45_16 + $contador45_17 + $contador45_18;

  $dias23 = $contador46_1 + $contador46_2 + $contador46_3 + $contador46_4 + $contador46_5 + $contador46_6 + $contador46_7 + $contador46_8 + $contador46_9 + $contador46_10 + $contador46_11 + $contador46_12 + $contador46_13 + $contador46_14 + $contador46_15 + $contador46_16 + $contador46_17 + $contador46_18;

  $dias24 = $contador47_1 + $contador47_2 + $contador47_3 + $contador47_4 + $contador47_5 + $contador47_6 + $contador47_7 + $contador47_8 + $contador47_9 + $contador47_10 + $contador47_11 + $contador47_12 + $contador47_13 + $contador47_14 + $contador47_15 + $contador47_16 + $contador47_17 + $contador47_18;


  $dias25 = $contador48_1 + $contador48_2 + $contador48_3 + $contador48_4 + $contador48_5 + $contador48_6 + $contador48_7 + $contador48_8 + $contador48_9 + $contador48_10 + $contador48_11 + $contador48_12 + $contador48_13 + $contador48_14 + $contador48_15 + $contador48_16 + $contador48_17 + $contador48_18;

  $dias26 = $contador49_1 + $contador49_2 + $contador49_3 + $contador49_4 + $contador49_5 + $contador49_6 + $contador49_7 + $contador49_8 + $contador49_9 + $contador49_10 + $contador49_11 + $contador49_12 + $contador49_13 + $contador49_14 + $contador49_15 + $contador49_16 + $contador49_17 + $contador49_18;

  $dias27 = $contador50_1 + $contador50_2 + $contador50_3 + $contador50_4 + $contador50_5 + $contador50_6 + $contador50_7 + $contador50_8 + $contador50_9 + $contador50_10 + $contador50_11 + $contador50_12 + $contador50_13 + $contador50_14 + $contador50_15 + $contador50_16 + $contador50_17 + $contador50_18;

  $dias28 = $contador51_1 + $contador51_2 + $contador51_3 + $contador51_4 + $contador51_5 + $contador51_6 + $contador51_7 + $contador51_8 + $contador51_9 + $contador51_10 + $contador51_11 + $contador51_12 + $contador51_13 + $contador51_14 + $contador51_15 + $contador51_16 + $contador51_17 + $contador51_18;

  $dias29 = $contador52_1 + $contador52_2 + $contador52_3 + $contador52_4 + $contador52_5 + $contador52_6 + $contador52_7 + $contador52_8 + $contador52_9 + $contador52_10 + $contador52_11 + $contador52_12 + $contador52_13 + $contador52_14 + $contador52_15 + $contador52_16 + $contador52_17 + $contador52_18;

  $dias30 = $contador53_1 + $contador53_2 + $contador53_3 + $contador53_4 + $contador53_5 + $contador53_6 + $contador53_7 + $contador53_8 + $contador53_9 + $contador53_10 + $contador53_11 + $contador53_12 + $contador53_13 + $contador53_14 + $contador53_15 + $contador53_16 + $contador53_17 + $contador53_18;

  $dias31 = $contador54_1 + $contador54_2 + $contador54_3 + $contador54_4 + $contador54_5 + $contador54_6 + $contador54_7 + $contador54_8 + $contador54_9 + $contador54_10 + $contador54_11 + $contador54_12 + $contador54_13 + $contador54_14 + $contador54_15 + $contador54_16 + $contador54_17 + $contador54_18;


$suma_dias = $dias1 + $dias2 + $dias3 + $dias4 + $dias5 + $dias6 + $dias7 + $dias8 + $dias9 + $dias10 + $dias11 + $dias12 + $dias13 + $dias14 + $dias15 + $dias16 + $dias17 + $dias18 + $dias19 + $dias20 + $dias21 + $dias22 + $dias23 + $dias24 + $dias25 + $dias26 + $dias27 + $dias28 + $dias29 + $dias30 + $dias31;


$suma_hoy = $contador23_1 + $contador23_2 + $contador23_3 + $contador23_4 + $contador23_5 + $contador23_6 + $contador23_7 + $contador23_8 + $contador23_9 + $contador23_10 + $contador23_11 + $contador23_12 + $contador23_13 + $contador23_14 + $contador23_15 + $contador23_16 + $contador23_17;

?>


<div class="mdl-grid">
                                        <div class="mdl-cell mdl-cell--12-col">
                                          
                                        </div>



    <br/><br/>
    <br/><br/>
    <div class="line-chart-area">
        <div class="container">
            <div class="row">





                                        
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="width: 15%;">
                            <div class="line-chart-wp chart-display-nn" style="border-radius: 15px 15px 15px 15px;-moz-border-radius: 15px 15px 15px 15px;-webkit-border-radius: 15px 15px 15px 15px;border: 1px solid #ff0066;background: #ff0066;color: #ffffff;text-align: center;font-size: 13px;">
                                 
                                Total Ventas MES <div style="font-size: 18px;">

                                <?php
                                    echo $suma_dias;
                                                                           
                                ?>

                                </div>
                                           
                            </div>
                    </div>


                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="width: 15%;">
                      <div class="line-chart-wp chart-display-nn" style="border-radius: 15px 15px 15px 15px;-moz-border-radius: 15px 15px 15px 15px;-webkit-border-radius: 15px 15px 15px 15px;border: 1px solid #FFFFFF;background: #FFFFFF;color: #ffffff;text-align: center;font-size: 13px;color: #FFFFFF">
                         
                        Global Ventas <div style="font-size: 18px;">
                            

                            </div>
                                   
                        </div>
                    </div>


                                        
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="width: 15%;">
                      <div class="line-chart-wp chart-display-nn" style="border-radius: 15px 15px 15px 15px;-moz-border-radius: 15px 15px 15px 15px;-webkit-border-radius: 15px 15px 15px 15px;border: 1px solid #FFFFFF;background: #FFFFFF;color: #ffffff;text-align: center;font-size: 13px;color: #FFFFFF">
                         
                        Global Ventas <div style="font-size: 18px;">
                            

                            </div>
                                   
                        </div>
                    </div>


                    

                                        
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="width: 15%;">
                      <div class="line-chart-wp chart-display-nn" style="border-radius: 15px 15px 15px 15px;-moz-border-radius: 15px 15px 15px 15px;-webkit-border-radius: 15px 15px 15px 15px;border: 1px solid #FFFFFF;background: #FFFFFF;color: #ffffff;text-align: center;font-size: 13px;color: #FFFFFF">
                         
                        Global Ventas <div style="font-size: 18px;">
                            

                            </div>
                                   
                        </div>
                    </div>

                                        
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="width: 15%;">
                      <div class="line-chart-wp chart-display-nn" style="border-radius: 15px 15px 15px 15px;-moz-border-radius: 15px 15px 15px 15px;-webkit-border-radius: 15px 15px 15px 15px;border: 1px solid #FFFFFF;background: #FFFFFF;color: #ffffff;text-align: center;font-size: 13px;color: #FFFFFF">
                         
                        Global Ventas <div style="font-size: 18px;">
                            

                            </div>
                                   
                        </div>
                    </div>


                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="width: 15%;">
                            <div class="line-chart-wp chart-display-nn" style="border-radius: 15px 15px 15px 15px;-moz-border-radius: 15px 15px 15px 15px;-webkit-border-radius: 15px 15px 15px 15px;border: 1px solid #ff0066;background: #ff0066;color: #ffffff;text-align: center;font-size: 13px;">
                                 
                                Total Ventas HOY <div style="font-size: 18px;">
                                    <?php

                                    echo $suma_hoy;
                                        
                                    ?>

                                </div>
                                           
                            </div>
                    </div>





            </div>
    </div>
                      




    <!-- Bar Chart area End-->
    <div class="line-chart-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: center;">
                    <div class="line-chart-wp chart-display-nn">

                      <script type="text/javascript">
                            var ctx = document.getElementById("barchart22");
                            var barchart22 = new Chart(ctx, {
                              type: 'pie',
                              data: {
                                labels: ["SPP PLUS","SPP AUTONOMO","API - ASISTENCIA PYMES","UUEE - URGENCIAS ELECTRICAS","FE - FACTURA ELECTRONICA","CF - CUOTA FIJA","PMG - PACK MANTENIMIENTO GAS","AECC - ASOCIACION CONTRA EL CANCER","SPH+ PROTECCION ELECTRICA HOGAR PLUS","SPC - SERVICIO PROTECCION CLIMATIZACION","SPE - SERVICIO PROTECCION ELECTRODOMESTICOS","SPEH - SERVICIO PROTECCION ELECTRICA HOGAR","AG - ASISTENCIA GAS","PG - PROTECCION GAS","SMART HOME","SMART MOBILITY","OTROS PRODUCTOS","ASISTENTE SMART"],
                                datasets: [{
                                  label: 'Ventas diarias por producto',
                                  data: [<?php echo $contador7; ?>,<?php echo $contador8; ?>,<?php echo $contador9; ?>,<?php echo $contador10; ?>,<?php echo $contador11; ?>,<?php echo $contador12; ?>,<?php echo $contador13; ?>,<?php echo $contador14; ?>,<?php echo $contador15; ?>,<?php echo $contador16; ?>,<?php echo $contador17; ?>,<?php echo $contador18; ?>,<?php echo $contador19; ?>,<?php echo $contador20; ?>,<?php echo $contador21; ?>,<?php echo $contador22; ?>,<?php echo $contador23; ?>,<?php echo $contador24; ?>],
                                  backgroundColor: [
                                    '#E91E63',
                                    '#9C27B0',
                                    '#999999',
                                    '#3F51B5',
                                    '#0097A7',
                                    '#F9A825',
                                    '#F4511E',
                                    '#6D4C41',
                                    '#FF0099',
                                    '#117864',
                                    '#54C7C5',
                                    '#27AE60',
                                    '#ff0066',
                                    '#FFA726',
                                    '#42A5F5',
                                    '#827717',
                                    '#795548',
                                    '#ef6030',  

                                  ],
                                  borderColor: [
                                    '#ff0066'
                                  ],
                                  borderWidth: 1
                                }]
                              },
                              options: {
                                scales: {
                                  yAxes: [{
                                    ticks: {
                                      beginAtZero:true
                                    }
                                  }]
                                }
                              }
                            });
                      </script>
                        <div class="bar-chart-wp">
                        <canvas height="40vh" width="120vw" id="barchart22"></canvas>
                        
                                  
                    </div>
                </div>

            </div>
            
        </div>
    </div>
                      


<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="center: -60px;">
                    <div class="line-chart-wp sm-res-mg-t-30 chart-display-nn">
                        <script type="text/javascript">
                            var ctx = document.getElementById("barchart11");
                            var barchart11 = new Chart(ctx, {
                              type: 'bar',
                              data: {
                                labels: ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"],
                                datasets: [{
                                  label: 'Ventas diarias por producto',
                                  data: [<?php echo $dias1; ?>,<?php echo $dias2; ?>,<?php echo $dias3; ?>,<?php echo $dias4; ?>,<?php echo $dias5; ?>,<?php echo $dias6; ?>,<?php echo $dias7; ?>,<?php echo $dias8; ?>,<?php echo $dias9; ?>,<?php echo $dias10; ?>,<?php echo $dias11; ?>,<?php echo $dias12; ?>,<?php echo $dias13; ?>,<?php echo $dias14; ?>,<?php echo $dias15; ?>,<?php echo $dias16; ?>,<?php echo $dias17; ?>,<?php echo $dias18; ?>,<?php echo $dias19; ?>,<?php echo $dias20; ?>,<?php echo $dias21; ?>,<?php echo $dias22; ?>,<?php echo $dias23; ?>,<?php echo $dias24; ?>,<?php echo $dias25; ?>,<?php echo $dias26; ?>,<?php echo $dias27; ?>,<?php echo $dias28; ?>,<?php echo $dias29; ?>,<?php echo $dias30; ?>,<?php echo $dias31; ?>],
                                  backgroundColor: [
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066'

                                  ],
                                  borderColor: [
                                    '#ff0066'
                                  ],
                                  borderWidth: 1
                                }]
                              },
                              options: {
                                scales: {
                                  yAxes: [{
                                    ticks: {
                                      beginAtZero:true
                                    }
                                  }]
                                }
                              }
                            });
                      </script>
                        <div class="bar-chart-wp">
                        <canvas height="80vh" width="200vw" id="barchart11"></canvas>
                    </div>
                    </div>
                </div>


                    

        

                <table id="mis_ventas_x_productos" class="display" style="width:100%">
                          <thead>  
                               <tr style="background: #FF0066;color: #FFFF;">  
                                    <td style="text-align: center;">Usuario</td>  
                                    <td style="text-align: center;">Fecha</td> 
                                    <td style="text-align: center;">Hora</td> 
                                    <td style="text-align: center;">Cups</td> 
                                    <td style="text-align: center;">SPP</td>
                                    <td style="text-align: center;">SPP</td>
                                    <td style="text-align: center;">API</th>  
                                    <td style="text-align: center;">UUEE</th>
                                    <td style="text-align: center;">FE</th>
                                    <td style="text-align: center;">CF</th>
                                    <td style="text-align: center;">PMG</th>
                                    <td style="text-align: center;">AECC</th>
                                    <td style="text-align: center;">SPH+</th>
                                    <td style="text-align: center;">SPC</th>
                                    <td style="text-align: center;">SPE</th>
                                    <td style="text-align: center;">SPEH</th>
                                    <td style="text-align: center;">AG</th>
                                    <td style="text-align: center;">PG</th>
                                    <td style="text-align: center;">SMART HOME</th>
                                    <td style="text-align: center;">SMART MOBILITY</th>
                                    <td style="text-align: center;">OTROS PRODUCTOS</th>
                                    <td style="text-align: center;">ASISTENTE SMART</th>
                               </tr>  
                          </thead>    
                          <?php  
                          foreach ( $resultado_principal as $activos )
                          {  

                                $fechaMysql2 = $activos['fecha_registro'];
                                $fecha2 = preg_split("/[\s-]/", $fechaMysql2);
                                $mostrar_fecha2 = $fecha2[2].'/'.$fecha2[1].'/'.$fecha2[0];
                                $mostrar_fecha3 = $fecha2[3];

                                $id_accion = $activos["id_accion"];

                               echo '  
                               <tr>  
                                    <td style="text-align: center;">'.$activos["usuario_delta"].'</td>  
                                    <td style="text-align: center;">'.$mostrar_fecha2.'</td>
                                    <td style="text-align: center;">'.$mostrar_fecha3.'</td>
                                    <td style="text-align: center;">'.$activos["cups"].'</td>
                                    ';

                                    if($activos['productos1']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }


                                    if($activos['productos2']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }


                                    if($activos['productos3']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }




                                    if($activos['productos4']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }





                                    if($activos['productos5']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }





                                    if($activos['productos6']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }





                                    if($activos['productos7']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }




                                    if($activos['productos8']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }


                                    if($activos['productos9']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }



                                    if($activos['productos10']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }


                                    if($activos['productos11']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }


                                    if($activos['productos12']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }


                                    if($activos['productos13']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }


                                    if($activos['productos14']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }


                                    if($activos['productos15']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }


                                    if($activos['productos16']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }

                                    if($activos['productos17']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }

                                     if($activos['productos18']>='1'){
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('1'); ?></td>
                                    <?php 
                                    }else{
                                    ?>
                                    <td style="text-align: center;"><?php echo utf8_decode('0'); ?></td>
                                    <?php 
                                    }


                               echo '</tr>  
                               ';  
                          }  
                          ?> 
                     </table>
                    
        

