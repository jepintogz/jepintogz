<?php
require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
global $wpdb;
$valor=sanitize_text_field($_POST["valor"]);
if($valor==NULL){

}else{
	
$sql_duplicados_delta = $wpdb->get_row( "SELECT * FROM  {$wpdb->prefix}usuarios_delta WHERE tx = '$valor' OR delta_emp = '$valor' OR tsau = '$valor' OR tgeir = '$valor' OR tc2c = '$valor' OR omega_emicion = '$valor'", ARRAY_A );

}

if($sql_duplicados_delta["user_login"])
{
	$cadena=ltrim($sql_duplicados_delta["user_login"]);
	echo $cadena;
}

?>