<?php
    define('plugin_cd_iberdrola',plugin_dir_path(__FILE__));
    include(plugin_cd_iberdrola . './plantilla/index.php');

?>


<section style="padding: 3rem;border: 0px solid #ccc;/* IMPORTANTE */  text-align: center;border-radius: 5px;width: 100%;">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    
                    <div class="tab-content custom-menu-content">
                            <div class="widget-tabs-list">
                            <ul class="nav nav-tabs">
                                <li><a data-toggle="tab" href="#home2" style="background-color:#ff0066;color:#FFFFFF;">Reporte</a></li>
                            </ul>
                            <div class="tab-content tab-custom-st">
<div id="home3" class="tab-pane fade">

<div class="tab-ctn">
                                            <div class="row">
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <div class="form-element-list mg-t-30">
                                                        <div class="row">
                                                        </br></br></br>                        

                                                            <!-- INICIO FORMULARIO-->
<form method="POST" id='formulario_editar_ventas' enctype="multipart/form-data">     


               
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <label>Canal Entrada</label>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select id="id_canal_entrada_resultado" name="id_canal_entrada_resultado" class="selectpicker">
                                <option value=""></option>

                                </select>
                            </div>
                    </div>



                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <label>Usuario delta</label>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select id="usuario_delta_consulta2" name="usuario_delta_consulta2" class="selectpicker" data-live-search="true" disabled>
                                            <option value=""></option>
                                </select>
                                <input type="hidden" class="form-control" name="usuario_delta_consulta" id="usuario_delta_consulta">
                            </div>
                    </div>



                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <label>Departamento</label>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select id="id_departamento_consulta" name="id_departamento_consulta" class="selectpicker" data-live-search="true">
                                            <option value=""></option>
                                </select>
                            </div>
                    </div>




                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <label>Acción</label>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select id="id_accion_consulta" name="id_accion_consulta" class="selectpicker" data-live-search="true">
                                            <option value=""></option>
                                </select>
                            </div>
                    </div>



                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <label>CUP/NIF</label>
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <input type="hidden" class="form-control" name="cups_resultados" id="cups_resultados">
                                        <input type="text" class="form-control" name="cups_resultados2" id="cups_resultados2" onclick="getState5()" disabled>
                                        <input type="hidden" class="form-control" name="fecha_resultados" id="fecha_resultados">
                                        <input type="hidden" class="form-control" name="usuario_resultados" id="usuario_resultados">
                                        <input type="hidden" class="form-control" name="cups_resultados_1" id="cups_resultados_1">
                                    </div>
                    </div>


                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <label>Planes</label>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select id="id_planes_consulta" name="id_planes_consulta" class="selectpicker" data-live-search="true">
                                    <option value=""></option>
                                </select>
                            </div>
                    </div>



                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <label>Productos</label>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select name="id_productos_consulta[]" id="id_productos_consulta" class="selectpicker" data-live-search="true" multiple>
                                    <option value=""></option>
                                        </select>
                                    </div>
                    </div>


        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-element-list mg-t-30">
                    <div class="row">


                            




                        </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="form-element-list mg-t-30" style="text-align: left;padding: 2em;">
                                    <div class="row">
                                        
                                    <button type="button" class="btn notika-btn-pink" id="button_ventas" onclick='modificar_datos_ventas()'>Editar Venta</button>
                                    </div>
                                </div>
                            </div>
                        </div> 
                        

                    </div>    
                </div>
</form>      
                                                         <!-- FIN FORMULARIO-->   
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
</div>



<div id="home2" class="tab-pane fade">
                                    <div class="tab-ctn">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-element-list mg-t-30">
                                                    <div class="row">

<form method="POST" id='formulario_consultar_reportes' enctype="multipart/form-data">     


              

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-element-list mg-t-30">
                    <div class="row">


                            </br></br>
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>Fecha Inicial</label>
                                    <div class="input-group date nk-int-st">
                                        <span class="input-group-addon" style="padding: 6px !important;"></span>
                                        <input type="date" class="form-control" name="fecha_inicial_reporte" id="fecha_inicial_reporte">
                                    </div>
                                </div>
                            </div>


                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>Fecha Final</label>
                                    <div class="input-group date nk-int-st">
                                        <span class="input-group-addon" style="padding: 6px !important;"></span>
                                        <input type="date" class="form-control" name="fecha_final_reporte" id="fecha_final_reporte">
                                    </div>
                                </div>
                            </div>




                        </div>
                        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-element-list mg-t-30" style="text-align: left;padding: 1em;">
                    <div class="row">
                        
                    <button type="button" class="btn notika-btn-pink" onclick='consulta_reporte()'>Consultar</button>
                    </div>
                </div>
            </div>
        </div> 
                        
                    </div>    
                </div>
</form>      

<br/><br/>

<div id="listado_filtros_reporte">
                      </div>  

                                                       
                                                           
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>                    
                </div>
            </div>
        </div>
    </div>
</section>
     <div class="modal fade" id="modal_filtros" role="dialog">
                                    <div class="modal-dialog modals-default">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <h2>Editar Información</h2>
                                                <div id="actualizar_datos_codificador_filtros">
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
    </div>