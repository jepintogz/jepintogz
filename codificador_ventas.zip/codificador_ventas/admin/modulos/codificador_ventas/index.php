<?php
    define('plugin_cd_iberdrola',plugin_dir_path(__FILE__));
    include(plugin_cd_iberdrola . './plantilla/index.php');

?>

<section style="padding: 3rem;border: 0px solid #ccc;/* IMPORTANTE */  text-align: center;border-radius: 1px;width: 100%;">
    <div class="main-menu-area mg-tb-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <ul class="nav nav-tabs notika-menu-wrap menu-it-icon-pro">
                        <li><a data-toggle="tab" href="#codificador" style="background-color:#ff0066;color:#FFFFFF;"><i class="notika-icon notika-form"></i> Codificador</a>
                        </li>
                        <li><a data-toggle="tab" href="#mis_ventas" style="background-color:#ff0066;color:#FFFFFF;"><i class="notika-icon notika-edit"></i> Mis ventas</a>
                        </li>
                        <li><a data-toggle="tab" href="#ranking" style="background-color:#ff0066;color:#FFFFFF;"><i class="notika-icon notika-bar-chart"></i> Ranking</a>
                        </li>
                        <!--<li><a data-toggle="tab" href="#objetivos"><i class="notika-icon notika-support"></i> Objetivos</a>
                        </li>-->
                    </ul>
                     <!-- INICIO MENÚ TAB-->
                    <div class="tab-content custom-menu-content">
                        <!-- INICIO SUB-MENÚ TAB-->
                        <div id="codificador" class="tab-pane in flipInX">
                            <div class="widget-tabs-list">
                                <ul class="nav nav-tabs">
                                    <li><a data-toggle="tab" href="#codificador_ventas" style="background-color:#ff0066;color:#FFFFFF;">Codificador Ventas</a></li>
                                </ul>
                                <div class="tab-content tab-custom-st">
                                    <!-- INICIO SUB TAB MENÚ TAB-->
                                    <div id="codificador_ventas" class="tab-pane fade">
                                        <div class="tab-ctn">
                                            <div class="row">
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <div class="form-element-list mg-t-30">
                                                        <div class="row">
                                                        </br></br></br>
                                                        <!-- INICIO FORMULARIO-->
            <form method="POST" id='formulario_registrar_ventas' enctype="multipart/form-data">     


                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <div class="nk-int-mk sl-dp-mn sm-res-mg-t-10">
                            <label>Canal entrada</label>
                        </div>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select class="selectpicker" id="id_canal_entrada" name="id_canal_entrada" data-live-search="true">
                                <option value="">Por favor seleccione</option>
                                <?php
                                $query ="SELECT * FROM {$wpdb->prefix}canal_entrada where estado = 'Activo'";
                                $results = $conexion->query($query);
                                ?>
                                <?php
                                while($rs=$results->fetch_assoc()) {
                                ?>
                                <option value="<?php echo $rs["id_canal_entrada"]; ?>"><?php echo $rs["canal_entrada"]; ?></option>
                                <?php
                                }
                                ?>
                                </select>
                            </div>
                    </div>






                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <div class="nk-int-mk sl-dp-mn sm-res-mg-t-10">
                            <label>Usuario delta</label>
                        </div>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select class="selectpicker" id="usuario_delta" name="usuario_delta" data-live-search="true">
                                <option value="">Por favor seleccione</option>
                                <?php
                                $query ="SELECT * FROM {$wpdb->prefix}usuarios_delta where tsau IS NOT NULL AND  user_login = '$user_general' AND estado = 'Activo'";
                                $results = $conexion->query($query);
                                ?>
                                <?php
                                while($rs=$results->fetch_assoc()) {
                                ?>
                                <?php
                                if($rs["tx"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["tx"]; ?>"><?php echo $rs["tx"]; ?></option>
                                <?php
                                }
                                ?>

                                <?php
                                if($rs["delta_emp"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["delta_emp"]; ?>"><?php echo $rs["delta_emp"]; ?></option>  
                                <?php
                                }
                                ?>



                                <?php
                                if($rs["tsau"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["tsau"]; ?>"><?php echo $rs["tsau"]; ?></option>
                                <?php
                                }
                                ?>
                                
                                

                                <?php
                                if($rs["tgeir"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["tgeir"]; ?>"><?php echo $rs["tgeir"]; ?></option>  
                                <?php
                                }
                                ?>
                                

                                <?php
                                if($rs["tc2c"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["tc2c"]; ?>"><?php echo $rs["tc2c"]; ?></option>  
                                <?php
                                }
                                ?>
                                

                                <?php
                                if($rs["omega_emicion"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["omega_emicion"]; ?>"><?php echo $rs["omega_emicion"]; ?></option>
                                <?php
                                }
                                ?>                    
                                <?php
                                }
                                ?>
                                </select>
                            </div>
                    </div>




                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <div class="nk-int-mk sl-dp-mn sm-res-mg-t-10">
                            <label>Departamento</label>
                        </div>
                            <div class="bootstrap-select fm-cmp-mg">
                                <select class="selectpicker" id="id_departamento" name="id_departamento" data-live-search="true">
                                <option value="">Por favor seleccione</option>
                                <?php
                                $query ="SELECT * FROM {$wpdb->prefix}departamento where estado = 'Activo'";
                                $results = $conexion->query($query);
                                ?>
                                <?php
                                while($rs=$results->fetch_assoc()) {
                                ?>
                                <option value="<?php echo $rs["id_departamento"]; ?>"><?php echo $rs["departamento"]; ?></option>
                                <?php
                                }
                                ?>
                                </select>
                            </div>
                    </div>




                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <div class="nk-int-mk sl-dp-mn sm-res-mg-t-10">
                            <label>Acción</label>
                        </div>
                        <div class="bootstrap-select fm-cmp-mg">
                            <select id="id_accion" name="id_accion" class="selectpicker" data-live-search="true">
                            <option value="">Por favor seleccione</option>
                            <?php
                            $query ="SELECT * FROM {$wpdb->prefix}accion where estado = 'Activo'";
                            $results = $conexion->query($query);
                            ?>
                            <?php
                            while($rs=$results->fetch_assoc()) {
                            ?>
                            <option value="<?php echo $rs["id_accion"]; ?>"><?php echo $rs["accion"]; ?></option>
                            <?php
                            }
                            ?>              
                            </select>
                        </div>
                    </div>


                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <label>CUP/NIF</label>
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <input type="hidden" class="form-control" name="user_admin" id="user_admin" value="<?php echo $user_general; ?>">
                                        <input type="text" class="form-control" name="cups" id="cups" onclick="getState()">
                                    </div>
                    </div>





                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="nk-int-mk sl-dp-mn sm-res-mg-t-10">
                                    <label>Planes</label>
                                </div>
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <select id="id_planes" name="id_planes" class="selectpicker" data-live-search="true">
                                        <option value="">Por favor seleccione</option>
                                        <?php
                                        $query ="SELECT * FROM {$wpdb->prefix}planes where estado = 'Activo'";
                                        $results = $conexion->query($query);
                                        ?>
                                        <?php
                                        while($rs=$results->fetch_assoc()) {
                                        ?>
                                        <option value="<?php echo $rs["id_planes"]; ?>"><?php echo $rs["planes"]; ?></option>
                                        <?php
                                        }
                                        ?>
                                        </select>
                                    </div>
                            </div>


                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="nk-int-mk sl-dp-mn sm-res-mg-t-10">
                                    <label>Productos</label>
                                </div>
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <select name="id_productos[]" id="id_productos" class="selectpicker" data-live-search="true" multiple>
                                        <?php
                                        $query ="SELECT * FROM {$wpdb->prefix}productos where estado = 'Activo'";
                                        $results = $conexion->query($query);
                                        ?>
                                        <?php
                                        while($rs=$results->fetch_assoc()) {
                                        ?>
                                        <option value="<?php echo $rs["id_productos"]; ?>"><?php echo $rs["productos"]; ?></option>
                                        <?php
                                        }
                                        ?>
                                        </select>
                                    </div>
                            </div>



        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-element-list mg-t-30">
                    <div class="row">





                        </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="form-element-list mg-t-30" style="text-align: left;padding: 2em;">
                                    <div class="row">
                                        
                                    <button type="button" class="btn notika-btn-pink" id="button_ventas" onclick='registrar_ventas()'>Registrar Venta</button>
                                    </div>
                                </div>
                            </div>
                        </div> 
                        

                    </div>    
                </div>
            </form>      
                                                         <!-- FIN FORMULARIO-->   
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- FIN SUB TAB MENÚ TAB-->
                                </div>
                            </div>
                        </div> 
                        <!-- FIN SUB-MENÚ TAB-->   
                        <!-- INICIO SUB-MENÚ TAB-->
                        <div id="mis_ventas" class="tab-pane in flipInX">
                            <div class="widget-tabs-list">
                                <ul class="nav nav-tabs">

                               <?php
                              /* $result2 = mysqli_query($conexion, "SELECT * FROM  {$wpdb->prefix}users WHERE user_login = 'TMLSP1V23'");
                                $filas2 = mysqli_fetch_array($result2);
                                if($filas2["user_login"]=='TMLSP1V23'){*/
                                ?>    
                                    <li><a data-toggle="tab" href="#mis_ventas_x_accion" style="background-color:#ff0066;color:#FFFFFF;">Mis ventas x acción</a></li>
                                    <li><a data-toggle="tab" href="#mis_ventas_x_producto" style="background-color:#ff0066;color:#FFFFFF;">Mis ventas x producto</a></li>
                                <?php
                                
                               /* } */
                                ?>
                                </ul>
                                <div class="tab-content tab-custom-st">
                                    <!-- INICIO SUB TAB MENÚ TAB-->
                                    <div id="mis_ventas_x_accion" class="tab-pane fade">
                                        <div class="tab-ctn">
                                            <div class="row">
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <div class="form-element-list mg-t-30">
                                                        <div class="row">
                                                            <!-- INICIO FORMULARIO-->
                                                <div class="tab-ctn">
                                                <div class="form-element-list mg-t-30">

<form method="POST" id='formulario_filtros_busqueda_ventas' enctype="multipart/form-data">     


              

        <div class="row">
                                </br></br>

                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>Fecha Inicial</label>
                                    <div class="input-group date nk-int-st">
                                        <span class="input-group-addon" style="padding: 6px !important;"></span>
                                        <input type="month" class="form-control" name="fecha_inicial_estadisticas" id="fecha_inicial_estadisticas">
                                    </div>
                                </div>
                            </div>



                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                    
                                    <div class="bootstrap-select fm-cmp-mg">
                                    <label>Acción</label>
                                        <select id="id_accion_estadisticas" name="id_accion_estadisticas" class="selectpicker" data-live-search="true">
                                        <option value="">Por favor seleccione</option>
                                        <?php
                                        $query ="SELECT * FROM {$wpdb->prefix}accion where id_accion = '1' OR id_accion = '2'";
                                        $results = $conexion->query($query);
                                        ?>
                                        <?php
                                        while($rs=$results->fetch_assoc()) {
                                        ?>
                                        <option value="<?php echo $rs["id_accion"]; ?>"><?php echo $rs["accion"]; ?></option>
                                        <?php
                                        }
                                        ?>
                                        </select>
                                    </div>
                            </div>




                        </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="form-element-list mg-t-30" style="text-align: left;padding: 2em;">
                                    <div class="row">
                                    <button type="button" class="btn notika-btn-pink" onclick='mis_ventas_x_accion()'>Consultar</button>
                                    </div>
                                </div>
                            </div>
                        </div> 

                       
                    </div>    
                </div>
</form>      



<div id="listado_filtros_mis_ventas_por_accion">
                      </div>  

                                                       
                                                           
                                                    </div>
                                                </div>

                                                            <!-- FIN FORMULARIO-->
                                                        </div>
                                                    </div>
                                                </div>
                                    <!-- FIN SUB TAB MENÚ TAB-->
                                    <!-- INICIO SUB TAB MENÚ TAB-->
                                    <div id="mis_ventas_x_producto" class="tab-pane fade">
                                        <div class="tab-ctn">
                                            <div class="row">
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <div class="form-element-list mg-t-30">
                                                        <div class="row">
                                                            <!-- INICIO FORMULARIO-->
                                                <div class="tab-ctn">
                                                <div class="form-element-list mg-t-30">

<form method="POST" id='formulario_filtros_busqueda_ventas_producto' enctype="multipart/form-data">     


                                    </br></br></br>      

        <div class="row">


                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>Fecha Inicial</label>
                                    <div class="input-group date nk-int-st">
                                        <span class="input-group-addon" style="padding: 6px !important;"></span>
                                        <input type="month" class="form-control" name="fecha_inicial_estadisticas_producto" id="fecha_inicial_estadisticas_producto">
                                    </div>
                                </div>
                            </div>





                        </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="form-element-list mg-t-30" style="text-align: left;padding: 2em;">
                                    <div class="row">
                                        
                                    <button type="button" class="btn notika-btn-pink" onclick='mis_ventas_x_producto()'>Consultar</button>
                                    </div>
                                </div>
                            </div>
                        </div> 
                       
                    </div>    
                </div>
</form>      



<div id="listado_filtros_mis_ventas_por_producto">
                      </div>  

                                                       
                                                           
                                                    </div>
                                                </div>

                                                            <!-- FIN FORMULARIO-->
                                                        </div>
                                                    </div>
                                                </div>
                                    <!-- FIN SUB TAB MENÚ TAB-->
                                </div>
                            </div>
                        </div>   
                        <!-- FIN SUB-MENÚ TAB-->    
                        <!-- INICIO SUB-MENÚ TAB-->
                        <div id="ranking" class="tab-pane in flipInX">
                            <div class="widget-tabs-list">
                                <ul class="nav nav-tabs">
                                    <li><a data-toggle="tab" href="#subranking" style="background-color:#ff0066;color:#FFFFFF;">Ranking</a></li>
                                </ul>
                                <div class="tab-content tab-custom-st">
                                    <!-- INICIO SUB TAB MENÚ TAB-->
                                    <div id="subranking" class="tab-pane fade">
                                        <div class="tab-ctn">
                                            <div class="row">
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <div class="form-element-list mg-t-30">
                                                        <div class="row">
                                                            <!-- INICIO FORMULARIO-->
                                        <div class="tab-ctn">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

<form method="POST" id='formulario_filtros_ranking' enctype="multipart/form-data">     



                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>Fecha Inicial</label>
                                    <div class="input-group date nk-int-st">
                                        <span class="input-group-addon" style="padding: 6px !important;"></span>
                                        <input type="month" class="form-control" name="fecha_inicial_ranking" id="fecha_inicial_ranking">
                                    </div>
                                </div>
                            </div>


                            

                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <label>Acción</label>
                                        <select id="id_accion_ranking" name="id_accion_ranking" class="selectpicker" data-live-search="true">
                                        <option value="">Por favor seleccione</option>
                                        <?php
                                        $query ="SELECT * FROM {$wpdb->prefix}accion where id_accion = '1' OR id_accion = '2'";
                                        $results = $conexion->query($query);
                                        ?>
                                        <?php
                                        while($rs=$results->fetch_assoc()) {
                                        ?>
                                        <option value="<?php echo $rs["id_accion"]; ?>"><?php echo $rs["accion"]; ?></option>
                                        <?php
                                        }
                                        ?>
                                        </select>
                                    </div>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <label>Plataforma</label>
                                        <select id="id_pais_ranking" name="id_pais_ranking" class="selectpicker" data-live-search="true">
                                        <option value="">Por favor seleccione</option>
                                        <?php
                                        $query ="SELECT * FROM {$wpdb->prefix}pais where estado = 'Activo'";
                                        $results = $conexion->query($query);
                                        ?>
                                        <?php
                                        while($rs=$results->fetch_assoc()) {
                                        ?>
                                        <option value="<?php echo $rs["id_pais"]; ?>"><?php echo $rs["pais"]; ?></option>
                                        <?php
                                        }
                                        ?>
                                        </select>
                                    </div>
                            </div>

                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <label>Departamento</label>
                                        <select id="id_departamento_ranking" name="id_departamento_ranking" class="selectpicker" data-live-search="true">
                                        <option value="">Por favor seleccione</option>
                                        <?php
                                        $query ="SELECT * FROM {$wpdb->prefix}departamento where estado = 'Activo'";
                                        $results = $conexion->query($query);
                                        ?>
                                        <?php
                                        while($rs=$results->fetch_assoc()) {
                                        ?>
                                        <option value="<?php echo $rs["id_departamento"]; ?>"><?php echo $rs["departamento"]; ?></option>
                                        <?php
                                        }
                                        ?>
                                        </select>
                                    </div>
                            </div>



                        </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="form-element-list mg-t-30" style="text-align: left;padding: 2em;">
                                    <div class="row">
                                        
                                    <button type="button" class="btn notika-btn-pink" onclick='mis_ventas_ranking()'>Consultar</button>
                                    </div>
                                </div>
                            </div>
                        </div> 
                        
                    </div>    
                </div>
</form>      



<div id="listado_filtros_mis_ventas_ranking">
                      </div>  

                                                       
                                                           
                                            
                                            </div>
                                        </div>
                                    </div>
                                                            <!-- FIN FORMULARIO-->
                                           
                                        </div>
                                    </div>
                                    <!-- FIN SUB TAB MENÚ TAB-->
                                </div>
                            </div>
                        </div>    
                        <!-- FIN SUB-MENÚ TAB-->  
                        <!-- INICIO SUB-MENÚ TAB-->         
                        <div id="objetivos" class="tab-pane in flipInX">
                            <div class="widget-tabs-list">
                                <ul class="nav nav-tabs">
                                    <li><a data-toggle="tab" href="#consecusion_objetivos">Consecución mis objetivos</a></li>
                                </ul>
                                <div class="tab-content tab-custom-st">
                                    <div id="consecusion_objetivos" class="tab-pane fade">
                                        <div class="tab-ctn">
                                            <div class="row">
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <div class="form-element-list mg-t-30">
                                                        <div class="row">
                                                            <!-- INICIO FORMULARIO-->
                                        <div class="tab-ctn">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

<form method="POST" id='formulario_mis_objetivos' enctype="multipart/form-data">     


                          
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="nk-int-mk sl-dp-mn sm-res-mg-t-10">
                                    <h2>Acción</h2>
                                </div>
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <select id="id_accion_objetivos" name="id_accion_objetivos" class="selectpicker" data-live-search="true">
                                        <option value="">Por favor seleccione</option>
                                        <?php
                                        $query ="SELECT * FROM {$wpdb->prefix}accion where id_accion = '1' OR id_accion = '2'";
                                        $results = $conexion->query($query);
                                        ?>
                                        <?php
                                        while($rs=$results->fetch_assoc()) {
                                        ?>
                                        <option value="<?php echo $rs["id_accion"]; ?>"><?php echo $rs["accion"]; ?></option>
                                        <?php
                                        }
                                        ?>
                                        </select>
                                    </div>
                            </div>




                        </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="form-element-list mg-t-30" style="text-align: left;padding: 2em;">
                                    <div class="row">
                                        
                                    <button type="button" class="btn notika-btn-pink" onclick='mis_objetivos()'>Consultar</button>
                                    </div>
                                </div>
                            </div>
                        </div> 
                        <br/>
                        <br/>
                        
                    </div>    
                </div>
</form>      



<div id="listado_filtros_mis_objetivos">
                      </div>  

                                                            <!-- FIN FORMULARIO-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>  
                        <!-- FIN SUB-MENÚ TAB--> 
                    </div>                         
                     <!-- FIN MENÚ TAB-->

                </div>
            </div>
        </div>
    </div>
</section>