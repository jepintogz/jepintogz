<?php

/*
$sql11_42 ="CREATE TABLE IF NOT EXISTS {$wpdb->prefix}objetivos(
            `id_objetivos` INT NOT NULL AUTO_INCREMENT,
            `id_departamento` INT NOT NULL,
            `objetivo_luz` VARCHAR(60) NULL,
            `objetivo_gas` VARCHAR(60) NULL,
            `estado` VARCHAR(15) NULL,
            PRIMARY KEY (`id_objetivos`));";

$wpdb->query($sql11_42);  


$sql11_111 ="INSERT INTO `{$wpdb->prefix}objetivos` (`id_objetivos`, `id_departamento`, `objetivo_luz`, `objetivo_gas`, `estado`) VALUES
(1, 1, '0', '0', 'Activo'),
(2, 2, '0', '0', 'Activo'),
(3, 3, '0', '0', 'Activo'),
(4, 4, '0', '0', 'Activo'),
(5, 5, '0', '0', 'Activo'),
(6, 6, '0', '0', 'Activo'),
(7, 7, '0', '0', 'Activo'),
(8, 8, '0', '0', 'Activo'),
(9, 9, '0', '0', 'Activo'),
(10, 10, '0', '0', 'Activo'),
(11, 11, '0', '0', 'Activo'),
(12, 12, '0', '0', 'Activo'),
(13, 13, '0', '0', 'Activo'),
(14, 14, '0', '0', 'Activo');";

$wpdb->query($sql11_111);

$sql11 ="CREATE TABLE IF NOT EXISTS {$wpdb->prefix}departamento(
            `id_departamento` INT NOT NULL AUTO_INCREMENT,
            `departamento` VARCHAR(60) NULL,
            `estado` VARCHAR(15) NULL,
            PRIMARY KEY (`id_departamento`));";

$wpdb->query($sql11);  


$sql11_1 ="INSERT INTO `{$wpdb->prefix}departamento` (`id_departamento`, `departamento`, `estado`) VALUES
(1, 'GENERALISTA', 'Activo'),
(2, 'RETENCIONES', 'Activo'),
(3, 'VENTAS', 'Activo'),
(4, 'EMPRESA', 'Activo'),
(5, 'SAU', 'Activo'),
(6, 'OVC', 'Activo'),
(7, 'CHAT', 'Activo'),
(8, 'REDES', 'Activo'),
(9, 'GEIR', 'Activo'),
(10, 'C2C', 'Activo'),
(11, 'PEXC', 'Activo'),
(12, 'GEIC', 'Activo'),
(13, 'FAC&COB', 'Activo'),
(14, 'COBROS', 'Activo');";

$wpdb->query($sql11_1);




$sql11 ="CREATE TABLE IF NOT EXISTS {$wpdb->prefix}objetivos(
            `id_objetivos` INT NOT NULL AUTO_INCREMENT,
            `id_departamento` INT NOT NULL,
            `id_accion` INT NOT NULL,
            `objetivo` VARCHAR(60) NULL,
            `estado` VARCHAR(15) NULL,
            PRIMARY KEY (`id_objetivos`));";

$wpdb->query($sql11);  


$sql11_1 ="INSERT INTO `{$wpdb->prefix}objetivos` (`id_objetivos`,`id_departamento`,`id_accion`, `objetivo`, `estado`) VALUES
(1,,,1, 'GENERALISTA', 'Activo'),
(2,,,2, 'RETENCIONES', 'Activo'),
(3,,,3, 'VENTAS', 'Activo'),
(4,,,4, 'EMPRESA', 'Activo'),
(5,,,5, 'SAU', 'Activo'),
(6,,,6, 'OVC', 'Activo'),
(7,,,7, 'CHAT', 'Activo'),
(8,,,8, 'REDES', 'Activo'),
(9, 'GEIR', 'Activo'),
(10, 'C2C', 'Activo'),
(11, 'PEXC', 'Activo'),
(12, 'GEIC', 'Activo'),
(13, 'FAC&COB', 'Activo'),
(14, 'COBROS', 'Activo');";

$wpdb->query($sql11_1);




$sql12 ="CREATE TABLE IF NOT EXISTS {$wpdb->prefix}accion(
            `id_accion` INT NOT NULL AUTO_INCREMENT,
            `accion` VARCHAR(60) NULL,
            `estado` VARCHAR(15) NULL,
            PRIMARY KEY (`id_accion`));";

$wpdb->query($sql12);  



$sql12_1 ="INSERT INTO `{$wpdb->prefix}accion` (`id_accion`, `accion`, `estado`) VALUES
(1, 'Venta Luz', 'Activo'),
(2, 'Venta Gas', 'Activo'),
(3, 'Venta Gas CUR', 'Activo'),
(4, 'Solo producto adiciona', 'Activo'),
(5, 'Frase Puente Electricidad', 'Activo'),
(6, 'Frase Puente Gas', 'Activo'),
(7, 'Retencion Fidelizacion', 'Activo'),
(8, 'Venta Luz CUR', 'Activo');";

$wpdb->query($sql12_1);  




$sql13 ="CREATE TABLE IF NOT EXISTS {$wpdb->prefix}productos(
            `id_productos` INT NOT NULL AUTO_INCREMENT,
            `productos` VARCHAR(60) NULL,
            `estado` VARCHAR(15) NULL,
            PRIMARY KEY (`id_productos`));";

$wpdb->query($sql13);  


$sql13_1 ="INSERT INTO `{$wpdb->prefix}productos` (`id_productos`, `productos`, `estado`) VALUES
(1, 'SPP PLUS', 'Activo'),
(2, 'SPP AUTONOMO', 'Activo'),
(3, 'API - ASISTENCIA PYMES', 'Activo'),
(4, 'UUEE - URGENCIAS ELECTRICAS', 'Activo'),
(5, 'FE - FACTURA ELECTRONICA', 'Activo'),
(6, 'CF - CUOTA FIJA', 'Activo'),
(7, 'PMG - PACK MANTENIMIENTO GAS', 'Activo'),
(8, 'AECC - ASOCIACION CONTRA EL CANCER', 'Activo'),
(9, 'SPH+ PROTECCION ELECTRICA HOGAR PLUS', 'Activo'),
(10, 'SPC - SERVICIO PROTECCION CLIMATIZACION', 'Activo'),
(11, 'SPE - SERVICIO PROTECCION ELECTRODOMESTICOS', 'Activo'),
(12, 'SPEH - SERVICIO PROTECCION ELECTRICA HOGAR', 'Activo'),
(13, 'AG - ASISTENCIA GAS', 'Activo'),
(14, 'PG - PROTECCION GAS', 'Activo'),
(15, 'SMART HOME', 'Activo'),
(16, 'SMART MOBILITY', 'Activo'),
(17, 'OTROS PRODUCTOS', 'Activo');";

$wpdb->query($sql13_1);  






$sql14 ="CREATE TABLE IF NOT EXISTS {$wpdb->prefix}planes(
            `id_planes` INT NOT NULL AUTO_INCREMENT,
            `planes` VARCHAR(60) NULL,
            `estado` VARCHAR(15) NULL,
            PRIMARY KEY (`id_planes`));";

$wpdb->query($sql14);  



$sql14_1 ="INSERT INTO `{$wpdb->prefix}planes` (`id_planes`, `planes`, `estado`) VALUES
(1, 'Plan 24 horas', 'Activo'),
(2, 'Plan 8760h', 'Activo'),
(3, 'Plan Comercio', 'Activo'),
(4, 'Plan Compromiso', 'Activo'),
(5, 'Plan Elige 8h', 'Activo'),
(6, 'Plan Estable', 'Activo'),
(7, 'Plan Exclusivo', 'Activo'),
(8, 'Plan Hogar', 'Activo'),
(9, 'Plan Invierno', 'Activo'),
(10, 'Plan Negocios', 'Activo'),
(11, 'Plan Noche', 'Activo'),
(12, 'Plan Restauracion', 'Activo'),
(13, 'Plan Segunda Vivienda', 'Activo'),
(14, 'Plan Solar', 'Activo'),
(15, 'Plan Verano', 'Activo'),
(16, 'Plan Exclusivo Empresas', 'Activo'),
(17, 'Plan Exclusivo Retenciones', 'Activo'),
(18, 'Plan Vehiculo Electrico', 'Activo'),
(19, 'Plan DHS', 'Activo'),
(20, 'Gas Online', 'Activo'),
(21, 'Gas Winback', 'Activo'),
(22, 'Gas Iberdrola', 'Activo'),
(23, 'Otros Planes', 'Activo');";

$wpdb->query($sql14_1);  



$sql15 ="CREATE TABLE IF NOT EXISTS {$wpdb->prefix}pais(
            `id_pais` INT NOT NULL AUTO_INCREMENT,
            `pais` VARCHAR(60) NULL,
            `estado` VARCHAR(15) NULL,
            PRIMARY KEY (`id_pais`));";

$wpdb->query($sql15);


$sql15_1 ="INSERT INTO `{$wpdb->prefix}pais` (`id_pais`, `pais`, `estado`) VALUES
(1, 'Chile', 'Activo'),
(2, 'Madrid', 'Activo'),
(3, 'Valencia', 'Activo');";

$wpdb->query($sql15_1);


$sql16 ="CREATE TABLE IF NOT EXISTS {$wpdb->prefix}cargos(
            `id_cargos` INT NOT NULL AUTO_INCREMENT,
            `cargos` VARCHAR(60) NULL,
            `estado` VARCHAR(15) NULL,
            PRIMARY KEY (`id_cargos`));";

$wpdb->query($sql16);

$sql16_1 ="INSERT INTO `{$wpdb->prefix}cargos` (`id_cargos`, `cargos`, `estado`) VALUES
(1, 'editor', 'Activo'),
(2, 'subscriber', 'Activo');";

$wpdb->query($sql16_1);


$sql17 ="CREATE TABLE IF NOT EXISTS {$wpdb->prefix}usuarios_delta(
            `id_usuarios_delta` INT NOT NULL AUTO_INCREMENT,
            `id_pais` INT NOT NULL,
            `id_cargos` INT NOT NULL,
            `id_departamento` INT NOT NULL,
            `user_login` VARCHAR(60) NULL,
            `nombres_apellidos` VARCHAR(60) NULL,
            `tx` VARCHAR(60) NULL,
            `delta_emp` VARCHAR(60) NULL,
            `tsau` VARCHAR(60) NULL,
            `tgeir` VARCHAR(60) NULL,
            `tc2c` VARCHAR(60) NULL,
            `omega_emicion` VARCHAR(60) NULL,
            `coordinador` VARCHAR(60) NULL,
            `estado` VARCHAR(15) NULL,
            PRIMARY KEY (`id_usuarios_delta`));";

$wpdb->query($sql17);


$sql17_1 ="INSERT INTO `{$wpdb->prefix}usuarios_delta` (`id_usuarios_delta`, `id_pais`, `id_cargos`, `id_departamento`, `user_login`, `nombres_apellidos`, `tx`, `delta_emp`, `tsau`, `tgeir`, `tc2c`, `omega_emicion`, `estado`) VALUES
(NULL, 2, 2, 6, 'E00021422', 'TITUAÑA ALMACHI, NOEMI', 'T214330', '', '', '', '', '', 'Activo'),
(NULL, 2, 2, 6, 'E00019132', 'SANSIERRA MOLINA, NATIVIDAD', 'T217190', '', '', '', '', '', 'Activo'),
(NULL, 2, 2, 13, 'E00105993', 'LIOY ABBA, MARIA CLARA', 'T21X590', '', '', '', '', '', 'Activo');";

$wpdb->query($sql17_1);

$sql18 ="CREATE TABLE IF NOT EXISTS {$wpdb->prefix}codificador_ventas(
            `id_codificador` INT NOT NULL AUTO_INCREMENT,
            `id_departamento` INT NOT NULL,
            `id_accion` INT NOT NULL,
            `id_productos` INT NOT NULL,
            `id_planes` INT NOT NULL,
            `id_canal_entrada` INT NOT NULL,
            `cups` VARCHAR(60) NULL,
            `usuario_delta` VARCHAR(60) NULL,
            `usuario` VARCHAR(60) NULL,
            `estado` VARCHAR(15) NULL,
            `fecha_registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id_codificador`));";

$wpdb->query($sql18);


$sql19 ="CREATE TABLE IF NOT EXISTS {$wpdb->prefix}canal_entrada(
            `id_canal_entrada` INT NOT NULL AUTO_INCREMENT,
            `canal_entrada` VARCHAR(60) NULL,
            `estado` VARCHAR(15) NULL,
            PRIMARY KEY (`id_canal_entrada`));";

$wpdb->query($sql19);



?>