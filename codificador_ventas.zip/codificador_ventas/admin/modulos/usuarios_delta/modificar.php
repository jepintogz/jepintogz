<?php
    require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
    global $wpdb;

    $id_usuarios_delta = sanitize_text_field($_POST["id_usuarios_delta"]);
    $id_pais = sanitize_text_field($_POST["id_pais2"]);
    $coordinador = sanitize_text_field($_POST["cooridnador2"]);
    $id_departamento = sanitize_text_field($_POST["id_departamento2"]);
    $user_login = sanitize_text_field($_POST["user_login3"]);
    $nombres_apellidos = sanitize_text_field($_POST["nombres_apellidos3"]);
    $tx = sanitize_text_field($_POST["tx2"]);
    $delta_emp = sanitize_text_field($_POST["delta_emp2"]);
    $tsau = sanitize_text_field($_POST["tsau2"]);
    $tgeir = sanitize_text_field($_POST["tgeir2"]);
    $tc2c = sanitize_text_field($_POST["tc2c2"]);
    $omega_emicion = sanitize_text_field($_POST["omega_emicion2"]);

    $sql11_42_1 ="UPDATE {$wpdb->prefix}usuarios_delta SET id_pais = '$id_pais',id_departamento = '$id_departamento',user_login = '$user_login',nombres_apellidos = '$nombres_apellidos',tx = '$tx',delta_emp = '$delta_emp',tsau = '$tsau',tgeir = '$tgeir',tc2c = '$tc2c',omega_emicion = '$omega_emicion',coordinador = '$coordinador' WHERE id_usuarios_delta = '$id_usuarios_delta'";
    $wpdb->query($sql11_42_1);  
    echo 1;
?>
