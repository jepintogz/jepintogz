<?php
  require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
  global $wpdb;
  $id_accion=sanitize_text_field($_POST["id_accion"]);
  $sql11_42_1 ="UPDATE {$wpdb->prefix}accion SET estado = 'Inactivo' WHERE id_accion = '$id_accion'";
  $wpdb->query($sql11_42_1);  
?>