<?php
  require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
  global $wpdb;
  $id_departamento=sanitize_text_field($_POST["id_departamento"]);
  $sql11_42_1 ="UPDATE {$wpdb->prefix}departamento SET estado = 'Activo' WHERE id_departamento = '$id_departamento'";
  $wpdb->query($sql11_42_1);  
?>