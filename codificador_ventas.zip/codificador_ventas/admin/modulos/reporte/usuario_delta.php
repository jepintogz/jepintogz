<?php
    include_once '../../../../../../wp-config.php';
    include_once '../../../../../../wp-load.php';
    include_once '../../../../../../wp-includes/wp-db.php';
    include_once '../../../../../../wp-includes/pluggable.php';

    include('../../../conexion/conexion.php');
    global $wpdb;


if ($conexion -> connect_errno)

{

  die("Fallo la conexion:(".$conexion -> mysqli_connect_errno().")".$conexion-> mysqli_connect_error());

}

error_reporting(E_ALL ^ E_NOTICE);

$id_codificador = $_POST["id_codificador"];
$query ="SELECT * FROM  {$wpdb->prefix}codificador_ventas WHERE id_codificador = '$id_codificador'";
$results = $conexion->query($query);



?>
<?php
	while($rs=$results->fetch_assoc()) {


?>
	<option value="<?php echo $rs["usuario_delta"]; ?>"><?php echo $rs["usuario_delta"]; ?></option>
<?php

}
?>
<?php
                                $query ="SELECT * FROM {$wpdb->prefix}usuarios_delta where tsau IS NOT NULL AND estado = 'Activo'";
                                $results = $conexion->query($query);
                                ?>
                                <?php
                                while($rs=$results->fetch_assoc()) {
                                ?>
                                <?php
                                if($rs["tx"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["tx"]; ?>"><?php echo $rs["tx"]; ?></option>
                                <?php
                                }
                                ?>

                                <?php
                                if($rs["delta_emp"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["delta_emp"]; ?>"><?php echo $rs["delta_emp"]; ?></option>  
                                <?php
                                }
                                ?>



                                <?php
                                if($rs["tsau"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["tsau"]; ?>"><?php echo $rs["tsau"]; ?></option>
                                <?php
                                }
                                ?>
                                
                                

                                <?php
                                if($rs["tgeir"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["tgeir"]; ?>"><?php echo $rs["tgeir"]; ?></option>  
                                <?php
                                }
                                ?>
                                

                                <?php
                                if($rs["tc2c"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["tc2c"]; ?>"><?php echo $rs["tc2c"]; ?></option>  
                                <?php
                                }
                                ?>
                                

                                <?php
                                if($rs["omega_emicion"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["omega_emicion"]; ?>"><?php echo $rs["omega_emicion"]; ?></option>
                                <?php
                                }
                                ?>                    
                                <?php
                                }
                                ?>