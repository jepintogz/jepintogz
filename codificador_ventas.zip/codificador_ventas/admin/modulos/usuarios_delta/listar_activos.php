<?php
                             
require_once(explode("wp-content", __FILE__)[0] . "wp-config.php"); 
$wpurl = plugins_url().'/codificador_ventas/plantilla/icons-1.7.2/bootstrap-icons.svg#justify';
$consulta_usuarios = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}usuarios_delta WHERE estado = 'Activo'" , ARRAY_A);   


?>

               <table id="listado_activos_usuarios_delta" class="display" style="width:100%;font-size: 11px;">
                         <thead>  
                              <tr style="background: #FF0066;color: #FFFF;">
                                    <td style="text-align: center;">Número de empleado</td>  
                                    <td style="text-align: center;">Apellidos y nombres</td>  
                                    <td style="text-align: center;">Tx</td>  
                                    <td style="text-align: center;">Servicio</td>  
                                    <td style="text-align: center;">Delta EMP</td>  
                                    <td style="text-align: center;">T SAU</td>  
                                    <td style="text-align: center;">T GEIR</td>  
                                    <td style="text-align: center;">T C2C</td>  
                                    <td style="text-align: center;">OMEGA Emisión</td>  
                                    <td style="text-align: center;">Centro</td>
                                    <td style="text-align: center;">Coordinador</td>
                                    <td style="text-align: center;">Editar</td>
                                    <td style="text-align: center;">Inactivar</td>
                              </tr>  
                         </thead>  
                    <?php  
                         foreach ( $consulta_usuarios as $resultados )
                         {  

                              $id_departamento = $resultados["id_departamento"]; 
                              $id_pais = $resultados["id_pais"];
                              $id_cargos = $resultados["id_cargos"];

                              $resultado_fl_departamento = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}departamento WHERE id_departamento = '$id_departamento'", ARRAY_A );
                              $resultado_fl_centro = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}pais WHERE id_pais = '$id_pais'", ARRAY_A );
                              $resultado_fl_cargos = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}cargos WHERE id_cargos = '$id_cargos'", ARRAY_A );

                               
                               echo '  
                               <tr>  
                                   <td style="text-align: center;">'.$resultados["user_login"].'</td>  
                                   <td style="text-align: center;">'.$resultados["nombres_apellidos"].'</td>  
                                   <td style="text-align: center;">'.$resultados["tx"].'</td>  
                                   <td style="text-align: center;">'.$resultado_fl_departamento["departamento"].'</td>  
                                   <td style="text-align: center;">'.$resultados["delta_emp"].'</td>  
                                   <td style="text-align: center;">'.$resultados["tsau"].'</td>  
                                   <td style="text-align: center;">'.$resultados["tgeir"].'</td>  
                                   <td style="text-align: center;">'.$resultados["tc2c"].'</td>  
                                   <td style="text-align: center;">'.$resultados["omega_emicion"].'</td>  
                                   <td style="text-align: center;">'.$resultado_fl_centro["pais"].'</td>  
                                   <td style="text-align: center;">'.$resultados["coordinador"].'</td>

                                   <td style="text-align: center;">
                                     <button class="btn btn-primary primary-icon-notika btn-reco-mg btn-button-mg" type="button" class="btn btn-outline-primary block" data-toggle="modal" data-target="#modal_edicion_usuarios_activos"
                                         onclick="listar_generico_usuarios_delta('.$resultados["id_usuarios_delta"].')"><svg class="bi" width="1em" height="1em" fill="currentColor">
                                                <use
                                                    xlink:href="'.$wpurl.'" />
                                            </svg></button>       
                                   </td>

                                   <td style="text-align: center;">
                                         <button class="btn btn-primary primary-icon-notika btn-reco-mg btn-button-mg" type="button" class="btn btn-outline-primary block" onclick="inactivo_usuarios_delta(\''.$resultados["id_usuarios_delta"].'\')"><svg class="bi" width="1em" height="1em" fill="currentColor">
                                                    <use
                                                        xlink:href="'.$wpurl.'" />
                                                </svg></button>       
                                   </td>';
    

                            
                         }  
                    ?>  
               </table>

