<?php
    define('plugin_cd_iberdrola',plugin_dir_path(__FILE__));
    include(plugin_cd_iberdrola . './plantilla/index.php');

?>


<section style="padding: 3rem;border: 0px solid #ccc;/* IMPORTANTE */  text-align: center;border-radius: 5px;width: 100%;">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    
                    <div class="tab-content custom-menu-content">
                            <div class="widget-tabs-list">
                            <ul class="nav nav-tabs">
                                <li><a data-toggle="tab" href="#home2" style="background-color:#ff0066;color:#FFFFFF;">Registrar usuarios delta</a></li>
                                <li><a data-toggle="tab" onclick='listar_registros_usuarios_delta()' href="#menu1" style="background-color:#ff0066;color:#FFFFFF;">Listar activos usuarios delta</a></li>
                                <li><a data-toggle="tab" onclick='listar_registros_inactivos_usuarios_delta()' href="#menu2" style="background-color:#ff0066;color:#FFFFFF;">Listar Inactivos usuarios delta</a></li>
                            </ul>
                            <div class="tab-content tab-custom-st">
                                <div id="home2" class="tab-pane fade">
                                    <div class="tab-ctn">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-element-list mg-t-30">
                                                    <div class="row">
</br></br></br>

<form method="POST" id='formulario_registrar_usuarios_delta' enctype="multipart/form-data">     


        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-element-list mg-t-30">
                    <div class="row">



                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>Número de empleado</label>
                                    <div class="input-group date nk-int-st">
                                        <span class="input-group-addon" style="padding: 12px !important;"></span>
                                        <input type="text" class="form-control" name="user_login" id="user_login" onchange="getState2(this.value),getState3(this.value)" placeholder="Por favor ingresa el número del empleado">
                                    </div>
                                </div>
                            </div>



                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>Nombres y apellidos</label>
                                    <div class="input-group date nk-int-st">
                                        <span class="input-group-addon" style="padding: 12px !important;background: #fff0;border: #fff0;"></span>
                                        <input type="text" name="nombres_apellidos2" id="nombres_apellidos2" readonly="readonly" class="form-control">
                                        <input type="hidden" name="nombres_apellidos" id="nombres_apellidos" class="form-control">
                                    </div>
                                </div>
                            </div>





                        </div>
                        </div>


        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-element-list mg-t-30">
                    <div class="row">



                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>Tx</label>
                                    <div class="input-group date nk-int-st">
                                        <span class="input-group-addon" style="padding: 12px !important;"></span>
                                        <input type="text" class="form-control" name="tx" id="tx" onchange="getState4(this.value)">
                                    </div>
                                </div>
                            </div>


                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>Delta Emp</label>
                                    <div class="input-group date nk-int-st">
                                        <span class="input-group-addon" style="padding: 12px !important;background: #fff0;border: #fff0;"></span>
                                        <input type="text" class="form-control" name="delta_emp" id="delta_emp" onchange="getState4(this.value)">
                                    </div>
                                </div>
                            </div>



                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>Tsau</label>
                                    <div class="input-group date nk-int-st">
                                        <span class="input-group-addon" style="padding: 12px !important;background: #fff0;border: #fff0;"></span>
                                        <input type="text" class="form-control" name="tsau" id="tsau" onchange="getState4(this.value)">
                                    </div>
                                </div>
                            </div>


                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>Tgeir</label>
                                    <div class="input-group date nk-int-st">
                                        <span class="input-group-addon" style="padding: 12px !important;background: #fff0;border: #fff0;"></span>
                                        <input type="text" class="form-control" name="tgeir" id="tgeir" onchange="getState4(this.value)">
                                    </div>
                                </div>
                            </div>



                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>T C2C</label>
                                    <div class="input-group date nk-int-st">
                                        <span class="input-group-addon" style="padding: 12px !important;background: #fff0;border: #fff0;"></span>
                                        <input type="text" class="form-control" name="tc2c" id="tc2c" onchange="getState4(this.value)">
                                    </div>
                                </div>
                            </div>



                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>Omega Emisión</label>
                                    <div class="input-group date nk-int-st">
                                        <span class="input-group-addon" style="padding: 12px !important;background: #fff0;border: #fff0;"></span>
                                        <input type="text" class="form-control" name="omega_emicion" id="omega_emicion" onchange="getState4(this.value)">
                                    </div>
                                </div>
                            </div>



                        </div>
                        </div>

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-element-list mg-t-30">
                    <div class="row">



                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                
                                    
                                    <div class="bootstrap-select fm-cmp-mg">
                                    <label>Centro</label>
                                        <select id="id_pais" name="id_pais" class="selectpicker" data-live-search="true">
                                        <option value="">Por favor seleccione</option>
                                        <?php
                                          $query ="SELECT * FROM {$wpdb->prefix}pais where estado = 'Activo'";
                                          $results = $conexion->query($query);
                                            ?>
                                                <?php
                                                while($rs=$results->fetch_assoc()) {
                                                ?>
                                                <option value="<?php echo $rs["id_pais"]; ?>"><?php echo $rs["pais"]; ?></option>
                                                <?php
                            
                                            }
                                        ?>
                                        </select>
                                    </div>
                            </div>



                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <label>Departamento</label>
                                        <select id="id_departamento" name="id_departamento" class="selectpicker" data-live-search="true">
                                        <option value="">Por favor seleccione</option>
                                        <?php
                                          $query ="SELECT * FROM {$wpdb->prefix}departamento where estado = 'Activo'";
                                          $results = $conexion->query($query);
                                            ?>
                                                <?php
                                                while($rs=$results->fetch_assoc()) {
                                                ?>
                                                <option value="<?php echo $rs["id_departamento"]; ?>"><?php echo $rs["departamento"]; ?></option>
                                                <?php
                            
                                            }
                                            ?>
                                        </select>
                                    </div>
                            </div>



                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <label>Coordinadores</label>
                                        <select id="coordinador" name="coordinador"  class="selectpicker" data-live-search="true">
                                        <option value="">Por favor seleccione</option>
                                          <?php


                                          $rol5 = 'a:1:{s:10:"subscriber";b:1;}';
                                         
                                          $query ="SELECT {$wpdb->users}.ID, firstname.meta_value as first_name, lastname.meta_value as last_name, {$wpdb->prefix}capabilities.meta_value as {$wpdb->prefix}capabilities FROM {$wpdb->users} INNER JOIN (SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = 'first_name') as firstname ON {$wpdb->users}.ID = firstname.user_id INNER JOIN (SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = 'last_name') as lastname ON {$wpdb->users}.ID = lastname.user_id INNER JOIN (SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = '{$wpdb->prefix}capabilities') as {$wpdb->prefix}capabilities  ON {$wpdb->users}.ID = {$wpdb->prefix}capabilities.user_id AND {$wpdb->prefix}capabilities.meta_value LIKE '%editor%' order by last_name asc";
                                          $results = $conexion->query($query);
                                            ?>
                                                <?php
                                                while($rs=$results->fetch_assoc()) {

                                                  $nombres_apellidos = $rs["last_name"].', '.' '.$rs["first_name"];
                                                ?>
                                                <option value="<?php echo $nombres_apellidos; ?>"><?php echo $nombres_apellidos; ?></option>
                                                <?php
                            
                                            }
                                            ?>
                                        </select>

                                    </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>    
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-element-list mg-t-30" style="text-align: left;padding: 1em;">
                    <div class="row">
                        
                <button type="button" class="btn notika-btn-pink" style="text-align: left;padding: -1rem;" onclick='registrar_usuarios_delta()'>Registrar usuarios</button>
                    </div>
                </div>
            </div>
        </div>                
</form>      
                                                            </div>
                                                        </div>   
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                            </div>
                            </div>

<div id="menu1" class="tab-pane fade">
                                    <div class="tab-ctn">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-element-list mg-t-30">
                                                    <div class="row">
                                        </br></br>
<form method="POST" id='formulario_filtros_busqueda_usuarios_delta' enctype="multipart/form-data">     


              

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-element-list mg-t-30">
                    <div class="row">


                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <label>Centro</label>
                                        <select id="id_pais" name="id_pais" class="selectpicker" data-live-search="true">
                                        <option value="">Por favor seleccione</option>
                                        <?php
                                          $query ="SELECT * FROM {$wpdb->prefix}pais where estado = 'Activo'";
                                          $results = $conexion->query($query);
                                            ?>
                                                <?php
                                                while($rs=$results->fetch_assoc()) {
                                                ?>
                                                <option value="<?php echo $rs["id_pais"]; ?>"><?php echo $rs["pais"]; ?></option>
                                                <?php
                            
                                            }
                                        ?>
                                        </select>
                                    </div>
                            </div>

                        </div>
                        </div>
                        <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-element-list mg-t-30" style="text-align: left;padding: 1em;">
                                <div class="row">
                                <button type="button" class="btn notika-btn-pink" style="text-align: left;padding: -1rem;" onclick='filtros_busqueda_usuarios_delta()'>Consultar</button>   
                                </div>
                                </div>
                            </div>
                        </div>    
                        
                    </div>    
                </div>
</form>      


<br/><br/>
<div id="listado_filtro_busqueda_div" style="overflow-x:scroll!important;">
                      </div>  

                                                       
                                                           
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>






<div id="menu2" class="tab-pane fade">
                                    <div class="tab-ctn">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-element-list mg-t-30">
                                                    <div class="row">

<form method="POST" id='formulario_filtros_busqueda_usuarios_delta_inactivo' enctype="multipart/form-data">     


              

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-element-list mg-t-30">
                    <div class="row">



                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                <div class="nk-int-mk sl-dp-mn sm-res-mg-t-10">
                                    <h2>Centro</h2>
                                </div>
                                    <div class="bootstrap-select fm-cmp-mg">
                                        <select id="id_pais" name="id_pais" class="selectpicker" data-live-search="true">
                                        <option value="">Por favor seleccione</option>
                                        <?php
                                          $query ="SELECT * FROM {$wpdb->prefix}pais where estado = 'Activo'";
                                          $results = $conexion->query($query);
                                            ?>
                                                <?php
                                                while($rs=$results->fetch_assoc()) {
                                                ?>
                                                <option value="<?php echo $rs["id_pais"]; ?>"><?php echo $rs["pais"]; ?></option>
                                                <?php
                            
                                            }
                                        ?>
                                        </select>
                                    </div>
                            </div>



                        </div>
                        </div>
                        
                        <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="form-element-list mg-t-30" style="text-align: left;padding: 1em;">
                                <div class="row">
                                <button type="button" class="btn notika-btn-pink" onclick='filtros_busqueda_inactivos_usuarios_delta()'>Consultar</button>
                                </div>
                                </div>
                            </div>
                        </div>    
                       
                    </div>    
                </div>
</form>      
<br/><br/>


<div id="listado_filtros_inactivos_usuarios_delta" style="overflow-x:scroll!important;">
                      </div>  

                                                       
                                                           
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                </div>
            </div>
        </div>
    </div>
</section>

    
    <div class="modal fade" id="modal_edicion_usuarios_activos" role="dialog">
                                    <div class="modal-dialog modals-default">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <h2>Editar Información</h2>
                                                <div id="actualizar_datos_usuarios_delta">
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
    </div>
