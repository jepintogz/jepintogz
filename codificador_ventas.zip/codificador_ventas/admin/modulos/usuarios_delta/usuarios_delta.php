<?php

require_once(explode("wp-content", __FILE__)[0] . "wp-config.php"); 
global $wpdb;
$user_login=sanitize_text_field($_POST["user_login"]);

$resultado_usuario_delta = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}usuarios_delta WHERE user_login = '$user_login'", ARRAY_A );


if($resultado_usuario_delta["user_login"])
{
 		$cadena=ltrim($resultado_usuario_delta["user_login"]);
    echo $cadena;
}
?>