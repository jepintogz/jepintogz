<?php
                             
require_once(explode("wp-content", __FILE__)[0] . "wp-config.php"); 
$wpurl = plugins_url().'/codificador_ventas/plantilla/icons-1.7.2/bootstrap-icons.svg#justify';
$res = file_get_contents(plugins_url().'/codificador_ventas/api/api_canal_entrada_activos.php');
$array = json_decode($res);                            


?>
                <table id="listado_activos_canal_entrada" class="display" style="width: 100%">  
                          <thead>  
                               <tr style="background: #FF0066;color: #FFFF;">  
                                    <td style="text-align: left;">Id Canal Entrada</td>  
                                    <td style="text-align: left;">Canal Entrada</td>  
                                    <td style="text-align: center;">Estado</td>
                                    <td style="text-align: center;">Editar</td>
                                    <td style="text-align: center;">Inactivar</td>
                               </tr>  
                          </thead>  
                          <?php  
                          foreach($array as $obj)
                          { 
                              $id_canal_entrada = $obj->id_canal_entrada; 
                              $canal_entrada = $obj->canal_entrada; 
                              $estado = $obj->estado;    
                               echo '  
                               <tr>  
                                    <td style="text-align: left;">'.$id_canal_entrada.'</td>  
                                    <td style="text-align: left;">'.$canal_entrada.'</td>  
                                    <td style="text-align: center;">'.$estado.'</td>
                                    <td style="text-align: center;">
                                    <button class="btn btn-primary primary-icon-notika btn-reco-mg btn-button-mg" type="button" class="btn btn-outline-primary block" data-toggle="modal" data-target="#modal_accion_canal_entrada"
                                        onclick="listar_generico_canal_entrada('.$id_canal_entrada.')"><svg class="bi" width="1em" height="1em" fill="currentColor">
                                               <use
                                                   xlink:href="'.$wpurl.'" />
                                           </svg></button>       
                                   </td>
                                   <td style="text-align: center;">
                                        <button class="btn btn-primary primary-icon-notika btn-reco-mg btn-button-mg" type="button" class="btn btn-outline-primary block" onclick="inactivo_canal_entrada(\''.$id_canal_entrada.'\')"><svg class="bi" width="1em" height="1em" fill="currentColor">
                                                   <use
                                                       xlink:href="'.$wpurl.'" />
                                               </svg></button>       
                                  </td>
                               </tr>  
                               ';  
                          }  
                          ?>  
                     </table>