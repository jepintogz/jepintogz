<?php


require_once(explode("wp-content", __FILE__)[0] . "wp-config.php"); 
$wpurl = plugins_url().'/codificador_ventas/plantilla/icons-1.7.2/bootstrap-icons.svg#justify';


	  $cups = sanitize_text_field($_POST["cups"]);
	  $id_departamento = sanitize_text_field($_POST["id_departamento"]);
	  $id_accion = sanitize_text_field($_POST["id_accion"]);
	  $usuario_delta_consulta = sanitize_text_field($_POST["usuario_delta_consulta"]);

	  $resultado_codificador = $wpdb->get_row( "SELECT * FROM  `{$wpdb->prefix}codificador_ventas` WHERE id_departamento = '$id_departamento' AND id_accion = '$id_accion' AND cups = '$cups'  AND DATE(fecha_registro) BETWEEN DATE_SUB(NOW(),INTERVAL 30 DAY) AND DATE(NOW()) ORDER BY id_codificador DESC LIMIT 1", ARRAY_A );
  
	  $cups = $resultado_codificador["cups"];
	  
	  $fechaMysql2 = $resultado_codificador['fecha_registro'];
      $fecha2 = preg_split("/[\s-]/", $fechaMysql2);
      $mostrar_fecha2 = $fecha2[2].'/'.$fecha2[1].'/'.$fecha2[0].' '.$fecha2[3];


?>
	

<?php
	
	  if($usuario_delta_consulta == $resultado_codificador["usuario_delta"] AND $id_departamento == $resultado_codificador["id_departamento"]){

	  	echo 'Se encuentra disponible';

	  }else{

	  	if($resultado_codificador["cups"]){

	  		$cadena="Este cups y esta acción han sido registrados anteriormente por otro usuario </br>".$mostrar_fecha2;
?>
<?php echo $cadena; ?>
<?php

	  	}else{
	  		echo 'Se encuentra disponible';
	  	}

	  }

?>