<?php
    define('plugin_cd_iberdrola',plugin_dir_path(__FILE__));
    include(plugin_cd_iberdrola . './plantilla/index.php');

?>


<section style="padding: 3rem;border: 0px solid #ccc;/* IMPORTANTE */  text-align: center;border-radius: 5px;width: 100%;">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    
                    <div class="tab-content custom-menu-content">
                            <div class="widget-tabs-list">
                            <ul class="nav nav-tabs">
                                <li><a data-toggle="tab" href="#home2" style="background-color:#ff0066;color:#FFFFFF;">Registrar</a></li>
                                <li><a data-toggle="tab" onclick='listar_registros_cargos()' href="#menu1" style="background-color:#ff0066;color:#FFFFFF;">Listar</a></li>
                                <li><a data-toggle="tab" onclick='listar_registros_inactivos_cargos()' href="#menu2" style="background-color:#ff0066;color:#FFFFFF;">Inactivos</a></li>
                            </ul>
                            <div class="tab-content tab-custom-st">
                                <div id="home2" class="tab-pane fade">
                                    <div class="tab-ctn">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-element-list mg-t-30">
                                                    <div class="row">

<form method="POST" id='formulario_registrar_cargos' enctype="multipart/form-data">     


        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-element-list mg-t-30">
                    <div class="row">


                            </br>
                            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="text-align: left;">
                                <div class="form-group nk-datapk-ctm form-elet-mg" id="data_2">
                                    <label>Cargos</label>
                                    <div class="input-group date nk-int-st">
                                        <input type="text" class="form-control" name="cargos" id="cargos">
                                    </div>
                                    
                                </div>
                                <button type="button" class="btn notika-btn-pink" onclick='registrar_cargos()'>Registrar</button>
                            </div>

                        </div>
                        </div>
                        

                    </div>    
                </div>
</form>      

                                                       
                                                           
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>


<div id="menu1" class="tab-pane fade">
                                    <div class="tab-ctn">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-element-list mg-t-30">
                                                    <div class="row">
                                                    </br></br></br>
                                    <div id="listado_acciones_cargos" style="overflow-x:scroll!important;">
                                    </div>  

                                                       
                                                           
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>






<div id="menu2" class="tab-pane fade">
                                    <div class="tab-ctn">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="form-element-list mg-t-30">
                                                    <div class="row">


                                                    </br></br></br>

                                <div id="listado_cargos_inactivos" style="overflow-x:scroll!important;">
                                </div>  

                                                       
                                                           
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                </div>
            </div>
        </div>
    </div>
</section>

    <div class="modal fade" id="modal_cargos_activos" role="dialog">
                                    <div class="modal-dialog modals-default">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <h2>Editar Información</h2>
                                                <div id="actualizar_datos_cargos">
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
    </div>