<?php
  require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
  global $wpdb;
  $response = array();
  header("Content-Type: Json");
  $i = 0;
  $reportes = $wpdb->get_results( "SELECT id_codificador,id_departamento,id_accion,id_productos,id_planes,id_canal_entrada,cups,usuario_delta,usuario,fecha_registro,
  max(case when (id_productos) = '1' then '1' end) productos1,
  max(case when (id_productos) = '2' then '2' end) productos2,
  max(case when (id_productos) = '3' then '3' end) productos3,
  max(case when (id_productos) = '4' then '4' end) productos4,
  max(case when (id_productos) = '5' then '5' end) productos5,
  max(case when (id_productos) = '6' then '6' end) productos6,
  max(case when (id_productos) = '7' then '7' end) productos7,
  max(case when (id_productos) = '8' then '8' end) productos8,
  max(case when (id_productos) = '9' then '9' end) productos9,
  max(case when (id_productos) = '10' then '10' end) productos10,
  max(case when (id_productos) = '11' then '11' end) productos11,
  max(case when (id_productos) = '12' then '12' end) productos12,
  max(case when (id_productos) = '13' then '13' end) productos13,
  max(case when (id_productos) = '14' then '14' end) productos14,
  max(case when (id_productos) = '15' then '15' end) productos15,
  max(case when (id_productos) = '16' then '16' end) productos16,
  max(case when (id_productos) = '17' then '17' end) productos17,
  max(case when (id_productos) = '18' then '18' end) productos18
  
  FROM `{$wpdb->prefix}codificador_ventas` WHERE SUBSTR({$wpdb->prefix}codificador_ventas.fecha_registro,1,10)>='$fecha_inicial' AND SUBSTR({$wpdb->prefix}codificador_ventas.fecha_registro,1,10)<='$fecha_final' AND {$wpdb->prefix}codificador_ventas.fecha_registro GROUP BY usuario,cups,id_accion" , ARRAY_A);  

  foreach ( $reportes as $resultados ) 
  {
    $response [$i]['id_codificador'] = $resultados ['id_codificador'];                          
    $response [$i]['id_departamento'] = $resultados ['id_departamento'];
    $response [$i]['id_accion'] = $resultados ['id_accion'];
    $response [$i]['id_productos'] = $resultados ['id_productos'];
    $response [$i]['id_planes'] = $resultados ['id_planes'];
    $response [$i]['id_canal_entrada'] = $resultados ['id_canal_entrada'];
    $response [$i]['cups'] = $resultados ['cups'];
    $response [$i]['usuario_delta'] = $resultados ['usuario_delta'];
    $response [$i]['usuario'] = $resultados ['usuario'];
    $response [$i]['estado'] = $resultados ['estado'];

    $dato_fecha = $resultados ['fecha_registro'];
    $fecha = date('Y-m-d',strtotime($dato_fecha));
    $fechaMysql2 = $fecha;
    $fecha2 = preg_split("/[\s-]/", $fechaMysql2);
    $mostrar_fecha2 = $fecha2[2].'/'.$fecha2[1].'/'.$fecha2[0];
    $hora = date('H:i:s',strtotime($dato_fecha)); 



    $i++;
  
  }   

  echo json_encode($response,JSON_PRETTY_PRINT);
?>
