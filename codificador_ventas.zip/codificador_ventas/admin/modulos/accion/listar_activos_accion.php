<?php
                             
require_once(explode("wp-content", __FILE__)[0] . "wp-config.php"); 
$wpurl = plugins_url().'/codificador_ventas/plantilla/icons-1.7.2/bootstrap-icons.svg#justify';
$res = file_get_contents(plugins_url().'/codificador_ventas/api/api_accion_activos.php');
$array = json_decode($res);                            


?>

                <table id="listado_activos_acciones" class="display" style="width:100%">
                          <thead>  
                               <tr style="background: #FF0066;color: #FFFF;">  
                                    <td style="text-align: center;">Id Acción</td>  
                                    <td style="text-align: center;">Acción</td>  
                                    <td style="text-align: center;">Estado</td>
                                    <td style="text-align: center;">Editar</td>
                                    <td style="text-align: center;">Inactivar</td>
                               </tr>  
                          </thead>  
                          <?php  
                          foreach($array as $obj)
                          {  
                              $id_accion = $obj->id_accion; 
                              $accion = $obj->accion; 
                              $estado = $obj->estado; 

                               echo '  
                               <tr>  
                                    <td style="text-align: left;">'.$id_accion.'</td>  
                                    <td style="text-align: left;">'.$accion.'</td>  
                                    <td style="text-align: center;">'.$estado.'</td>
                                    <td style="text-align: center;">
                                     <button class="btn btn-primary primary-icon-notika btn-reco-mg btn-button-mg" type="button" class="btn btn-outline-primary block" data-toggle="modal" data-target="#modal_accion_activos"
                                         onclick="listar_generico_accion('.$id_accion.')"><svg class="bi" width="1em" height="1em" fill="currentColor">
                                                <use
                                                    xlink:href="'.$wpurl.'" />
                                            </svg></button>       
                                   </td>
                                   <td style="text-align: center;">
                                         <button class="btn btn-primary primary-icon-notika btn-reco-mg btn-button-mg" type="button" class="btn btn-outline-primary block" onclick="inactivo_accion(\''.$id_accion.'\')"><svg class="bi" width="1em" height="1em" fill="currentColor">
                                                    <use
                                                        xlink:href="'.$wpurl.'" />
                                                </svg></button>       
                                   </td>
                               </tr>  
                               ';  
                          }  
                          ?>  
                     </table>