<?php
                             
require_once(explode("wp-content", __FILE__)[0] . "wp-config.php"); 
$wpurl = plugins_url().'/codificador_ventas/plantilla/icons-1.7.2/bootstrap-icons.svg#justify';
$res = file_get_contents(plugins_url().'/codificador_ventas/api/api_departamento_activos.php');
$array = json_decode($res);                            


?>


                 <table id="listado_activos_departamento" class="display" style="width:100%">
                          <thead>  
                               <tr style="background: #FF0066;color: #FFFF;">  
                                    <td style="text-align: left;">Id Departamento</td>  
                                    <td style="text-align: left;">Departamento</td>  
                                    <td style="text-align: center;">Estado</td>
                                    <td style="text-align: center;">Editar</td>
                                    <td style="text-align: center;">Inactivar</td>
                               </tr>  
                          </thead>  
                          <?php  
                          foreach($array as $obj)
                          {  
                               
                              $id_departamento = $obj->id_departamento; 
                              $departamento = $obj->departamento; 
                              $estado = $obj->estado; 
                               
                               echo '  
                               <tr>  
                                    <td style="text-align: left;">'.$id_departamento.'</td>  
                                    <td style="text-align: left;">'.$departamento.'</td>  
                                    <td style="text-align: center;">'.$estado.'</td>
                                    <td style="text-align: center;">
                                     <button class="btn btn-primary primary-icon-notika btn-reco-mg btn-button-mg" type="button" class="btn btn-outline-primary block" data-toggle="modal" data-target="#modal_departamento_activos"
                                         onclick="listar_generico_departamento('.$id_departamento.')"><svg class="bi" width="1em" height="1em" fill="currentColor">
                                                <use
                                                    xlink:href="'.$wpurl.'" />
                                            </svg></button>       
                                   </td>
                                   <td style="text-align: center;">
                                         <button class="btn btn-primary primary-icon-notika btn-reco-mg btn-button-mg" type="button" class="btn btn-outline-primary block" onclick="inactivo_departamento(\''.$id_departamento.'\')"><svg class="bi" width="1em" height="1em" fill="currentColor">
                                                    <use
                                                        xlink:href="'.$wpurl.'" />
                                                </svg></button>       
                                   </td>
                               </tr>  
                               ';  
                          }  
                          ?>  
                     </table>