<?php
    require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
    global $wpdb;	  

    $cups_resultados = sanitize_text_field($_POST["cups_resultados"]);
    $id_canal_entrada_resultado = sanitize_text_field($_POST["id_canal_entrada_resultado"]);
    $usuario_delta_consulta = sanitize_text_field($_POST["usuario_delta_consulta"]);
    $id_departamento_consulta = sanitize_text_field($_POST["id_departamento_consulta"]);
    $id_accion_consulta = sanitize_text_field($_POST["id_accion_consulta"]);
    $id_planes_consulta = sanitize_text_field($_POST["id_planes_consulta"]);
    $id_productos_consulta = ($_POST["id_productos_consulta"]);
    $user_admin = sanitize_text_field($_POST["usuario_resultados"]);
    $fecha_registro = sanitize_text_field($_POST["fecha_resultados"]);
    $cups_resultados_1 = sanitize_text_field($_POST["cups_resultados_1"]);
    $estado = 'Activo'; 

    $sql11_42_1 ="DELETE FROM `{$wpdb->prefix}codificador_ventas` WHERE `cups` = '$cups_resultados_1' AND fecha_registro = '$fecha_registro'";
    $wpdb->query($sql11_42_1);  

if($_POST["id_productos_consulta"]=='')
{
           
           $sql11_42 ="INSERT INTO `{$wpdb->prefix}codificador_ventas` (`id_codificador`, `id_departamento`, `id_accion`, `id_productos`, `id_planes`, `id_canal_entrada`, `cups`, `usuario_delta`, `usuario`, `estado`, `fecha_registro`) VALUES (Null, '$id_departamento_consulta', '$id_accion_consulta', '0', '$id_planes_consulta', '$id_canal_entrada_resultado', '$cups_resultados', '$usuario_delta_consulta', '$user_admin', '$estado', '$fecha_registro')";
           $wpdb->query($sql11_42);  

}else
{

    for ($i=0;$i<count($id_productos_consulta);$i++) 
        { 
            
            $ciclo = $id_productos_consulta[$i]; 
            
            $sql11_424 ="INSERT INTO `{$wpdb->prefix}codificador_ventas` (`id_codificador`, `id_departamento`, `id_accion`, `id_productos`, `id_planes`, `id_canal_entrada`, `cups`, `usuario_delta`, `usuario`, `estado`, `fecha_registro`) VALUES (Null, '$id_departamento_consulta', '$id_accion_consulta', '$ciclo', '$id_planes_consulta', '$id_canal_entrada_resultado', '$cups_resultados', '$usuario_delta_consulta', '$user_admin', '$estado', '$fecha_registro')";
            $wpdb->query($sql11_424);  
            
        }

}
echo 1;

?>
