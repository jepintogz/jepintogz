<?php
	  
    include_once '../../../../../../wp-config.php';
    include_once '../../../../../../wp-load.php';
    include_once '../../../../../../wp-includes/wp-db.php';
    include_once '../../../../../../wp-includes/pluggable.php';

    include('../../../conexion/conexion.php');
    global $wpdb;
	  $id_codificador=$_POST["id_codificador"];
  	$result = mysqli_query($conexion, "SELECT * FROM {$wpdb->prefix}codificador_ventas      
                         WHERE {$wpdb->prefix}codificador_ventas.id_codificador='$id_codificador'");
	  $filas = mysqli_fetch_array($result);

    $id_departamento = $filas['id_departamento'];
    $id_accion = $filas['id_accion'];
    $id_productos = $filas['id_productos'];
    $id_planes = $filas['id_planes'];
    $id_canal_entrada = $filas['id_canal_entrada'];
    $cups = $filas['cups'];
    $usuario_delta = $filas['usuario_delta'];
    $usuario = $filas['usuario'];
    $fecha_registro = $filas['fecha_registro'];

    $result2 = mysqli_query($conexion, "SELECT * FROM  {$wpdb->prefix}departamento WHERE id_departamento = '$id_departamento'");
    $filas2 = mysqli_fetch_array($result2);
    $result3 = mysqli_query($conexion, "SELECT * FROM  {$wpdb->prefix}accion WHERE id_accion = '$id_accion'");
    $filas3 = mysqli_fetch_array($result3);
    $result4 = mysqli_query($conexion, "SELECT * FROM  {$wpdb->prefix}productos WHERE id_productos = '$id_productos'");
    $filas4 = mysqli_fetch_array($result4);
    $result5 = mysqli_query($conexion, "SELECT * FROM  {$wpdb->prefix}planes WHERE id_planes = '$id_planes'");
    $filas5 = mysqli_fetch_array($result5);
    $result6 = mysqli_query($conexion, "SELECT * FROM  {$wpdb->prefix}canal_entrada WHERE id_canal_entrada = '$id_canal_entrada'");
    $filas6 = mysqli_fetch_array($result6);
     	

?>  
	  <form method="POST" id='editar_formulario_codificador' enctype="multipart/form-data">
      <table  class="table table-hover">
      	<input type="hidden" name="id_codificador" value="<?php echo $id_codificador ?>">
          <tr>
          <td>Canal Entrada</td>
            <td>
              <select id="id_canal_entrada_1" name="id_canal_entrada_1" style="width: 132px;">
                   <option value="<?php echo $filas6["id_canal_entrada"] ?>"><?php echo $filas6["canal_entrada"] ?></option>
                       <?php
                        $query ="SELECT * FROM {$wpdb->prefix}canal_entrada where estado = 'Activo'";
                        $results = $conexion->query($query);
                        ?>
                        <?php
                            while($rs=$results->fetch_assoc()) {
                        ?>
                        <option value="<?php echo $rs["id_canal_entrada"]; ?>"><?php echo $rs["canal_entrada"]; ?></option>
                        <?php
                        }
                        ?>
                                                
                </select>
            </td>
            <td>Usuario delta</td>
            <td>
              <select id="id_usuarios_delta" name="id_usuarios_delta" style="width: 132px;">
                   <option value="<?php echo $filas["usuario_delta"] ?>"><?php echo $filas["usuario_delta"] ?></option>
                      <?php
                                $query ="SELECT * FROM {$wpdb->prefix}usuarios_delta where estado = 'Activo'";
                                $results = $conexion->query($query);
                                ?>
                                <?php
                                while($rs=$results->fetch_assoc()) {
                                ?>

                                <?php
                                if($rs["tx"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["tx"]; ?>"><?php echo $rs["tx"]; ?></option>
                                <?php
                                }
                                ?>

                                <?php
                                if($rs["delta_emp"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["delta_emp"]; ?>"><?php echo $rs["delta_emp"]; ?></option>  
                                <?php
                                }
                                ?>



                                <?php
                                if($rs["tsau"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["tsau"]; ?>"><?php echo $rs["tsau"]; ?></option>
                                <?php
                                }
                                ?>
                                
                                

                                <?php
                                if($rs["tgeir"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["tgeir"]; ?>"><?php echo $rs["tgeir"]; ?></option>  
                                <?php
                                }
                                ?>
                                

                                <?php
                                if($rs["tc2c"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["tc2c"]; ?>"><?php echo $rs["tc2c"]; ?></option>  
                                <?php
                                }
                                ?>
                                

                                <?php
                                if($rs["omega_emicion"]==''){
                                ?>
                                <?php
                                }else{
                                ?>
                                <option value="<?php echo $rs["omega_emicion"]; ?>"><?php echo $rs["omega_emicion"]; ?></option>
                                <?php
                                }
                                ?>                               
                                
                                
                                <?php
                                }
                                ?>                                       
              </select>
              
            </td>
          </tr>  
          <tr>

            <td>Departamento</td>
            <td>
              <select class="selectpicker" id="id_departamento_1" name="id_departamento_1" data-live-search="true">
                   <option value="<?php echo $filas2["id_departamento"] ?>"><?php echo $filas2["departamento"] ?></option>
                       <?php
                        $query ="SELECT * FROM {$wpdb->prefix}departamento where estado = 'Activo'";
                        $results = $conexion->query($query);
                        ?>
                        <?php
                            while($rs=$results->fetch_assoc()) {
                        ?>
                        <option value="<?php echo $rs["id_departamento"]; ?>"><?php echo $rs["departamento"]; ?></option>
                        <?php
                        }
                        ?>
                                                
                </select>
            </td> 

            <td>Acción</td>
            <td>
              <select id="id_accion_1" name="id_accion_1" style="width: 132px;">
                   <option value="<?php echo $filas3["id_accion"] ?>"><?php echo $filas3["accion"] ?></option>
                       <?php
                        $query ="SELECT * FROM {$wpdb->prefix}accion where estado = 'Activo'";
                        $results = $conexion->query($query);
                        ?>
                        <?php
                            while($rs=$results->fetch_assoc()) {
                        ?>
                        <option value="<?php echo $rs["id_accion"]; ?>"><?php echo $rs["accion"]; ?></option>
                        <?php
                        }
                        ?>
                                                
                </select>
            </td> 
            

          <tr>

            
            
          </tr>
          <tr>
            <td>CUP/NIF </td>
            <td>
              <input type="text" id="cups" name="cups" style="width: 132px;" value="<?php echo $filas["cups"] ?>"> 
            </td> 
            <td>Planes</td>
            <td>
               <select id="id_planes_1" name="id_planes_1" style="width: 132px;">
                   <option value="<?php echo $filas5["id_planes"] ?>"><?php echo $filas5["planes"] ?></option>
                       <?php
                        $query ="SELECT * FROM {$wpdb->prefix}planes where estado = 'Activo'";
                        $results = $conexion->query($query);
                        ?>
                        <?php
                            while($rs=$results->fetch_assoc()) {
                        ?>
                        <option value="<?php echo $rs["id_planes"]; ?>"><?php echo $rs["planes"]; ?></option>
                        <?php
                        }
                        ?>
                                                
                </select>
            </td> 
          </tr>  
          
        </table>

        <div class="modal-footer">
              <button type="button" class="btn btn-default" onclick="modificar_datos_codificador_llamadas()" data-dismiss="modal">Guardar</button>
              <button type="button" class="btn btn-default" data-dismiss="modal">Salir</button>
        </div>
  </form>