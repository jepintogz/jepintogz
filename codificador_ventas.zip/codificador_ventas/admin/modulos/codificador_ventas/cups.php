<?php
require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
global $wpdb;

$cups = sanitize_text_field($_POST["cups"]);
$id_departamento = sanitize_text_field($_POST["id_departamento"]);
$id_accion = sanitize_text_field($_POST["id_accion"]);


$filas2 = $wpdb->get_row( "SELECT * FROM  `{$wpdb->prefix}codificador_ventas` WHERE id_departamento = '$id_departamento' AND id_accion = '$id_accion' AND cups = '$cups'  AND DATE(fecha_registro) BETWEEN DATE_SUB(NOW(),INTERVAL 30 DAY) AND DATE(NOW()) ORDER BY id_codificador DESC LIMIT 1", ARRAY_A );
$cups = $filas2["cups"];
$fechaMysql2 = $filas2['fecha_registro'];
$fecha2 = preg_split("/[\s-]/", $fechaMysql2);
$mostrar_fecha2 = $fecha2[2].'/'.$fecha2[1].'/'.$fecha2[0].' '.$fecha2[3];


?>
	

<?php
	  if($filas2["cups"])
	  	{
	  		$cadena="Este cups y esta acción han sido registrados anteriormente por otro usuario </br>".$mostrar_fecha2;
?>
	<?php echo $cadena; ?>
	

<?php
		}else{
			echo 'Se encuentra disponible';
		}
?>