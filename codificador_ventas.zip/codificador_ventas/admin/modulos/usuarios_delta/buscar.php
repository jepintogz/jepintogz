<?php
    require_once(explode("wp-content", __FILE__)[0] . "wp-config.php"); 
    global $wpdb;
    $id_usuarios_delta=sanitize_text_field($_POST["id_usuarios_delta"]);

    $resultado_usuario_delta = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}usuarios_delta WHERE id_usuarios_delta = '$id_usuarios_delta'", ARRAY_A );
    $id_departamento = $resultado_usuario_delta["id_departamento"];
    $id_pais = $resultado_usuario_delta["id_pais"];
    $id_cargos = $resultado_usuario_delta["id_cargos"];      
    $resultado_departamentos = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}departamento WHERE id_departamento = '$id_departamento'", ARRAY_A );
    $resultado_centros = $wpdb->get_row( "SELECT * FROM {$wpdb->prefix}pais WHERE id_pais = '$id_pais'", ARRAY_A );

?>  
    <form method="POST" id='editar_formulario_usuarios_delta' enctype="multipart/form-data">
      <table  class="table table-hover">
        <input type="hidden" name="id_usuarios_delta" value="<?php echo $id_usuarios_delta ?>">
          <tr>
            <td>Numero Empleado: </td>
            <td>
              <input class="form-control" type="text" value="<?php echo $resultado_usuario_delta["user_login"] ?>" name="user_login2" id="user_login2" disabled>
              <input class="form-control" type="hidden" value="<?php echo $resultado_usuario_delta["user_login"] ?>" name="user_login3" id="user_login3">
            </td>
            <td>Apellidos y Nombre: </td>
            <td>
              <input class="form-control" type="text" value="<?php echo $resultado_usuario_delta["nombres_apellidos"] ?>" name="nombres_apellidos2" id="nombres_apellidos2" disabled>
              <input class="form-control" type="hidden" value="<?php echo $resultado_usuario_delta["nombres_apellidos"] ?>" name="nombres_apellidos3" id="nombres_apellidos3">
            </td>
          </tr>
          <tr> 
            <td>Tx: </td>
            <td>
              <input class="form-control" type="text" value="<?php echo $resultado_usuario_delta["tx"] ?>" onchange="getState4_1(this.value)" name="tx2" id="tx2">
            </td> 
            <td>Servicio:</td>
            <td>
                <select id="id_departamento2" name="id_departamento2" class="form-control">
                          <option value="<?php echo $resultado_departamentos["id_departamento"] ?>"><?php echo $resultado_departamentos["departamento"] ?></option>
                    <?php
                      $consultar_departamentos = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}departamento where estado = 'Activo'" , ARRAY_A); 
                    ?>
                    <?php
                        foreach ($consultar_departamentos as $resultados)
                        {
                    ?>
                          <option value="<?php echo $resultados["id_departamento"]; ?>"><?php echo $resultados["departamento"]; ?></option>
                    <?php
                        }
                    ?>                            
                </select>
            </td> 
          </tr>
          <tr>
            <td>Delta EMP: </td>
            <td>
              <input class="form-control" type="text" value="<?php echo $resultado_usuario_delta["delta_emp"] ?>" name="delta_emp2" id="delta_emp2" onchange="getState4_1(this.value)">
            </td> 

            <td>T SAU: </td>
            <td>
              <input class="form-control" type="text" value="<?php echo $resultado_usuario_delta["tsau"] ?>" name="tsau2" id="tsau2" onchange="getState4_1(this.value)">
            </td> 

          </tr>  
          <tr>
            <td>T GEIR: </td>
            <td>
              <input class="form-control" type="text" value="<?php echo $resultado_usuario_delta["tgeir"] ?>" name="tgeir2" id="tgeir2" onchange="getState4_1(this.value)">
            </td> 

            <td>T C2C: </td>
            <td>
              <input class="form-control" type="text" value="<?php echo $resultado_usuario_delta["tc2c"] ?>" name="tc2c2" id="tc2c2" onchange="getState4_1(this.value)">
            </td> 

          </tr>  

           <tr>
            <td>OMEGA Emisión: </td>
            <td>
              <input class="form-control" type="text" value="<?php echo $resultado_usuario_delta["omega_emicion"] ?>" name="omega_emicion2" id="omega_emicion2" onchange="getState4_1(this.value)">
            </td> 

            <td>Centro: </td>
            <td>
                <select id="id_pais2" name="id_pais2" class="form-control">
                          <option value="<?php echo $resultado_centros["id_pais"] ?>"><?php echo $resultado_centros["pais"] ?></option>
                    <?php
                      $consultar_centros = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}pais where estado = 'Activo'" , ARRAY_A);
                    ?>
                    <?php
                        foreach ($consultar_centros as $resultados)
                        {
                    ?>
                          <option value="<?php echo $resultados["id_pais"]; ?>"><?php echo $resultados["pais"]; ?></option>
                    <?php
                        }
                    ?>                            
                </select>
            </td> 

          </tr>  

           <tr>
            
            <td>Coordinador: </td>
            <td>
                <select id="cooridnador2" name="cooridnador2" class="form-control">
                        <option value="<?php echo $resultado_usuario_delta["coordinador"] ?>"><?php echo $resultado_usuario_delta["coordinador"] ?></option>
                    <?php
                      $consultar_coordinador = $wpdb->get_results( "SELECT {$wpdb->users}.ID, firstname.meta_value as first_name, lastname.meta_value as last_name, {$wpdb->prefix}capabilities.meta_value as {$wpdb->prefix}capabilities FROM {$wpdb->users} INNER JOIN (SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = 'first_name') as firstname ON {$wpdb->users}.ID = firstname.user_id INNER JOIN (SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = 'last_name') as lastname ON {$wpdb->users}.ID = lastname.user_id INNER JOIN (SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = '{$wpdb->prefix}capabilities') as {$wpdb->prefix}capabilities  ON {$wpdb->users}.ID = {$wpdb->prefix}capabilities.user_id AND {$wpdb->prefix}capabilities.meta_value LIKE '%editor%' ORDER BY last_name ASC" , ARRAY_A);
                    ?>
                    <?php
                        foreach ($consultar_coordinador as $resultados)
                        {
                          $nombres_apellidos = $resultados["last_name"].', '.' '.$resultados["first_name"];
                    ?>
                          <option value="<?php echo $nombres_apellidos; ?>"><?php echo $nombres_apellidos; ?></option>
                    <?php
                        }
                    ?>                            
                </select>
            </td> 
          </tr>
        </table>
        <button type="button" onclick="modificar_usuarios_delta()" class="btn btn-primary ml-1"
        class="close" data-dismiss="modal">
                                                        <i class="bx bx-check d-block d-sm-none"></i>
                                                        <span class="d-none d-sm-block">Guardar2</span>
            </button>
    </form>