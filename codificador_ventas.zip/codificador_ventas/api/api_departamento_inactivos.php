<?php
  require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
  global $wpdb;
  $response = array();
  header("Content-Type: Json");
  $i = 0;
  $motivoss = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}departamento WHERE estado='Inactivo'" , ARRAY_A);  

  foreach ( $motivoss as $resultados ) 
  {
                              
    $response [$i]['id_departamento'] = $resultados ['id_departamento'];
    $response [$i]['departamento'] = $resultados ['departamento'];
    $response [$i]['estado'] = $resultados ['estado'];
    $i++;
  
  }   

  echo json_encode($response,JSON_PRETTY_PRINT);
?>
