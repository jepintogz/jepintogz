<?php
    require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
    global $wpdb;
    $planes = sanitize_text_field($_POST["planes"]);
    $estado = 'Activo';
    $sql11_42_1 ="INSERT INTO `{$wpdb->prefix}planes` (`id_planes`, `planes`, `estado`) VALUES (Null, '$planes', '$estado')";
    $wpdb->query($sql11_42_1);  
    echo 1;

?>