<?php
require_once(explode("wp-content", __FILE__)[0] . "wp-config.php"); 
global $wpdb;

$fecha_inicial = sanitize_text_field($_POST["fecha_inicial_reporte"]);
$fecha_final = sanitize_text_field($_POST["fecha_final_reporte"]);

$user_info = get_userdata(1);
if (is_user_logged_in()){
$cu = wp_get_current_user();
}
$user_general = $cu->user_login;
$user_general;
$permisos = implode(', ', $cu->roles);
$wpurl = plugins_url().'/codificador_ventas/plantilla/icons-1.7.2/bootstrap-icons.svg#justify';
$resultado_productos = $wpdb->get_row( "SELECT * FROM  {$wpdb->prefix}productos WHERE estado = 'Activo'", ARRAY_A );

$id_productos = $resultado_productos["id_productos"];
$productos = $resultado_productos["productos"];

$consulta_usuarios = $wpdb->get_results( "SELECT id_codificador,id_departamento,id_accion,id_productos,id_planes,id_canal_entrada,cups,usuario_delta,usuario,fecha_registro,
max(case when (id_productos) = '1' then '1' end) productos1,
max(case when (id_productos) = '2' then '2' end) productos2,
max(case when (id_productos) = '3' then '3' end) productos3,
max(case when (id_productos) = '4' then '4' end) productos4,
max(case when (id_productos) = '5' then '5' end) productos5,
max(case when (id_productos) = '6' then '6' end) productos6,
max(case when (id_productos) = '7' then '7' end) productos7,
max(case when (id_productos) = '8' then '8' end) productos8,
max(case when (id_productos) = '9' then '9' end) productos9,
max(case when (id_productos) = '10' then '10' end) productos10,
max(case when (id_productos) = '11' then '11' end) productos11,
max(case when (id_productos) = '12' then '12' end) productos12,
max(case when (id_productos) = '13' then '13' end) productos13,
max(case when (id_productos) = '14' then '14' end) productos14,
max(case when (id_productos) = '15' then '15' end) productos15,
max(case when (id_productos) = '16' then '16' end) productos16,
max(case when (id_productos) = '17' then '17' end) productos17,
max(case when (id_productos) = '18' then '18' end) productos18

FROM `{$wpdb->prefix}codificador_ventas` WHERE SUBSTR({$wpdb->prefix}codificador_ventas.fecha_registro,1,10)>='$fecha_inicial' AND SUBSTR({$wpdb->prefix}codificador_ventas.fecha_registro,1,10)<='$fecha_final' AND {$wpdb->prefix}codificador_ventas.fecha_registro GROUP BY usuario,cups,id_accion" , ARRAY_A);   

?>

                <table id="listado_reporte" class="display" style="width:100%;font-size: 11px;">
                          <thead>  
                               <tr style="background: #FF0066;color: #FFFF;">  
                                    <th>Editar</th>
                                    <th>Eliminar</th>
                                    <th>Empleado</th>
                                    <th>Usuario Delta</th>
                                    <th>Nombre</th>
                                    <th>Cups</th>
                                    <th>SPP PLUS</th>
                                    <th>SPP AUTONOMO</th>
                                    <th>API - ASISTENCIA PYMES</th>
                                    <th>UUEE - URGENCIAS ELECTRICAS</th>
                                    <th>FE - FACTURA ELECTRONICA</th>
                                    <th>CF - CUOTA FIJA</th>
                                    <th>PMG - PACK MANTENIMIENTO GAS</th>
                                    <th>AECC - ASOCIACION CONTRA EL CANCER</th>
                                    <th>SPH+ PROTECCION ELECTRICA HOGAR PLUS</th>
                                    <th>SPC - SERVICIO PROTECCION CLIMATIZACION</th>
                                    <th>SPE - SERVICIO PROTECCION ELECTRODOMESTICOS</th>
                                    <th>SPEH - SERVICIO PROTECCION ELECTRICA HOGAR</th>
                                    <th>AG - ASISTENCIA GAS</th>
                                    <th>PG - PROTECCION GAS</th>
                                    <th>SMART HOME</th>
                                    <th>SMART MOBILITY</th>
                                    <th>OTROS PRODUCTOS</th>
                                    <th>ASISTENTE SMART</th>    
                                    <th>Plataforma</th>
                                    <th>Acción</th>
                                    <th>Fecha</th>
                                    <th>Hora</th>
                                    <th>Departamento</th>
                                    <th>Coordinador</th>
                                    <th>Planes</th>
                                    <th>Canal Entrada</th>
                                    
                               </tr>  
                          </thead>  
                          <?php
                          foreach ( $consulta_usuarios as $row )
                          {  

                              $id_departamento = $row['id_departamento'];
                              $id_accion = $row['id_accion'];
                              $id_productos = $row['id_productos'];
                              $tx = $row['tx'];
                              $id_planes = $row['id_planes'];
                              $usuario_delta = $row['usuario_delta'];
                              $usuario_consulta = $row['usuario'];
                              $estado = $row['estado'];
                              $fecha_registro = $row['fecha_registro'];
                              $id_canal_entrada = $row['id_canal_entrada'];
                              $dato_fecha = $fecha_registro;
                              $fecha = date('Y-m-d',strtotime($dato_fecha));

                              $fechaMysql2 = $fecha;
                              $fecha2 = preg_split("/[\s-]/", $fechaMysql2);
                              $mostrar_fecha2 = $fecha2[2].'/'.$fecha2[1].'/'.$fecha2[0];



        $hora = date('H:i:s',strtotime($dato_fecha)); 

        $filas2 = $wpdb->get_row( "SELECT * FROM  {$wpdb->prefix}departamento WHERE id_departamento = '$id_departamento'", ARRAY_A );
        $filas3 = $wpdb->get_row( "SELECT * FROM  {$wpdb->prefix}accion WHERE id_accion = '$id_accion'", ARRAY_A );
        $filas4 = $wpdb->get_row( "SELECT * FROM  {$wpdb->prefix}productos WHERE id_productos = '$id_productos'", ARRAY_A );
        $filas5 = $wpdb->get_row( "SELECT * FROM  {$wpdb->prefix}planes WHERE id_planes = '$id_planes'", ARRAY_A );
        $filas6 = $wpdb->get_row( "SELECT * FROM  {$wpdb->prefix}usuarios_delta WHERE user_login = '$usuario_consulta'", ARRAY_A );
        $filas8 = $wpdb->get_row( "SELECT * FROM  {$wpdb->prefix}canal_entrada WHERE id_canal_entrada = '$id_canal_entrada'", ARRAY_A );
        $filas9 = $wpdb->get_row( "SELECT * FROM  {$wpdb->prefix}usuarios_delta WHERE tx = '$usuario_delta' OR delta_emp = '$usuario_delta' OR tsau = '$usuario_delta' or tgeir = '$usuario_delta' or tc2c = '$usuario_delta' OR omega_emicion = '$usuario_delta'", ARRAY_A );
        $filas11 = $wpdb->get_row( "SELECT {$wpdb->prefix}users.user_login, firstmeta.meta_value as first_name, lastmeta.meta_value as last_name FROM {$wpdb->prefix}users left join {$wpdb->prefix}usermeta as firstmeta on {$wpdb->prefix}users.ID = firstmeta.user_id and firstmeta.meta_key = 'first_name' left join {$wpdb->prefix}usermeta as lastmeta on {$wpdb->prefix}users.ID = lastmeta.user_id and lastmeta.meta_key = 'last_name' WHERE {$wpdb->prefix}users.user_login = '$usuario_consulta'", ARRAY_A );
        $nombres_apellidos = $filas11["last_name"].', '.' '.$filas11["first_name"]; 
        $id_pais = $filas9['id_pais'];

        $filas7 = $wpdb->get_row( "SELECT * FROM  {$wpdb->prefix}pais WHERE id_pais = '$id_pais'", ARRAY_A );
        $fecha_inicial_reporte = sanitize_text_field($_POST["fecha_inicial_reporte"]);
        $fecha_final_reporte = sanitize_text_field($_POST["fecha_final_reporte"]);

      

                               echo '  
                               <tr>  

                                    <td style="text-align: center;"><button class="btn btn-primary primary-icon-notika btn-reco-mg btn-button-mg" class="btn btn-outline-primary block" data-toggle="tab" href="#home3" onclick="consulta_id_codificador('.$row["id_codificador"].'),consulta_id_codificador2('.$row["id_codificador"].'),consulta_canal_entrada('.$row["id_codificador"].'),consulta_usuario_delta('.$row["id_codificador"].'),consulta_departamento('.$row["id_codificador"].'),consulta_accion('.$row["id_codificador"].'),consulta_planes('.$row["id_codificador"].'),consulta_productos(\''.$row["cups"].'\',\''.$row["fecha_registro"].'\'),consulta_fecha('.$row["id_codificador"].'),consulta_usuario('.$row["id_codificador"].'),consulta_cups('.$row["id_codificador"].'),consulta_usuario_delta2('.$row["id_codificador"].')"><i class="notika-icon notika-edit"></i>
                                    <svg class="bi" width="1em" height="1em" fill="currentColor">
                                          <use
                                              xlink:href="'.$wpurl.'" />
                                      </svg>
                                    
                                    </button></td>
                                    
                                    <td style="text-align: center;"><button class="btn btn-cyan cyan-icon-notika btn-reco-mg btn-button-mg" class="btn btn-outline-primary block" onclick="eliminar_venta('.$row["id_planes"].','.$row["id_departamento"].',\''.$row["cups"].'\','.$row["id_accion"].')"><i class="notika-icon notika-close"></i>
                                    <svg class="bi" width="1em" height="1em" fill="currentColor">
                                          <use
                                              xlink:href="'.$wpurl.'" />
                                      </svg>
                                    </button></td>

                                    <td style="text-align: left;">'.$filas9['user_login'].'</td>  
                                    <td style="text-align: left;">'.($row['usuario_delta']).'</td>  
                                    <td style="text-align: center;">'.($nombres_apellidos).'</td>
                                    <td style="text-align: left;">'.($row['cups']).'</td>
                                    ';

                                if($row['productos1']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos2']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  

                                    if($row['productos3']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  



                                    if($row['productos4']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos5']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos6']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos7']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos8']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos9']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos10']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos11']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos12']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos13']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos14']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos15']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos16']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }  


                                    if($row['productos17']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }      
                                    
                                    if($row['productos18']>='1')
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('1').'</td>';
                                    }else
                                    {
                                      echo '<td style="text-align: center;">'.utf8_decode('0').'</td>';
                                    }   

                                echo ' 
                                    <td style="text-align: left;">'.($filas7['pais']).'</td>  
                                    <td style="text-align: left;">'.($filas3['accion']).'</td>  
                                    <td style="text-align: center;">'.$mostrar_fecha2.'</td>
                                    <td style="text-align: left;">'.$hora.'</td>
                                    <td style="text-align: left;">'.$filas2['departamento'].'</td>
                                    <td style="text-align: left;">'.utf8_encode(utf8_decode($filas9['coordinador'])).'</td>
                                    <td style="text-align: left;">'.($filas5['planes']).'</td>
                                    <td style="text-align: left;">'.($filas8['canal_entrada']).'</td>
                                    </tr>  
                                    ';    
                                      
                              
                          }  
                          ?>  
                     </table>