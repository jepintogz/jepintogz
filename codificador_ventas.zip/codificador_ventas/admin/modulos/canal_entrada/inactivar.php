<?php
  require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
  global $wpdb;
  $id_canal_entrada=sanitize_text_field($_POST["id_canal_entrada"]);
  $sql11_42_1 ="UPDATE {$wpdb->prefix}canal_entrada SET estado = 'Inactivo' WHERE id_canal_entrada = '$id_canal_entrada'";
  $wpdb->query($sql11_42_1);  
?>