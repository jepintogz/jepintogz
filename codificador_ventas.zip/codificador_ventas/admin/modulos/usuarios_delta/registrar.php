<?php
    require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
    global $wpdb;

    $id_pais = sanitize_text_field($_POST["id_pais"]);
    $id_cargos = '1';
    $id_departamento = sanitize_text_field($_POST["id_departamento"]);
    $user_login = sanitize_text_field($_POST["user_login"]);
    $nombres_apellidos = sanitize_text_field($_POST["nombres_apellidos2"]);
    $tx = sanitize_text_field($_POST["tx"]);
    $delta_emp = sanitize_text_field($_POST["delta_emp"]);
    $tsau = sanitize_text_field($_POST["tsau"]);
    $tgeir = sanitize_text_field($_POST["tgeir"]);
    $tc2c = sanitize_text_field($_POST["tc2c"]);
    $omega_emicion = sanitize_text_field($_POST["omega_emicion"]);
    $estado = 'Activo';
    $coordinador = sanitize_text_field($_POST["coordinador"]);

    $sql11_42_1 ="INSERT INTO `{$wpdb->prefix}usuarios_delta` (`id_usuarios_delta`,`id_pais`, `id_cargos`, `id_departamento`,`user_login`, `nombres_apellidos`, `tx`,`delta_emp`, `tsau`, `tgeir`,`tc2c`, `omega_emicion`, `coordinador`, `estado`) VALUES (Null, '$id_pais', '$id_cargos', '$id_departamento', '$user_login', '$nombres_apellidos', '$tx', '$delta_emp', '$tsau', '$tgeir', '$tc2c', '$omega_emicion', '$coordinador', '$estado')";
    $wpdb->query($sql11_42_1);  
    echo 1;
?>