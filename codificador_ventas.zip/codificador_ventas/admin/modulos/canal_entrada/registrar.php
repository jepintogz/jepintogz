<?php
    require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
    global $wpdb;
    $canal_entrada = sanitize_text_field($_POST["canal_entrada"]);
    $estado = 'Activo';
    $sql11_42_1 ="INSERT INTO `{$wpdb->prefix}canal_entrada` (`id_canal_entrada`, `canal_entrada`, `estado`) VALUES (Null, '$canal_entrada', '$estado')";
    $wpdb->query($sql11_42_1);  
    echo 1;

?>