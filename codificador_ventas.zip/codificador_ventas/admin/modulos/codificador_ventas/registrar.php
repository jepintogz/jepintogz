<?php

require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
global $wpdb;	  

if (is_user_logged_in()){
$cu = wp_get_current_user();
}
$user_general = $cu->user_login;
$user_general;



$usuario_delta = sanitize_text_field($_POST["usuario_delta"]);
$id_departamento = sanitize_text_field($_POST["id_departamento"]);
$id_accion = sanitize_text_field($_POST["id_accion"]);
$id_productos = $_POST["id_productos"];
$id_canal_entrada = sanitize_text_field($_POST["id_canal_entrada"]);



if(sanitize_text_field($_POST["id_planes"])==NULL){
    $id_planes = '0';
}else{
    $id_planes = sanitize_text_field($_POST["id_planes"]);
}
$cups = sanitize_text_field($_POST["cups"]);
$user_admin = sanitize_text_field($_POST["user_admin"]);
$usuario = $user_general;

$estado = 'Activo';






if ($conexion->connect_error) {
    die("Connection failed: " . $conexion->connect_error);
} 


for ($i=0;$i<count($id_productos);$i++) 
{ 
            
    $ciclo = $id_productos[$i]; 
    $sql11_424 ="INSERT INTO `{$wpdb->prefix}codificador_ventas` (`id_codificador`, `id_departamento`, `id_accion`, `id_productos`, `id_planes`, `id_canal_entrada`, `cups`, `usuario_delta`, `usuario`, `estado`) VALUES (Null, '$id_departamento', '$id_accion', '$ciclo', '$id_planes', '$id_canal_entrada', '$cups', '$usuario_delta', '$user_admin', '$estado')";
    $wpdb->query($sql11_424); 
            
} 

if($_POST["id_productos"]==NULL){
           
    $sql11_4241 ="INSERT INTO `{$wpdb->prefix}codificador_ventas` (`id_codificador`, `id_departamento`, `id_accion`, `id_productos`, `id_planes`, `id_canal_entrada`, `cups`, `usuario_delta`, `usuario`, `estado`) VALUES (Null, '$id_departamento', '$id_accion', '0', '$id_planes', '$id_canal_entrada', '$cups', '$usuario_delta', '$user_admin', '$estado')";
    $wpdb->query($sql11_4241); 
}
echo 1;
	
?>