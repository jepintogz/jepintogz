<?php
      
require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
global $wpdb;      


$user_info = get_userdata(1);
if (is_user_logged_in()){
$cu = wp_get_current_user();
}
$user_general = $cu->user_login;
$user_general;
$hoy = date("Y-m-d");
$hoy2 = date("Y-m-d");
$fecha_inicial_estadisticas = sanitize_text_field($_POST["fecha_inicial_estadisticas"]);
$id_accion_estadisticas = sanitize_text_field($_POST["id_accion_estadisticas"]);
$fechaMysql2 = $fecha_inicial_estadisticas;
$fecha2 = preg_split("/[\s-]/", $fechaMysql2);
$mostrar_fecha2 = $fecha2[1];
$mostrar_fecha3 = $fecha2[0];

$dia1 = '01';
$dia2 = '02';
$dia3 = '03';
$dia4 = '04';
$dia5 = '05';
$dia6 = '06';
$dia7 = '07';
$dia8 = '08';
$dia9 = '09';
$dia10 = '10';
$dia11 = '11';
$dia12 = '12';
$dia13 = '13';
$dia14 = '14';
$dia15 = '15';
$dia16 = '16';
$dia17 = '17';
$dia18 = '18';
$dia19 = '19';
$dia20 = '20';
$dia21 = '21';
$dia22 = '22';
$dia23 = '23';
$dia24 = '24';
$dia25 = '25';
$dia26 = '26';
$dia27 = '27';
$dia28 = '28';
$dia29 = '29';
$dia30 = '30';
$dia31 = '31';
$contador1=0;
$contador3=0;
$contador5=0;


if($id_accion_estadisticas=='2')
{

$resultado_principal = $wpdb->get_results( "SELECT {$wpdb->prefix}codificador_ventas.id_codificador,{$wpdb->prefix}codificador_ventas.id_departamento,{$wpdb->prefix}codificador_ventas.id_accion,{$wpdb->prefix}codificador_ventas.id_productos,{$wpdb->prefix}codificador_ventas.id_planes,{$wpdb->prefix}codificador_ventas.id_canal_entrada,{$wpdb->prefix}codificador_ventas.cups,{$wpdb->prefix}codificador_ventas.usuario_delta,{$wpdb->prefix}codificador_ventas.usuario,{$wpdb->prefix}codificador_ventas.fecha_registro,{$wpdb->prefix}accion.id_accion,{$wpdb->prefix}accion.accion,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '1' then '1' end) productos1,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '2' then '2' end) productos2,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '3' then '3' end) productos3,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '4' then '4' end) productos4,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '5' then '5' end) productos5,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '6' then '6' end) productos6,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '7' then '7' end) productos7,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '8' then '8' end) productos8,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '9' then '9' end) productos9,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '10' then '10' end) productos10,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '11' then '11' end) productos11,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '12' then '12' end) productos12,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '13' then '13' end) productos13,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '14' then '14' end) productos14,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '15' then '15' end) productos15,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '16' then '16' end) productos16,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '17' then '17' end) productos17,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` 
LEFT JOIN {$wpdb->prefix}accion ON {$wpdb->prefix}accion.id_accion = {$wpdb->prefix}codificador_ventas.id_accion
WHERE MONTH({$wpdb->prefix}codificador_ventas.fecha_registro) = '$mostrar_fecha2' AND YEAR({$wpdb->prefix}codificador_ventas.fecha_registro) = '$mostrar_fecha3' AND {$wpdb->prefix}codificador_ventas.usuario = '$user_general' AND {$wpdb->prefix}codificador_ventas.id_accion = '2' OR {$wpdb->prefix}codificador_ventas.id_accion = '3'  GROUP BY {$wpdb->prefix}codificador_ventas.usuario,{$wpdb->prefix}codificador_ventas.fecha_registro" , ARRAY_A);   

}else
{

$resultado_principal = $wpdb->get_results( "SELECT {$wpdb->prefix}codificador_ventas.id_codificador,{$wpdb->prefix}codificador_ventas.id_departamento,{$wpdb->prefix}codificador_ventas.id_accion,{$wpdb->prefix}codificador_ventas.id_productos,{$wpdb->prefix}codificador_ventas.id_planes,{$wpdb->prefix}codificador_ventas.id_canal_entrada,{$wpdb->prefix}codificador_ventas.cups,{$wpdb->prefix}codificador_ventas.usuario_delta,{$wpdb->prefix}codificador_ventas.usuario,{$wpdb->prefix}codificador_ventas.fecha_registro,{$wpdb->prefix}accion.id_accion,{$wpdb->prefix}accion.accion,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '1' then '1' end) productos1,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '2' then '2' end) productos2,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '3' then '3' end) productos3,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '4' then '4' end) productos4,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '5' then '5' end) productos5,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '6' then '6' end) productos6,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '7' then '7' end) productos7,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '8' then '8' end) productos8,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '9' then '9' end) productos9,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '10' then '10' end) productos10,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '11' then '11' end) productos11,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '12' then '12' end) productos12,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '13' then '13' end) productos13,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '14' then '14' end) productos14,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '15' then '15' end) productos15,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '16' then '16' end) productos16,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '17' then '17' end) productos17,
max(case when ({$wpdb->prefix}codificador_ventas.id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` 
LEFT JOIN {$wpdb->prefix}accion ON {$wpdb->prefix}accion.id_accion = {$wpdb->prefix}codificador_ventas.id_accion
WHERE {$wpdb->prefix}codificador_ventas.id_accion = '$id_accion_estadisticas' AND MONTH({$wpdb->prefix}codificador_ventas.fecha_registro) = '$mostrar_fecha2' AND YEAR({$wpdb->prefix}codificador_ventas.fecha_registro) = '$mostrar_fecha3' AND {$wpdb->prefix}codificador_ventas.usuario = '$user_general' GROUP BY {$wpdb->prefix}codificador_ventas.usuario,{$wpdb->prefix}codificador_ventas.fecha_registro" , ARRAY_A);   

}



$resultado2 = $wpdb->get_results( "SELECT id_codificador,id_departamento,id_accion,id_productos,id_planes,id_canal_entrada,cups,usuario_delta,usuario,fecha_registro,
max(case when (id_productos) = '1' then '1' end) productos1,
max(case when (id_productos) = '2' then '2' end) productos2,
max(case when (id_productos) = '3' then '3' end) productos3,
max(case when (id_productos) = '4' then '4' end) productos4,
max(case when (id_productos) = '5' then '5' end) productos5,
max(case when (id_productos) = '6' then '6' end) productos6,
max(case when (id_productos) = '7' then '7' end) productos7,
max(case when (id_productos) = '8' then '8' end) productos8,
max(case when (id_productos) = '9' then '9' end) productos9,
max(case when (id_productos) = '10' then '10' end) productos10,
max(case when (id_productos) = '11' then '11' end) productos11,
max(case when (id_productos) = '12' then '12' end) productos12,
max(case when (id_productos) = '13' then '13' end) productos13,
max(case when (id_productos) = '14' then '14' end) productos14,
max(case when (id_productos) = '15' then '15' end) productos15,
max(case when (id_productos) = '16' then '16' end) productos16,
max(case when (id_productos) = '17' then '17' end) productos17,
max(case when (id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` WHERE usuario = '$user_general' AND id_accion = '1' AND id_accion = '2' GROUP BY usuario,fecha_registro" , ARRAY_A);   



$resultado3 = $wpdb->get_results( "SELECT 
max(case when (id_productos) = '1' then '1' end) productos1,
max(case when (id_productos) = '2' then '2' end) productos2,
max(case when (id_productos) = '3' then '3' end) productos3,
max(case when (id_productos) = '4' then '4' end) productos4,
max(case when (id_productos) = '5' then '5' end) productos5,
max(case when (id_productos) = '6' then '6' end) productos6,
max(case when (id_productos) = '7' then '7' end) productos7,
max(case when (id_productos) = '8' then '8' end) productos8,
max(case when (id_productos) = '9' then '9' end) productos9,
max(case when (id_productos) = '10' then '10' end) productos10,
max(case when (id_productos) = '11' then '11' end) productos11,
max(case when (id_productos) = '12' then '12' end) productos12,
max(case when (id_productos) = '13' then '13' end) productos13,
max(case when (id_productos) = '14' then '14' end) productos14,
max(case when (id_productos) = '15' then '15' end) productos15,
max(case when (id_productos) = '16' then '16' end) productos16,
max(case when (id_productos) = '17' then '17' end) productos17,
max(case when (id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` WHERE id_accion = '1' AND SUBSTR({$wpdb->prefix}codificador_ventas.fecha_registro,1,10)='$hoy' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador2 = $wpdb->num_rows;



$resultado4 = $wpdb->get_results( "SELECT 
max(case when (id_productos) = '1' then '1' end) productos1,
max(case when (id_productos) = '2' then '2' end) productos2,
max(case when (id_productos) = '3' then '3' end) productos3,
max(case when (id_productos) = '4' then '4' end) productos4,
max(case when (id_productos) = '5' then '5' end) productos5,
max(case when (id_productos) = '6' then '6' end) productos6,
max(case when (id_productos) = '7' then '7' end) productos7,
max(case when (id_productos) = '8' then '8' end) productos8,
max(case when (id_productos) = '9' then '9' end) productos9,
max(case when (id_productos) = '10' then '10' end) productos10,
max(case when (id_productos) = '11' then '11' end) productos11,
max(case when (id_productos) = '12' then '12' end) productos12,
max(case when (id_productos) = '13' then '13' end) productos13,
max(case when (id_productos) = '14' then '14' end) productos14,
max(case when (id_productos) = '15' then '15' end) productos15,
max(case when (id_productos) = '16' then '16' end) productos16,
max(case when (id_productos) = '17' then '17' end) productos17,
max(case when (id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` WHERE usuario = '$user_general' AND id_accion = '1' AND MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador3 = $wpdb->num_rows;



$resultado5 = $wpdb->get_results( "SELECT 
max(case when (id_productos) = '1' then '1' end) productos1,
max(case when (id_productos) = '2' then '2' end) productos2,
max(case when (id_productos) = '3' then '3' end) productos3,
max(case when (id_productos) = '4' then '4' end) productos4,
max(case when (id_productos) = '5' then '5' end) productos5,
max(case when (id_productos) = '6' then '6' end) productos6,
max(case when (id_productos) = '7' then '7' end) productos7,
max(case when (id_productos) = '8' then '8' end) productos8,
max(case when (id_productos) = '9' then '9' end) productos9,
max(case when (id_productos) = '10' then '10' end) productos10,
max(case when (id_productos) = '11' then '11' end) productos11,
max(case when (id_productos) = '12' then '12' end) productos12,
max(case when (id_productos) = '13' then '13' end) productos13,
max(case when (id_productos) = '14' then '14' end) productos14,
max(case when (id_productos) = '15' then '15' end) productos15,
max(case when (id_productos) = '16' then '16' end) productos16,
max(case when (id_productos) = '17' then '17' end) productos17,
max(case when (id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` WHERE SUBSTR({$wpdb->prefix}codificador_ventas.fecha_registro,1,10)='$hoy' AND usuario = '$user_general' AND id_accion = '2' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador4 = $wpdb->num_rows;



$resultado5_13 = $wpdb->get_results( "SELECT 
max(case when (id_productos) = '1' then '1' end) productos1,
max(case when (id_productos) = '2' then '2' end) productos2,
max(case when (id_productos) = '3' then '3' end) productos3,
max(case when (id_productos) = '4' then '4' end) productos4,
max(case when (id_productos) = '5' then '5' end) productos5,
max(case when (id_productos) = '6' then '6' end) productos6,
max(case when (id_productos) = '7' then '7' end) productos7,
max(case when (id_productos) = '8' then '8' end) productos8,
max(case when (id_productos) = '9' then '9' end) productos9,
max(case when (id_productos) = '10' then '10' end) productos10,
max(case when (id_productos) = '11' then '11' end) productos11,
max(case when (id_productos) = '12' then '12' end) productos12,
max(case when (id_productos) = '13' then '13' end) productos13,
max(case when (id_productos) = '14' then '14' end) productos14,
max(case when (id_productos) = '15' then '15' end) productos15,
max(case when (id_productos) = '16' then '16' end) productos16,
max(case when (id_productos) = '17' then '17' end) productos17,
max(case when (id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` WHERE SUBSTR({$wpdb->prefix}codificador_ventas.fecha_registro,1,10)='$hoy' AND usuario = '$user_general' AND id_accion = '3' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador4_2 = $wpdb->num_rows;



$resultado6 = $wpdb->get_results( "SELECT 
max(case when (id_productos) = '1' then '1' end) productos1,
max(case when (id_productos) = '2' then '2' end) productos2,
max(case when (id_productos) = '3' then '3' end) productos3,
max(case when (id_productos) = '4' then '4' end) productos4,
max(case when (id_productos) = '5' then '5' end) productos5,
max(case when (id_productos) = '6' then '6' end) productos6,
max(case when (id_productos) = '7' then '7' end) productos7,
max(case when (id_productos) = '8' then '8' end) productos8,
max(case when (id_productos) = '9' then '9' end) productos9,
max(case when (id_productos) = '10' then '10' end) productos10,
max(case when (id_productos) = '11' then '11' end) productos11,
max(case when (id_productos) = '12' then '12' end) productos12,
max(case when (id_productos) = '13' then '13' end) productos13,
max(case when (id_productos) = '14' then '14' end) productos14,
max(case when (id_productos) = '15' then '15' end) productos15,
max(case when (id_productos) = '16' then '16' end) productos16,
max(case when (id_productos) = '17' then '17' end) productos17,
max(case when (id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` WHERE id_accion = '2' AND MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador6 = $wpdb->num_rows;




$resultado6_78 = $wpdb->get_results( "SELECT 
max(case when (id_productos) = '1' then '1' end) productos1,
max(case when (id_productos) = '2' then '2' end) productos2,
max(case when (id_productos) = '3' then '3' end) productos3,
max(case when (id_productos) = '4' then '4' end) productos4,
max(case when (id_productos) = '5' then '5' end) productos5,
max(case when (id_productos) = '6' then '6' end) productos6,
max(case when (id_productos) = '7' then '7' end) productos7,
max(case when (id_productos) = '8' then '8' end) productos8,
max(case when (id_productos) = '9' then '9' end) productos9,
max(case when (id_productos) = '10' then '10' end) productos10,
max(case when (id_productos) = '11' then '11' end) productos11,
max(case when (id_productos) = '12' then '12' end) productos12,
max(case when (id_productos) = '13' then '13' end) productos13,
max(case when (id_productos) = '14' then '14' end) productos14,
max(case when (id_productos) = '15' then '15' end) productos15,
max(case when (id_productos) = '16' then '16' end) productos16,
max(case when (id_productos) = '17' then '17' end) productos17,
max(case when (id_productos) = '18' then '18' end) productos18
FROM `{$wpdb->prefix}codificador_ventas` WHERE id_accion = '3' AND MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador6_78 = $wpdb->num_rows;


$resultado7 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_accion = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador7 = $wpdb->num_rows;

$resultado8 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_accion = '2' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador8 = $wpdb->num_rows;

$resultado9 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND  id_accion = '3' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador9 = $wpdb->num_rows;

$resultado10 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE SUBSTR({$wpdb->prefix}codificador_ventas.fecha_registro,1,10)>='$enero' AND SUBSTR({$wpdb->prefix}codificador_ventas.fecha_registro,1,10)<='$enero2' AND  id_accion = '1' AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador10 = $wpdb->num_rows;

$resultado10_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador10_1 = $wpdb->num_rows;

$resultado10_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia1' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador10_2 = $wpdb->num_rows;

$resultado11 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador11 = $wpdb->num_rows;          


$resultado11_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador11_1 = $wpdb->num_rows;

$resultado11_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia2' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador11_2 = $wpdb->num_rows;

$resultado12 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador12 = $wpdb->num_rows;

$resultado12_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador12_1 = $wpdb->num_rows;

$resultado12_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia3' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador12_2 = $wpdb->num_rows;


$resultado13 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador13 = $wpdb->num_rows;

$resultado13_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador13_1 = $wpdb->num_rows;

$resultado13_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia4' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador13_2 = $wpdb->num_rows;


$resultado14 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador14 = $wpdb->num_rows;


$resultado14_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador14_1 = $wpdb->num_rows;


$resultado14_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia5' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador14_2 = $wpdb->num_rows;

$resultado15 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador15 = $wpdb->num_rows;


$resultado15_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador15_1 = $wpdb->num_rows;


$resultado15_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia6' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador15_2 = $wpdb->num_rows;


$resultado16 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador16 = $wpdb->num_rows;


$resultado16_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador16_1 = $wpdb->num_rows;

$resultado16_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia7' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador16_2 = $wpdb->num_rows;

$resultado17 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador17 = $wpdb->num_rows;


$resultado17_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador17_1 = $wpdb->num_rows;

$resultado17_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia8' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador17_2 = $wpdb->num_rows;


$resultado18 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador18 = $wpdb->num_rows;

$resultado18_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador18_1 = $wpdb->num_rows;

$resultado18_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia9' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador18_2 = $wpdb->num_rows;



/*$resultado7 = $wpdb->get_results( "" , ARRAY_A);   
$contador7 = $wpdb->num_rows;*/

          ////////////////////////


$resultado19 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador19 = $wpdb->num_rows;


$resultado19_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador19_1 = $wpdb->num_rows;


$resultado19_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia10' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador19_2 = $wpdb->num_rows;

$resultado20 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador20 = $wpdb->num_rows;


$resultado20_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador20_1 = $wpdb->num_rows;



$resultado20_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia11' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador20_2 = $wpdb->num_rows;


$resultado21 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador21 = $wpdb->num_rows;


$resultado21_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador21_1 = $wpdb->num_rows;



$resultado21_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia12' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador21_2 = $wpdb->num_rows;



$resultado40 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia13' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40 = $wpdb->num_rows;


$resultado40_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia13' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_1 = $wpdb->num_rows;



$resultado40_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia13' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador40_2 = $wpdb->num_rows;


$resultado22 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador22 = $wpdb->num_rows;


$resultado22_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador22_1 = $wpdb->num_rows;



$resultado22_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia14' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador22_2 = $wpdb->num_rows;



$resultado23 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23 = $wpdb->num_rows;


$resultado23_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_1 = $wpdb->num_rows;



$resultado23_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia15' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador23_2 = $wpdb->num_rows;




$resultado24 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24 = $wpdb->num_rows;


$resultado24_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_1 = $wpdb->num_rows;



$resultado24_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia16' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador24_2 = $wpdb->num_rows;

$resultado25 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25 = $wpdb->num_rows;


$resultado25_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_1 = $wpdb->num_rows;



$resultado25_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia17' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador25_2 = $wpdb->num_rows;



$resultado26 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26 = $wpdb->num_rows;


$resultado26_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_1 = $wpdb->num_rows;



$resultado26_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia18' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador26_2 = $wpdb->num_rows;


$resultado27 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27 = $wpdb->num_rows;


$resultado27_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_1 = $wpdb->num_rows;



$resultado27_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia19' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador27_2 = $wpdb->num_rows;



$resultado28 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28 = $wpdb->num_rows;


$resultado28_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_1 = $wpdb->num_rows;



$resultado28_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia20' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador28_2 = $wpdb->num_rows;



$resultado29 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29 = $wpdb->num_rows;


$resultado29_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_1 = $wpdb->num_rows;



$resultado29_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia21' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador29_2 = $wpdb->num_rows;


$resultado30 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30 = $wpdb->num_rows;


$resultado30_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_1 = $wpdb->num_rows;



$resultado30_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia22' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador30_2 = $wpdb->num_rows;



$resultado31 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31 = $wpdb->num_rows;


$resultado31_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_1 = $wpdb->num_rows;



$resultado31_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia23' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador31_2 = $wpdb->num_rows;



$resultado32 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32 = $wpdb->num_rows;


$resultado32_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_1 = $wpdb->num_rows;



$resultado32_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia24' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador32_2 = $wpdb->num_rows;


$resultado33 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33 = $wpdb->num_rows;


$resultado33_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_1 = $wpdb->num_rows;



$resultado33_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia25' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador33_2 = $wpdb->num_rows;


$resultado34 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34 = $wpdb->num_rows;


$resultado34_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_1 = $wpdb->num_rows;



$resultado34_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia26' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador34_2 = $wpdb->num_rows;


$resultado35 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35 = $wpdb->num_rows;


$resultado35_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_1 = $wpdb->num_rows;



$resultado35_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia27' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador35_2 = $wpdb->num_rows;



$resultado36 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36 = $wpdb->num_rows;


$resultado36_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_1 = $wpdb->num_rows;



$resultado36_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia28' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador36_2 = $wpdb->num_rows;


$resultado37 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador37 = $wpdb->num_rows;


$resultado37_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador37_1 = $wpdb->num_rows;



$resultado37_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia29' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador37_2 = $wpdb->num_rows;



$resultado38 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38 = $wpdb->num_rows;


$resultado38_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_1 = $wpdb->num_rows;



$resultado38_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia30' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador38_2 = $wpdb->num_rows;


$resultado39 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_accion = '1'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39 = $wpdb->num_rows;


$resultado39_1 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_accion = '2'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_1 = $wpdb->num_rows;



$resultado39_2 = $wpdb->get_results( "SELECT id_codificador FROM {$wpdb->prefix}codificador_ventas WHERE MONTH(fecha_registro) = '$mostrar_fecha2' AND YEAR(fecha_registro) = '$mostrar_fecha3' AND day(fecha_registro) = '$dia31' AND  id_accion = '3'  AND usuario = '$user_general' GROUP BY usuario,fecha_registro" , ARRAY_A);   
$contador39_2 = $wpdb->num_rows;
$sumatoria_gas = $contador8 + $contador9;
        


?>

<div class="mdl-grid">
                                        <div class="mdl-cell mdl-cell--12-col">
                                          
                                        </div>


    <br/><br/>
    <br/><br/>
    <div class="line-chart-area">
        <div class="container">
            <div class="row">






                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="width: 15%;">
                            <div class="line-chart-wp chart-display-nn" style="border-radius: 15px 15px 15px 15px;-moz-border-radius: 15px 15px 15px 15px;-webkit-border-radius: 15px 15px 15px 15px;border: 1px solid #54C7C5;background: #54C7C5;color: #ffffff;text-align: center;font-size: 13px;">
                                 
                                Ventas Hoy Luz <div style="font-size: 18px;">

                                <?php
                                    
                                    echo $contador2;
                                    
                                        
                                ?>

                                </div>
                                           
                            </div>
                    </div>




                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="width: 15%;">
                            <div class="line-chart-wp chart-display-nn" style="border-radius: 15px 15px 15px 15px;-moz-border-radius: 15px 15px 15px 15px;-webkit-border-radius: 15px 15px 15px 15px;border: 1px solid #54C7C5;background: #54C7C5;color: #ffffff;text-align: center;font-size: 13px;">
                                 
                                Total Ventas Luz <div style="font-size: 18px;">

                                <?php

                                    echo $contador3;
                                        
                                ?>

                                </div>
                                           
                            </div>
                    </div>




                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="width: 15%;">
                            <div class="line-chart-wp chart-display-nn" style="border-radius: 15px 15px 15px 15px;-moz-border-radius: 15px 15px 15px 15px;-webkit-border-radius: 15px 15px 15px 15px;border: 1px solid #999999;background: #999999;color: #ffffff;text-align: center;font-size: 13px;">
                                 
                                Ventas Hoy Gas <div style="font-size: 18px;">

                                <?php
                                  
                                    echo $sumas = $contador4+$contador4_2;
                                                                    
                                                                                
                                ?>

                                </div>
                                           
                            </div>
                    </div>



                    
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="width: 15%;">
                            <div class="line-chart-wp chart-display-nn" style="border-radius: 15px 15px 15px 15px;-moz-border-radius: 15px 15px 15px 15px;-webkit-border-radius: 15px 15px 15px 15px;border: 1px solid #999999;background: #999999;color: #ffffff;text-align: center;font-size: 13px;">
                                 
                                Total Ventas Gas<div style="font-size: 18px;">
                            
                                    <?php
                                
                                    echo $sumas3 = $contador6 + $contador6_78;    
                                ?>

                                </div>
                                           
                            </div>
                    </div>

                                        
                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="width: 15%;">
                      <div class="line-chart-wp chart-display-nn" style="border-radius: 15px 15px 15px 15px;-moz-border-radius: 15px 15px 15px 15px;-webkit-border-radius: 15px 15px 15px 15px;border: 1px solid #FFFFFF;background: #FFFFFF;color: #ffffff;text-align: center;font-size: 13px;color: #FFFFFF">
                         
                        Global Ventas <div style="font-size: 18px;">
                            <?php

                            echo "1";
                            ?>

                            </div>
                                   
                        </div>
                    </div>


                    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12" style="width: 15%;">
                            <div class="line-chart-wp chart-display-nn" style="border-radius: 15px 15px 15px 15px;-moz-border-radius: 15px 15px 15px 15px;-webkit-border-radius: 15px 15px 15px 15px;border: 1px solid #ff0066;background: #ff0066;color: #ffffff;text-align: center;font-size: 13px;">
                                 
                                Global Ventas <div style="font-size: 18px;">
                                    <?php

                                    echo $sum = $sumas3 + $contador3;
                                        
                                    ?>

                                </div>
                                           
                            </div>
                    </div>





            </div>
    </div>
                      




    <!-- Bar Chart area End-->
    <div class="line-chart-area">
        <div class="container">
            <div class="row">
                


                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12" style="position: relative;">
                    <div class="line-chart-wp sm-res-mg-t-30 chart-display-nn">
                        <script type="text/javascript">
                            var ctx = document.getElementById("barchart2");
                            var barchart2 = new Chart(ctx, {
                              type: 'pie',
                              data: {
                                labels: ["Electricidad","Gas"],
                                datasets: [{
                                  label: 'Ventas por día',
                                  data: [<?php echo $contador7; ?>,<?php echo $sumatoria_gas; ?>],
                                  backgroundColor: [
                                    '#ff0066',
                                    '#54C7C5',
                                    '#999999'
                                  ],
                                  borderColor: [
                                    '#ff0066'
                                  ],
                                  borderWidth: 1
                                }]
                              },
                              options: {
                                scales: {
                                  yAxes: [{
                                    ticks: {
                                      beginAtZero:true
                                    }
                                  }]
                                }
                              }
                            });
                      </script>
                        <div class="bar-chart-wp">
                        <canvas height="40vh" width="120vw" id="barchart2"></canvas>
                    </div>
                    </div>
                </div>



<?php



  $dias1 = $contador10 + $contador10_1 + $contador10_2;
  $dias2 = $contador11 + $contador11_1 + $contador11_2;
  $dias3 = $contador12 + $contador12_1 + $contador12_2;
  $dias4 = $contador13 + $contador13_1 + $contador13_2;
  $dias5 = $contador14 + $contador14_1 + $contador14_2;
  $dias6 = $contador15 + $contador15_1 + $contador15_2;
  $dias7 = $contador16 + $contador16_1 + $contador16_2;
  $dias8 = $contador17 + $contador17_1 + $contador17_2;
  $dias9 = $contador18 + $contador18_1 + $contador18_2;
  $dias10 =$contador19 + $contador19_1 + $contador19_2;
  $dias11 = $contador20 + $contador20_1 + $contador20_2;
  $dias12 = $contador21 + $contador21_1 + $contador21_2;
  $dias13 = $contador40 + $contador40_1 + $contador40_2;



  $dias14 = $contador22 + $contador22_1 + $contador22_2;  
  $dias15 = $contador23 + $contador23_1 + $contador23_2;
  $dias16 = $contador24 + $contador24_1 + $contador24_2;
  $dias17 = $contador25 + $contador25_1 + $contador25_2;
  $dias18 = $contador26 + $contador26_1 + $contador26_2;
  $dias19 = $contador27 + $contador27_1 + $contador27_2;

  $dias20 = $contador28 + $contador28_1 + $contador28_2;
  $dias21 = $contador29 + $contador29_1 + $contador29_2;
  $dias22 = $contador30 + $contador30_1 + $contador30_2;
  $dias23 = $contador31 + $contador31_1 + $contador31_2;
  $dias24 = $contador32 + $contador32_1 + $contador32_2;
  $dias25 = $contador33 + $contador33_1 + $contador33_2;
  $dias26 = $contador34 + $contador34_1 + $contador34_2;
  $dias27 = $contador35 + $contador35_1 + $contador35_2;
  $dias28 = $contador36 + $contador36_1 + $contador36_2;
  $dias29 = $contador37 + $contador37_1 + $contador37_2;
  $dias30 = $contador38 + $contador38_1 + $contador38_2;
  $dias31 = $contador39 + $contador39_1 + $contador39_2;

?>

                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12" style="left: -60px;">
                    <div class="line-chart-wp sm-res-mg-t-30 chart-display-nn">
                        <script type="text/javascript">
                            var ctx = document.getElementById("barchart1");
                            var barchart1 = new Chart(ctx, {
                              type: 'bar',
                              data: {
                                labels: ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"],
                                datasets: [{
                                  label: 'Ventas por día',
                                  data: [<?php echo $dias1; ?>,<?php echo $dias2; ?>,<?php echo $dias3; ?>,<?php echo $dias4; ?>,<?php echo $dias5; ?>,<?php echo $dias6; ?>,<?php echo $dias7; ?>,<?php echo $dias8; ?>,<?php echo $dias9; ?>,<?php echo $dias10; ?>,<?php echo $dias11; ?>,<?php echo $dias12; ?>,<?php echo $dias13; ?>,<?php echo $dias14; ?>,<?php echo $dias15; ?>,<?php echo $dias16; ?>,<?php echo $dias17; ?>,<?php echo $dias18; ?>,<?php echo $dias19; ?>,<?php echo $dias20; ?>,<?php echo $dias21; ?>,<?php echo $dias22; ?>,<?php echo $dias23; ?>,<?php echo $dias24; ?>,<?php echo $dias25; ?>,<?php echo $dias26; ?>,<?php echo $dias27; ?>,<?php echo $dias28; ?>,<?php echo $dias29; ?>,<?php echo $dias30; ?>,<?php echo $dias31; ?>],
                                  backgroundColor: [
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066',
                                    '#ff0066'

                                  ],
                                  borderColor: [
                                    '#ff0066'
                                  ],
                                  borderWidth: 1
                                }]
                              },
                              options: {
                                scales: {
                                  yAxes: [{
                                    ticks: {
                                      beginAtZero:true
                                    }
                                  }]
                                }
                              }
                            });
                      </script>
                        <div class="bar-chart-wp">
                        <canvas height="80vh" width="200vw" id="barchart1"></canvas>
                    </div>
                    </div>
                </div>














            </div>
            
        </div>
    </div>
                      

                    

   <form method="POST" id='form_activo' enctype="multipart/form-data">
        

                <table id="mis_ventas_x_acciones" class="display" style="width:100%">
                          <thead>  
                               <tr style="background: #FF0066;color: #FFFF;">  
                                    <td style="text-align: center;">Usuario Delta</td>  
                                    <td style="text-align: center;">Fecha</td> 
                                    <td style="text-align: center;">Hora</td>
                                    <td style="text-align: center;">Cups</td>
                                    <td style="text-align: center;">Acción</th>
                               </tr>  
                          </thead>  
                          <?php  
                          foreach ( $resultado_principal as $activos )
                          {  

                                

                                $fechaMysql = $activos['fecha_registro'];
                                $fecha = preg_split("/[\s-]/", $fechaMysql);
                                $mostrar_fecha = $fecha[2].'/'.$fecha[1].'/'.$fecha[0];
                                $hora = $fecha[3];

                               echo '  
                               <tr>';  
                                    

                                    

                              echo '<td style="text-align: center;">'.$activos["usuario_delta"].'</td> 
                                    <td style="text-align: center;">'.$mostrar_fecha.'</td>  
                                    <td style="text-align: center;">'.$hora.'</td>  
                                    <td style="text-align: center;">'.$activos["cups"].'</td>  
                                    <td style="text-align: center;">'.$activos["accion"].'</td>
                                    ';



                               echo '</tr>  
                               ';  
                          }  
                          ?>  
                     </table>    

                    </form>

                    
        

