<?php
	  
    include_once '../../../../../../wp-config.php';
    include_once '../../../../../../wp-load.php';
    include_once '../../../../../../wp-includes/wp-db.php';
    include_once '../../../../../../wp-includes/pluggable.php';

    include('../../../conexion/conexion.php');
    global $wpdb;
	$id_cargos=$_POST["id_cargos"];




 $consulta = "UPDATE {$wpdb->prefix}cargos SET estado = 'Activo' WHERE id_cargos = '$id_cargos'";


if ($conexion->query($consulta) === TRUE) {
    echo 1;
} else {
    echo "Error: " . $consulta . "<br>" . $conexion->error;
}
 
$conexion->close();

?>
