<?php
    require_once(explode("wp-content", __FILE__)[0] . "wp-config.php");
    global $wpdb;
    $id_pais=sanitize_text_field($_POST["id_pais"]);
    $centro = sanitize_text_field($_POST["centro"]);
    $sql11_42_1 ="UPDATE {$wpdb->prefix}pais SET pais = '$centro' WHERE id_pais = '$id_pais'";
    $wpdb->query($sql11_42_1);  
    echo 1;

?>