<?php
	  
    include_once '../../../../../../wp-config.php';
    include_once '../../../../../../wp-load.php';
    include_once '../../../../../../wp-includes/wp-db.php';
    include_once '../../../../../../wp-includes/pluggable.php';

    include('../../../conexion/conexion.php');
    global $wpdb;
	  $id_cargos=$_POST["id_cargos"];
  	$result = mysqli_query($conexion, "SELECT * FROM  {$wpdb->prefix}cargos WHERE id_cargos = $id_cargos");
	  $filas = mysqli_fetch_array($result);
     	

?>  
	  <form method="POST" id='editar_formulario_cargos' enctype="multipart/form-data">
      <table  class="table table-hover">
      	<input type="hidden" name="id_cargos" value="<?php echo $id_cargos ?>">
          <tr>
            <td>Cargos: </td>
            <td>
              <input class="form-control" type="text" value="<?php echo $filas["cargos"] ?>" name="cargos" id="cargos">
            </td>
          </tr>
        </table>
        <button type="button" onclick="modificar_datos_cargos()" class="btn btn-primary ml-1"
            class="close" data-bs-dismiss="modal" aria-label="Close">
                                                        <i class="bx bx-check d-block d-sm-none"></i>
                                                        <span class="d-none d-sm-block">Guardar</span>
        </button> 
  </form>